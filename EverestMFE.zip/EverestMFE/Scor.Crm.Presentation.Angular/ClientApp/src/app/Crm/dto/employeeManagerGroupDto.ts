import { EmployeeDto } from './employeeDto';

export interface EmployeeManagerGroupDto {
    employeeManagerGroupId: string;
    employeeId: string;
    roleId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    employee: EmployeeDto;
}