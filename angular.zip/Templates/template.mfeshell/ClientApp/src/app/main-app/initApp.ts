import { AuthenticationService } from '@auth/services/authentication.service';
import { environment } from '@environment/environment';
import { AppSettingsService } from '@scor/common';

export function initApp(
  appSettings: AppSettingsService,
  authService: AuthenticationService
) {
  return () => {
    return new Promise<void>((resolve) => {
      appSettings
        .LoadConfigData(
          `assets/app-settings/appsettings.${environment.env}.json`
        ) //load app config file
        .then(() => authService.login()) // have the user loging
        .then(() => resolve()) // all is done return control back to angular
        .catch((error) =>
          alert(
            'Error connecting to authorization service...Please make sure it is running, message from server: ' +
              error.message
          )
        );
    });
  };
}
