import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InputTextModule } from 'primeng/inputtext';
import { CheckboxModule } from 'primeng/checkbox';
import { ListboxModule } from 'primeng/listbox';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import { CalendarModule } from 'primeng/calendar';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { CardModule } from 'primeng/card';
import { TooltipModule } from 'primeng/tooltip';
import { LoadingModule, GridModule, ScorToastModule } from '@scor/common';
import { ConfirmationService, MessageService } from 'primeng/api';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ButtonModule,
    ToastModule,
    MessagesModule,
    MessageModule,
    BrowserAnimationsModule,
    InputTextModule,
    CheckboxModule,
    ListboxModule,
    ConfirmDialogModule,
    DialogModule,
    DropdownModule,
    RadioButtonModule,
    CalendarModule,
    InputTextareaModule,
    ReactiveFormsModule,
    TooltipModule,
    LoadingModule,
    GridModule,
    ScorToastModule,
    CardModule,
  ],
  exports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ButtonModule,
    ToastModule,
    MessagesModule,
    MessageModule,
    BrowserAnimationsModule,
    InputTextModule,
    CheckboxModule,
    ListboxModule,
    ConfirmDialogModule,
    DialogModule,
    DropdownModule,
    RadioButtonModule,
    CalendarModule,
    InputTextareaModule,
    ReactiveFormsModule,
    TooltipModule,
    LoadingModule,
    GridModule,
    ScorToastModule,
    CardModule,
  ],
  providers: [ConfirmationService, MessageService],
})
export class SharedModule {}
