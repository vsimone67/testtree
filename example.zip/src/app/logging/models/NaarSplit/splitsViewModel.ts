import { SplitsModel } from './splitsModel';

export interface SplitsViewModel {
  new(): SplitsViewModel;

  splits: SplitsModel[];

}
