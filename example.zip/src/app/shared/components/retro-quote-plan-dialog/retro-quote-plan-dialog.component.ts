import { Component, OnInit, Input } from '@angular/core';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';
import { RetroQuotePlanModel } from '@retro/models/retroQuotePlanModel';
import { ColDef } from 'ag-grid-community';

@Component({
  selector: 'retro-quote-plan-dialog',
  templateUrl: './retro-quote-plan-dialog.component.html',
  styleUrls: ['./retro-quote-plan-dialog.component.css']
})
export class RetroQuotePlanComponent extends DialogBase implements OnInit {

  @Input() RetroQuotePlanList: Array<RetroQuotePlanModel>;
  GridCssStyle: string;
  columnDefs: Array<ColDef>;
  constructor() { super(); }


  ngOnInit(): void {
    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 50vh;";
  }

  createColumnDefs() {
    return [
      {
        headerName: "Plan Name",
        field: "planName"
      },
      {
        headerName: "Expiry Age",
        field: "expiryAge"
      },
      {
        headerName: "Issue Type",
        field: "issueType"
      },
      {
        headerName: "Base/Rider",
        field: "retroQuotePlanBaseRiderCodeName"

      },
      {
        headerName: "Recapture Years",
        field: "recaptureYears"

      },

    ];
  }

}
