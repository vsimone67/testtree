import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObstaclesStrategyComponent } from './obstacles-strategy.component';

describe('ObstaclesStrategyComponent', () => {
  let component: ObstaclesStrategyComponent;
  let fixture: ComponentFixture<ObstaclesStrategyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObstaclesStrategyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ObstaclesStrategyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
