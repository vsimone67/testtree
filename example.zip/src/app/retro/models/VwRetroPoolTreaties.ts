export interface VwRetroPoolTreaties
    {
        RetroPoolId: string;
        RetroTreatyId: string;
        TreatyNumber: string;
        MinCoverageEffectiveDate: Date | string | null;
        TerminatedDate: Date | string | null;
        TerminatedForNewBusinessDate: Date | string | null;
        TreatyEffectiveDate: Date | string | null;
        TreatyCategoryIdCodeName: string;
        NarSplitCodeId: string | null;
    }
