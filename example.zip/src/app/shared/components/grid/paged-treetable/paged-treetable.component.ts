import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {ColDef} from "ag-grid-community";
import {TreeTable} from "primeng";
import {User} from "@auth/models/user";
import {SiteConstants} from "@constants/siteConstants";
import {LifeLineRoles} from "@auth/models/lifeLineRoles";

@Component({
  selector: 'paged-treetable',
  templateUrl: './paged-treetable.component.html',
  styleUrls: ['./paged-treetable.component.css']
})
export class PagedTreetableComponent implements OnInit {
  @Input() tableData: Array<any>;
  @Input() columns: Array<ColDef>;
  @Input() levels: number;
  @Input() levelsMessages: any[];
  @Output() updateData: EventEmitter<any> = new EventEmitter<any>();
  @Output() rollbackdata: EventEmitter<any> = new EventEmitter<any>();
  @Input() checkActive: string
  @Input() pageSize: number;
  @Input() RecordCount: number;
  @Output() changePage: EventEmitter<any> = new EventEmitter<any>();
  @ViewChild('retroTable') retroTable: TreeTable;
  isAdmin:boolean=false
  constructor() {
  }

  ngOnInit(): void {
    var currentUser: User = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
    this.isAdmin = currentUser.roles.filter(role => role.role === LifeLineRoles.Adminstrator).length > 0
  }

  updateRetro(rowData) {
    this.updateData.emit(rowData)
  }

  onPageChanged(data: any) {
    this.pageSize = data.rows;
    this.changePage.emit(data)
  }

  rollback(rowData) {
    this.rollbackdata.emit(rowData)
  }
   filter(filtervalue, field, contains){
    console.log('called')
     this.retroTable.filter(filtervalue, field, contains)
  }
  resetFilters(){
    this.retroTable.filters = {}

  }
}
