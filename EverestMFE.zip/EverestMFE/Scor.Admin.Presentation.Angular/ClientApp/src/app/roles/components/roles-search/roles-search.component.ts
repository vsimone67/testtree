import { DatePipe } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { SecurityRolesService } from 'src/app/roles/services/security-roles.service';
import { RoleModel } from '../../models/role-model';

@Component({
  selector: 'app-roles-search',
  templateUrl: './roles-search.component.html',
  styleUrls: ['./roles-search.component.css'],
})
export class RolesSearchComponent implements OnInit {
  formRuns;
  roles: any[];
  @Output() searchData: EventEmitter<any> = new EventEmitter<any>();
  @Output() dataSelection: EventEmitter<any> = new EventEmitter<any>();
  paginator;
  teamId;
  loadingField: boolean = false;
  showDialog: boolean = false;
  showEditDialog: boolean = false;
  showAddUserDialog: boolean = false;
  newRole: RoleModel;
  allowAdd: boolean = false;
  showAll: boolean = false;
  selectedRole;
  roleId;
  fullRole: RoleModel[];

  constructor(
    private fb: FormBuilder,
    private pipe: DatePipe,
    private roleService: SecurityRolesService
  ) {
    this.formRuns = this.fb.group({
      roleId: [null, Validators.required],
    });
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    const newRoles = await this.roleService.getRoles();

    this.fullRole = newRoles;

    this.roles = [];
    newRoles.forEach((line: RoleModel) => {
      if (line)
        this.roles.push({
          label: line.roleName,
          value: line.roleId,
        });
    });
  }

  reset() {
    this.formRuns.reset();
    this.searchData.emit(null);
  }

  search() {
    this.loadingField = true;
    if (this.formRuns.valid) {
      this.searchData.emit(this.formRuns.value);
      this.allowAdd = true;
    }
    this.loadingField = false;
  }

  updateDrops(data) {
    this.allowAdd = !(data.value == null);

    for (var i = 0; i < this.fullRole.length; ++i) {
      if (this.fullRole[i].roleId == this.formRuns.value.roleId) {
        this.selectedRole = this.fullRole[i];
        this.dataSelection.emit(this.selectedRole);
        this.search();
      }
    }
  }

  addRole() {
    this.showDialog = true;
    this.newRole = <RoleModel>{};
  }

  closeAddDialog() {
    this.showDialog = false;
  }

  closeEditDialog() {
    this.showEditDialog = false;
  }

  closeAddRoleDialog() {
    this.showAddUserDialog = false;
  }

  saveRecord(data) {
    this.getInitialData();
  }

  saveEditRecord(data) {
    this.reset();
    this.getInitialData();
  }

  saveAddRoleRecord(data) {
    this.search();
  }

  addUserToRole() {
    if (!this.allowAdd) {
      return;
    }
    this.showAddUserDialog = true;
  }

  editUser() {
    if (!this.allowAdd) {
      return;
    }
    this.showEditDialog = true;
  }
}
