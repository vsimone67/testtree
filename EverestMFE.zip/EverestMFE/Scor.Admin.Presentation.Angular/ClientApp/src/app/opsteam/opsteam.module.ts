import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpsteamContainerComponent } from './components/opsteam-container/opsteam-container.component';
import { OpsteamResultsComponent } from './components/opsteam-results/opsteam-results.component';
import { OpsteamSearchComponent } from './components/opsteam-search/opsteam-search.component';
import { AddTeamMemberComponent } from './dialog/add-team-member/add-team-member.component';
import { DeleteTeamMemberComponent } from './dialog/delete-team-member/delete-team-member.component';
import { EditTeamMemberComponent } from './dialog/edit-team-member/edit-team-member.component';
import { InfoTeamMemberComponent } from './dialog/info-team-member/info-team-member.component';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [
    OpsteamContainerComponent,
    OpsteamResultsComponent,
    OpsteamSearchComponent,
    AddTeamMemberComponent,
    DeleteTeamMemberComponent,
    EditTeamMemberComponent,
    InfoTeamMemberComponent,
  ],
  imports: [CommonModule, SharedModule],
})
export class OpsteamModule {}
