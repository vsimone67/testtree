import { Component, OnInit, Input, SimpleChange } from "@angular/core";
import { TreatyCompleteModel } from "@assumed/models/TreatyCompleteModel";
import { ColDef, GridOptions } from "ag-grid-community";
import { DialogBase } from "@assumed/components/dialogs/dialog-base";
import { formatDate } from "../grid/formatters/formatDate";
import { formatCurrency } from "../grid/formatters/formatCurrency";

@Component({
  selector: "treaty-dialog",
  templateUrl: "./treaty-dialog.component.html",
  styleUrls: ["./treaty-dialog.component.css"],
})
export class TreatyDialogComponent extends DialogBase implements OnInit {
  @Input() treatyInfo: TreatyCompleteModel;
  columnDefs: Array<ColDef>;
  effectiveDate: string;
  coverageEffectiveDate: string;
  GridCssStyle: string;
  gridOption: GridOptions;

  constructor() {
    super();
    this.columnDefs = this.createColumnDefs();
    this.gridOption = <GridOptions>{};
    this.GridCssStyle = "width: 100%; height: 550px;";
  }

  ngOnInit(): void {}

  createColumnDefs() {
    return [
      {
        headerName: "Responsible Company",
        field: "responsibleCompanyName",
      },
      {
        headerName: "Plan",
        field: "insurancePlanShortName",
      },
      {
        headerName: "Band",
        field: "bandName",
      },
      {
        headerName: "Status",
        field: "treatyPlanRowStatusIdCodeName",
      },
      {
        headerName: "Quote Plan Name",
        field: "quotePlanPlanName",
        tooltipField: "quotePlanPlanName",
        width: 350,
      },
      {
        headerName: "Min Band Value",
        field: "minBandValue",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Max Band Value",
        field: "maxBandValue",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Responsible Transfer Type",
        field: "responsibleTransferTypeIdCodeName",
      },
      {
        headerName: "Coverage Effective Date",
        field: "treatyPlanCoverageEffectiveDate",
        valueFormatter: formatDate,
      },
      {
        headerName: "Treaty Terminated Date",
        field: "treatyPlanTerminatedDate",
        valueFormatter: formatDate,
      },
    ];
  }

  hideDialog() {
    this.onDialogHide.emit(true);
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if options are passed, override default
    if (changes.treatyInfo != undefined) {
      // convert the dates to a string for presentation so it will show mm/dd/yyyy
      this.coverageEffectiveDate = new Date(
        changes.treatyInfo.currentValue.treaty.treatyCoverageEffectiveDate
      ).toLocaleDateString();
      this.effectiveDate = new Date(
        changes.treatyInfo.currentValue.treaty.treatyEffectiveDate
      ).toLocaleDateString();
    }
  }
}
