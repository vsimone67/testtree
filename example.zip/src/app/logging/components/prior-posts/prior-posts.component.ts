import { Component, OnInit, Input, SimpleChange, OnChanges } from '@angular/core';
import { PriorsPostsViewModel } from '../../models/NaarSplit/priorsPostsViewModel';
import { formatNumberToCurrency } from '@shared/functions/formatNumberToCurrency';

@Component({
  selector: 'prior-posts',
  templateUrl: './prior-posts.component.html',
  styleUrls: ['./prior-posts.component.css']
})
export class PriorPostsComponent implements OnInit, OnChanges {
  @Input() priorInfo: PriorsPostsViewModel;
  constructor() { }

  // prior
  retainedNaar: string;
  retainedCeded: string;
  affiliateNAARRecapture: string;
  affiliateCededRecapture: string;
  affiliateNAARNonRecapture: string;
  affiliateCededNonRecapture: string;

  // posts
  retainedNAARPost: string;
  retainedCededPost: string;

  ngOnInit(): void {
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    //if options are passed, override default
    if (changes.priorInfo != undefined) {

      // prior
      this.retainedNaar = formatNumberToCurrency(changes.priorInfo.currentValue.priors.retainedNAAR);
      this.retainedCeded = formatNumberToCurrency(changes.priorInfo.currentValue.priors.retainedCeded);
      this.affiliateNAARRecapture = formatNumberToCurrency(changes.priorInfo.currentValue.priors.affiliateNAARRecapture);
      this.affiliateCededRecapture = formatNumberToCurrency(changes.priorInfo.currentValue.priors.affiliateCededRecapture);
      this.affiliateNAARNonRecapture = formatNumberToCurrency(changes.priorInfo.currentValue.priors.affiliateNAARNonRecapture);
      this.affiliateCededNonRecapture = formatNumberToCurrency(changes.priorInfo.currentValue.priors.affiliateCededNonRecapture);

      // posts
      this.retainedNAARPost = formatNumberToCurrency(changes.priorInfo.currentValue.priors.retainedNAAR);
      this.retainedCededPost = formatNumberToCurrency(changes.priorInfo.currentValue.priors.retainedCeded);
    }

  }
}
