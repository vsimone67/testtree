import { AddressDto } from './addressDto';
import { CompanyContactGroupMemberDto } from './companyContactGroupMemberDto';
import { CompanyOperationalTeamRelDto } from './companyOperationalTeamRelDto';
import { CompanyThresholdVolumeDto } from './companyThresholdVolumeDto';
import { PhoneNumberDto } from './phoneNumberDto';
import { RegionsCountryRelationshipDto } from './regionsCountryRelationshipDto';
import { SalesObjectiveDto } from './salesObjectiveDto';
import { SalesObstacleDto } from './salesObstacleDto';
import { SalesOpportunityDto } from './salesOpportunityDto';
import { UnderwritingSeriesDecisionLanguageDto } from './underwritingSeriesDecisionLanguageDto';

export interface CodeDto {
    codeId: string;
    codeCategoryId: string;
    codeDescription: string;
    codeName: string;
    codeValue: string;
    isDefault: boolean;
    sequenceNumber: number;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    addressAddressType: AddressDto[];
    addressState: AddressDto[];
    companyContactGroupMember: CompanyContactGroupMemberDto[];
    companyOperationalTeamRel: CompanyOperationalTeamRelDto[];
    companyThresholdVolumeThresholdReasonNavigation: CompanyThresholdVolumeDto[];
    companyThresholdVolumeThresholdTypeNavigation: CompanyThresholdVolumeDto[];
    phoneNumber: PhoneNumberDto[];
    regionsCountryRelationshipCountry: RegionsCountryRelationshipDto[];
    regionsCountryRelationshipRegion: RegionsCountryRelationshipDto[];
    salesObjective: SalesObjectiveDto[];
    salesObstacle: SalesObstacleDto[];
    salesOpportunity: SalesOpportunityDto[];
    underwritingSeriesDecisionLanguage: UnderwritingSeriesDecisionLanguageDto[];
}