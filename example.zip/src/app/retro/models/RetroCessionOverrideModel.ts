export interface RetroCessionOverrideModel {
  id: number;
  retroCessionId: string;
  overrideAllowRecapture: boolean | null;
  overrideRetroBindingLimit: number | null;
  overrideRateTableId: string | null;
  overrideRateFactor: number | null;
  retroTableRating: number | null;
  retroTableNumber: number | null;
  createDate: Date | string;
  createdBy: string;
  modifiedDate: Date | string | null;
  modifiedById: string | null;

  overrideRateTableName: string;
  createdByName: string;
  modifiedByName: string;
  hasRollback:boolean
}
