import { Output, EventEmitter, Injectable, Component } from '@angular/core';
import { EventService } from '@scor/common';

@Component({
  template: '',
})
export class DialogBase {
  @Output() onDialogHide: EventEmitter<boolean> = new EventEmitter<boolean>();
  showDialog: boolean = true;
  _eventService: EventService;
  constructor() {}

  ngOnInit(): void {}

  hideDialog() {
    this.onDialogHide.emit(true);
  }
}
