To Install Template (one time) Run
    dotnet new -i .\template.Angular

To UnInstall Run
    dotnet new -u FULLPATHINCLUDINGDRIVE\template.Angular

To List all templates and show their uninstall command
    dotnet new -u