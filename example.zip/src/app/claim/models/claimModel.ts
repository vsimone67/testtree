export interface ClaimModel {
  cessionId: string;
  claimId: string;
  claimNumber: string;
  claimTypeId: string;
  claimType: string;
  claimSubTypeId: string | null;
  claimSubType: string;
  claimBaseAmount: number | null;
  policyNumber: string;
  workflowCurrentStatus: string;
  legalEntity: string;
  insuredId: string | null;
  companyId: string | null;

}
