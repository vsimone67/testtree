import { GraphDataModel } from './GraphDataModel';

export interface GraphEventModel {
  id: string;
  label: string;
  data: GraphDataModel;
}
