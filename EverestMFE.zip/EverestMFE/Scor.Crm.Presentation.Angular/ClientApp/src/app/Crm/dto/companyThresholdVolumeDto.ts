import { CompanyDto } from './companyDto';
import { CodeDto } from './codeDto';

export interface CompanyThresholdVolumeDto {
    companyThresholdVolumeId: string;
    companyId: string;
    thresholdYear: number;
    thresholdType: string;
    thresholdVolume: number;
    thresholdReason: string;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    thresholdReasonNavigation: CodeDto;
    thresholdTypeNavigation: CodeDto;
}