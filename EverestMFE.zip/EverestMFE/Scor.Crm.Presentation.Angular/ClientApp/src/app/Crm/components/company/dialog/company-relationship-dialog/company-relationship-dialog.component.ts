import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CrmService} from "../../../../service/CrmService";
import {CompanyRelationshipDto} from "../../../../dto/companyRelationshipDto";

@Component({
  selector: 'company-relationship-dialog',
  templateUrl: './company-relationship-dialog.component.html',
  styleUrls: ['./company-relationship-dialog.component.css']
})
export class CompanyRelationshipDialogComponent implements OnInit {
  @Input() company :CompanyRelationshipDto;
  @Input() parentCompany:string;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  relationships;
  constructor(private _crmService:CrmService) {
  }

  ngOnInit(): void {
    this._crmService.GetRelationships().then(relationships => {
      this.relationships = [];
      relationships.forEach(org => {
        this.relationships.push({
          label: org.codeName,
          value: org.codeId
        })
      })
    })
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    this.showDialog = false;
    this.onSubmitDialog.emit(this.company);
    this.onDialogHide.emit()

  }
}
