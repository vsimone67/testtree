import { CustomerPerceptionDto } from './customerPerceptionDto';
import { ProductAllocationDto } from './productAllocationDto';

export interface GeneraliProductAllocationDto {
    companyId: string;
    salesPlanGroupId: string;
    customerPerceptionId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    customerPerception: CustomerPerceptionDto;
    productAllocation: ProductAllocationDto;
}