import { loadRemoteModule } from '@angular-architects/module-federation';
import { Routes } from '@angular/router';
import { NotFoundComponent } from '../components/not-found/not-found.component';

export const APP_ROUTES: Routes = [
    // Your routes here:
    {
      path: 'flights',

      loadChildren: () =>
        loadRemoteModule({
          remoteEntry: 'http://localhost:4600/remoteEntry.js',
          remoteName: 'mfe1',
          exposedModule: './Module'
        })
        .then(m => m.FlightsModule)
    },
    {
      path: '**',
      component: NotFoundComponent
    }

    // DO NOT insert routes after this one.
    // { path:'**', ...} needs to be the LAST one.

];

