import { Component, OnInit } from "@angular/core";
import { AssumedService } from "@assumed/service/assumed.service";
import { ActivatedRoute } from "@angular/router";
import { CessionPoolBindingOverrideModel } from "@assumed/models/CessionPoolBindingOverrideModel";
import { RetroService } from "@retro/service/retro.service";
import { ColDef } from "ag-grid-community";
import { SiteConstants } from "@constants/siteConstants";
import { CessionSearchResult } from "@assumed/models/CessionSearchResult";
import { formatDate } from "@shared/componentsgrid/formatters/formatDate";
import { formatCurrency } from "@shared/componentsgrid/formatters/formatCurrency";
import { CommonService } from "@shared/service/common.service";
import { DropPair } from "@shared/models/dropPair";
import { CrmService } from "@shared/service/crm.service";
import { TreatyService } from "@shared/service/treaty.service";
import { ConfirmationService, MessageService } from "primeng";
import { User } from "@auth/models/user";
import { DatePipe } from "@angular/common";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { RollbackService } from "@shared/service/rollback.service";
import { AssumedRollbackAggregatorService } from "@assumed/service/assumed-rollback-aggregator.serivce";
import { AssumedAggregatorService } from "@shared/service/assumedAggregatorService";
import { CessionPoolBindingOverrideAggregateModel } from "@assumed/models/CessionPoolBindingOverrideAggregateModel";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";

@Component({
  selector: "cession-pool-binding-overrides",
  templateUrl: "./cession-pool-binding-overrides.component.html",
  styleUrls: ["./cession-pool-binding-overrides.component.css"],
  providers: [DatePipe],
})
export class CessionPoolBindingOverridesComponent implements OnInit {
  cessionId: string;
  poolList: Array<CessionPoolBindingOverrideModel>;
  cessionInfo: string;
  columns: ColDef[];
  retroPool: Array<DropPair>;
  Naarsplits: Array<DropPair>;

  rowtoEdit: CessionPoolBindingOverrideModel;
  currentData: Array<CessionPoolBindingOverrideModel>;
  errors: { key: string; value: string }[];
  isAdmin: boolean;

  constructor(
    private _assumedService: AssumedService,
    private commonService: CommonService,
    private crmService: CrmService,
    private treatyService: TreatyService,
    private message: ConfirmationService,
    private datePipe: DatePipe,
    private assumedAggregator: AssumedAggregatorService,
    private _confirmService: ConfirmationService,
    private _rollbackService: RollbackService,
    private _assumedRollback: AssumedRollbackAggregatorService,
    private _route: ActivatedRoute,
    private _retroService: RetroService,
    private _messageService: MessageService
  ) {}

  async ngOnInit() {
    this.cessionId = this._route.snapshot.paramMap.get("id");
    this.columns = this.prepareColumns();
    var storedCession = JSON.parse(
      localStorage.getItem(SiteConstants.cessionLocalStorage)
    ) as CessionSearchResult;
    this.cessionInfo = `${storedCession.insuredFullName} ${storedCession.completePolicyNumber}`;
    this.refreshData();
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.isAdmin = LifeLineRoleCheck.isCessionDetailWrite();
    this.populateData();
  }

  populateData() {
    this.commonService.getNaarSplitTypes().then((liste) => {
      this.Naarsplits = [];
      this.Naarsplits.push({
        label: null,
        value: null,
      });
      liste.forEach((split: any) => {
        if (split) {
          this.Naarsplits.push({
            label: split.codeName,
            value: split.codeId,
          });
        }
      });
    });
    this._retroService.getAllRetroPools().then((retropools) => {
      this.retroPool = [];
      this.retroPool.push({
        label: null,
        value: null,
      });
      retropools.forEach((pool: any) => {
        if (pool) {
          this.retroPool.push({
            label: pool.poolName,
            value: pool.retroPoolId,
          });
        }
      });
    });
  }

  prepareColumns() {
    return <ColDef[]>[
      {
        field: "effectiveDate",
        headerName: "Effective Date",
        valueFormatter: formatDate,
        editable: true,
      },
      {
        field: "cancelDate",
        headerName: "Cancel Date",
        editable: true,
        valueFormatter: formatDate,
      },
      {
        field: "retroPoolId",
        editable: true,
        cellEditor: "agRichSelectCellEditor",
        headerName: "Retro Pool",
      },
      {
        field: "retroTreatyId",
        editable: true,
        headerName: "Retro Treaty",
      },
      {
        field: "poolMemberCompanyId",
        editable: true,
        headerName: "Retro Company",
      },
      {
        field: "narsplitTypeId",
        editable: true,
        headerName: "Naar Split Type",
      },
      {
        field: "maxBindingAmount",
        editable: true,
        headerName: "Max Binding Amount",
        valueFormatter: formatCurrency,
      },
      {
        field: "comment",
        editable: true,
        headerName: "Comment",
      },

      {
        headerName: "",
        field: "edit",
        width: 15,
      },
      {
        headerName: "",
        field: "rollback",
        width: 15,
      },
    ];
  }

  deletePoolBinding(cell, index) {
    if (!cell.cessionPoolBindingOverrideId) {
      this.poolList.splice(index, 1);
    } else {
      this.message.confirm({
        message: "Do you want to delete this record?",
        header: "Delete Confirmation",
        icon: "pi pi-info-circle",
        rejectButtonStyleClass: "cleardata",
        accept: () => {
          this.confirmeDelete(cell);
        },
        reject: () => {},
      });
    }
  }

  confirmeDelete(cell) {
    delete cell.companies;
    delete cell.treatiesForapool;
    this._assumedService
      .deleteRetroPoolBindingOverride(cell)
      .then((data) => this.refreshData())
      .finally(() =>
        this._messageService.add({
          severity: "success",
          detail: "Retro Binding Override has been deleted",
        })
      );
  }

  getTreaties(poolId, pool) {
    this._retroService.getRetroTreaties(poolId).then((liste) => {
      pool.treatiesForapool = [];
      pool.treatiesForapool.push({
        label: null,
        value: null,
      });
      liste.forEach((treaty: any) => {
        if (treaty) {
          pool.treatiesForapool.push({
            label: treaty.treatyNumber,
            value: treaty.retroTreatyId,
          });
        }
      });
      if (pool.retroTreatyId) this.updateCompanies(pool.retroTreatyId, pool);
    });
  }

  updateCompanies(treatyID, pool: CessionPoolBindingOverrideModel) {
    this.treatyService.getTreatyPlanBasicInfo(treatyID).then((data) => {
      pool.companies = [];
      pool.companies.push({ value: null, label: null });
      data.forEach((company: any) => {
        if (company) {
          pool.companies.push({
            value: company.companyId,
            label: company.responsibleCompanyName,
          });
        }
      });
    });
  }

  addPoolOverride() {
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.rowtoEdit = <CessionPoolBindingOverrideModel>{};
    this.rowtoEdit.createdBy = currentUser.userId;
    this.rowtoEdit.cessionId = this.cessionId;
    this.rowtoEdit.createDate = new Date();
    this.poolList.unshift(this.rowtoEdit);
  }

  savePools() {
    this.errors = [];
    let missingpool: boolean = false;
    let missingTreaty: boolean = false;
    let missingcompany: boolean = false;
    let missingsplit: boolean = false;
    let missingbinding: boolean = false;
    this.poolList.forEach((pool: any) => {
      if (!pool.retroPoolId) {
        missingpool = true;
      }
      if (!pool.retroTreatyId) {
        missingTreaty = true;
      }
      if (!pool.narsplitTypeId) {
        missingsplit = true;
      }
      if (!pool.poolMemberCompanyId) {
        missingcompany = true;
      }
      if (!pool.maxBindingAmount) {
        missingbinding = true;
      }
    });
    if (missingpool) {
      this.errors.push({
        key: "pool Missing ",
        value: "Retro Pool is required.",
      });
    }
    if (missingcompany) {
      this.errors.push({
        key: "company Missing ",
        value: "Retro Company is required.",
      });
    }
    if (missingTreaty) {
      this.errors.push({
        key: "treaty Missing ",
        value: "Retro Treaty is required.",
      });
    }
    if (missingsplit) {
      this.errors.push({
        key: "Split Missing ",
        value: "NAAR Split Type is required.",
      });
    }
    if (missingbinding) {
      this.errors.push({
        key: "binding Missing ",
        value: "Max Binding Amount is required.",
      });
    }
    if (this.errors.length === 0) {
      this.currentData.forEach((data) => {
        delete data.companies;
        delete data.treatiesForapool;
      });
      let addedList = this.poolList.filter(
        (pool: any) => pool.cessionPoolBindingOverrideId == null
      );
      let updatedList = this.poolList.filter(
        (pool: any) => pool.cessionPoolBindingOverrideId != null
      );
      let i = 0;
      addedList.forEach((data) => {
        this._assumedService
          .AddRetroPoolBindingOverride(data)
          .then((t) => {
            i++;
            if (i === this.poolList.length) {
              this.refreshData();
            }
          })
          .finally(() =>
            this._messageService.add({
              severity: "success",
              detail: "Retro Binding has been added",
            })
          );
      });
      updatedList.forEach((data: any) => {
        let oldData = this.currentData.filter(
          (pool) =>
            pool.cessionPoolBindingOverrideId ===
            data.cessionPoolBindingOverrideId
        )[0];
        delete data.companies;
        delete data.treatiesForapool;
        if (!this.compareFn(oldData, data)) {
          let newObject = { ...data };
          newObject.effectiveDate = this.datePipe.transform(
            data.effectiveDate,
            "yyyy-MM-ddTHH:mm:SS"
          );
          newObject.cancelDate = this.datePipe.transform(
            data.cancelDate,
            "yyyy-MM-ddTHH:mm:SS"
          );
          let aggregateData: CessionPoolBindingOverrideAggregateModel = {
            CurrentValue: oldData,
            NewValue: newObject,
          };
          this.assumedAggregator
            .EditPoolBindingOverride(aggregateData)
            .then((t) => {
              i++;
              if (i === this.poolList.length) {
                this.refreshData();
                this._messageService.add({
                  severity: "success",
                  detail: "Retro Binding has been updated",
                });
              }
            });
        } else {
          i++;
          if (i === this.poolList.length) {
            this.refreshData();
            this._messageService.add({
              severity: "success",
              detail: "Retro Binding has been updated",
            });
          }
        }
      });
    }
  }

  compareFn(old, newval) {
    let equals = true;
    if (old && !newval) return false;
    if (!old && newval) return false;
    Object.keys(old).forEach((key) => {
      if (key !== "effectiveDate" && key !== "cancelDate") {
        if (old[key] !== newval[key]) equals = false;
      }
    });
    return equals;
  }

  async refreshData() {
    this.poolList = await this._assumedService.getRetroPoolBindingOverride(
      this.cessionId
    );
    this.currentData = [];
    this.poolList.forEach((data) => {
      data.effectiveDate = new Date(data.effectiveDate);
      data.cancelDate = new Date(data.cancelDate);
      this._rollbackService
        .hasRollback(data.cessionPoolBindingOverrideId, "PoolBindingOverride")
        .then((rollback: any) => {
          data.hasRollback = rollback.hasRollback;
        });
      if (data.retroPoolId) this.getTreaties(data.retroPoolId, data);
      this.currentData.push(Object.assign({}, data));
    });
  }

  rollback(pool) {
    this._confirmService.confirm({
      message: "Are you sure you want to Rollback ?",
      header: "Rollback",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key: "pool",
      accept: () => {
        this._assumedRollback
          .rollbackCessionPoolBindingOverride(pool.cessionPoolBindingOverrideId)
          .then((data) => {
            this._messageService.add({
              severity: "success",
              detail: "Rollback done successfully",
            });
            this.refreshData();
          });
      },
    });
  }
}
