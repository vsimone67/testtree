import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CodeAdminComponent } from '../code/components/code-admin/code-admin.component';
import { CoreComponent } from './core/core.component';
import { EmptyComponent } from './empty/empty.component';
import { GroupsContainerComponent } from '../groups/components/groups-container/groups-container.component';
import { OpsteamContainerComponent } from '../opsteam/components/opsteam-container/opsteam-container.component';
import { RatesContainerComponent } from '../rates/components/rates-container/rates-container.component';
import { RegionsContainerComponent } from '../region/components/regions-container/regions-container.component';
import { RolesContainerComponent } from '../roles/components/roles-container/roles-container.component';

const routes: Routes = [
  {
    path: 'admin',
    component: CoreComponent,
    children: [
      { path: 'codeAdmin', component: CodeAdminComponent },
      { path: 'groups', component: GroupsContainerComponent },
      { path: 'regions', component: RegionsContainerComponent },
      { path: 'rate', component: RatesContainerComponent },
      { path: 'opsteam', component: OpsteamContainerComponent },
      { path: 'roles', component: RolesContainerComponent },
    ],
  },
  { path: '**', component: EmptyComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [],
})
export class AppRoutingModule {}
