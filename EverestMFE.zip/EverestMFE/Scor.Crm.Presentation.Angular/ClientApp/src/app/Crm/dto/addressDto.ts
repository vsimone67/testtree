import {CodeDto} from './codeDto';
import {DemographicInfoGroupDto} from './demographicInfoGroupDto';

export interface AddressDto {
  addressId: string;
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  addressLine4: string;
  addressTypeId: string;
  attentionTo: string;
  city: string;
  countryId: string | null;
  demographicInfoGroupId: string | null;
  isPrimaryAddress: boolean | null;
  latitude: number | null;
  longitude: number | null;
  postalCode: string;
  postOfficeBox: string;
  provinceId: string | null;
  stateId: string | null;
  timeZoneId: string | null;
  zipCode4: string;
  zipCode5: string;
  createDate: string | null;
  createdBy: string | null;
  modifiedDate: string | null;
  modifiedBy: string | null;
  moduleReference: string | null;
  rowStatusId: string | null;
  addressType: CodeDto;
  demographicInfoGroup: DemographicInfoGroupDto;
  state: CodeDto;
  country: CodeDto;
  province: CodeDto;
}
