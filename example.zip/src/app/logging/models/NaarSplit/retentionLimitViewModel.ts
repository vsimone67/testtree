export interface RetentionLimitViewModel {
    baseNAARAmount: number | null;
    baseReinsuredAmount: number | null;
    issueAge: number | null;
    reinsuranceDuration: number | null;
    maxGradedRetentionLimit: number;
    tableNumber: number | null;
    isExcludedFromRetention: boolean | null;
    jointType: string;
}