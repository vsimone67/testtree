import { Component, NgZone, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.css'],
})
export class MainMenuComponent implements OnInit {
  public items: MenuItem[];
  constructor() {
    this.items = [];
  }

  ngOnInit(): void {

  }


}
