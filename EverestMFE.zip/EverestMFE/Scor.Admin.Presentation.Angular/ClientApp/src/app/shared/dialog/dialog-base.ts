import { Output, EventEmitter, Component, Input } from '@angular/core';
import { EventService } from '@scor/common';

@Component({
  template: '',
})
export class DialogBase {
  @Output() onDialogHide: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Input() disabled: boolean = false;
  showDialog: boolean = true;
  _eventService: EventService;
  constructor() {}

  ngOnInit(): void {}

  hideDialog() {
    this.onDialogHide.emit(true);
  }
}
