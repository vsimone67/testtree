import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { User } from "@auth/models/user";
import { CessionUpdateInfo } from "@retro/models/CessionUpdateInfo";
import { VwInsuredCessionSearch } from "@retro/models/VwInsuredCessionSearchModel";
import { RetroService } from "@retro/services/retro.service";
import { formatDate } from "@shared/components/grid/formatters/formatDate";
import { GenericGridComponent } from "@shared/components/grid/generic-grid/generic-grid.component";
import { GetNotesByParentAndGroupCriteria } from "@shared/models/GetNotesByParentAndGroupCriteria";
import { NoteModel } from "@shared/models/NoteModel";
import { CommonService } from "@shared/services/common.service";
import { ColDef } from "ag-grid-community";
import { ConfirmationService, MessageService } from "primeng";
import { SiteConstants } from "@constants/siteConstants";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { RetroAggregatorService } from "@shared/services/retroAggregator.service";
import { CessionUpdateInfoAggregate } from "@retro/models/CessionUpdateInfoAggregate";
import { RollbackService } from "@shared/service/rollback.service";
import { RetroRollbackAggregatorService } from "@retro/services/retro-rollback-aggregator.service";
import { DropPair } from "@shared/models/dropPair";
import { DatePipe } from "@angular/common";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";
import { THIS_EXPR } from "@angular/compiler/src/output/output_ast";
import { GuidConstants } from "@constants/guidConstants";

@Component({
  selector: "cession-update",
  templateUrl: "./cession-update.component.html",
  styleUrls: ["./cession-update.component.css"],
})
export class CessionUpdateComponent implements OnInit {
  @ViewChild(GenericGridComponent, { static: false }) grid;

  //insuredInfoList: Array<VwInsuredCessionSearch>;
  insuredInfo: CessionUpdateInfo;
  currentInsuredInfo: CessionUpdateInfo;
  noteList: Array<NoteModel>;
  cessionId: string;

  columnList: Array<ColDef>;
  isAdmin: boolean;
  canEditCompany: boolean;
  rollBackUpdate: any = null;
  errors: string;
  types: Array<DropPair>;

  extendMessage: string;
  commitOff: boolean;

  constructor(
    private _retroSerivce: RetroService,
    private _commonService: CommonService,
    private datePipe: DatePipe,
    private _rollbackService: RollbackService,
    private _rollbackAggregator: RetroRollbackAggregatorService,
    private _RetroAggregatorService: RetroAggregatorService,
    private _route: ActivatedRoute,
    private _messageService: MessageService,
    private _confirmService: ConfirmationService
  ) {
    this.insuredInfo = <CessionUpdateInfo>{}; // stop undefined error on page load
  }

  async ngOnInit() {
    this.cessionId = this._route.snapshot.paramMap.get("id");
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.isAdmin = LifeLineRoleCheck.isCessionDetailWrite();
    this.canEditCompany = LifeLineRoleCheck.canEditCompany();
    this.populateData();
    this.columnList = this.getColumns();
    this.extendMessage = ""; // this is used let the user know they cannot extend the cession because the commit is off
    this.commitOff = false;
  }
  populateTypes() {
    if (this.insuredInfo.isActive) {
      this.types = [
        { value: "REN", label: "REN" },
        { value: "TRM", label: "TRM" },
        { value: "DTH", label: "DTH" },
      ];
    } else {
      this.types = [{ value: "REI", label: "REI" }];
    }
  }
  paidToDate: Date;
  async populateData() {
    this._retroSerivce.getRetroInsuredInfo(this.cessionId).then((data) => {
      var currentUser: User = JSON.parse(
        localStorage.getItem(SiteConstants.UserToken)
      );
      this.insuredInfo = data;
      this.insuredInfo.addToWarningExemptionList = false;
      this.insuredInfo.userName = currentUser.userName;

      this.populateTypes();
      // default txn type
      this.insuredInfo.transactionType = this.types[0].value.toString();

      this.currentInsuredInfo = { ...this.insuredInfo }; // Save the current state to pass to the rollback service (Make clone)
      this.insuredInfo.paidToDate = new Date(this.insuredInfo.paidToDate);
      this.paidToDate = new Date(this.insuredInfo.paidToDate);
      var criteria = <GetNotesByParentAndGroupCriteria>{
        ParentId: this.cessionId,
        NoteGroup: "Notes from Cession Update Screen",
      };
      this._commonService
        .getNotes(criteria)
        .then((data) => (this.noteList = data));
    });
    this.rollBackUpdate = await this._rollbackService.hasRollback(
      this.cessionId,
      "CessionUpdate"
    );

    var configSetting = await this._commonService.getConfiguationSettings(
      GuidConstants.commitConfigSetting
    );

    if (
      configSetting.configurationValue != null &&
      configSetting.configurationValue === "0"
    ) {
      this.extendMessage =
        "Commit has been disabled, cannot extend the cession";
      this.commitOff = true;
    }
  }
  saveRetroCession() {
    this.errors = null;
    if (
      this.insuredInfo.uniquePlanNumber &&
      this.insuredInfo.uniquePlanNumber.trim().length > 0 &&
      this.insuredInfo.coverageNumber &&
      this.insuredInfo.coverageNumber.trim().length > 0 &&
      this.insuredInfo.cessionSequence &&
      this.insuredInfo.cessionSequence.trim().length > 0
    ) {
      this.errors = "Please enter either CVG/SEQ or UPN, not both.";
    } else {
      var currentUser: User = JSON.parse(
        localStorage.getItem(SiteConstants.UserToken)
      );
      this.insuredInfo.paidToDate = this.datePipe.transform(
        this.insuredInfo.paidToDate,
        "yyyy-MM-ddTHH:mm:SS"
      );
      if (
        !this.insuredInfo.note ||
        (this.insuredInfo.note && this.insuredInfo.note.trim().length === 0)
      ) {
        this.insuredInfo.note = "Update Extended Cession Informations";
      }
      var aggregatedCessionUpdateInfo = <CessionUpdateInfoAggregate>{
        newValue: this.insuredInfo,
        currentValue: this.currentInsuredInfo,
      };

      this.insuredInfo.modifiedById = currentUser.userId;
      this.currentInsuredInfo.modifiedById = currentUser.userId;
      this._RetroAggregatorService
        .saveCessionInsuredInfo(aggregatedCessionUpdateInfo)
        .then((exp) => {
          this._messageService.add({
            severity: "success",
            detail: "Cession has been updated",
          });
          // this.updateGrid(note);
          this.populateData();
        });
    }
  }

  updateGrid(note) {
    this.grid.gridApi.updateRowData({ add: [note] });
    this.noteList.push(note);
  }

  getColumns() {
    return [
      {
        headerName: "Note",
        field: "noteText",
      },
      {
        headerName: "Note Date",
        field: "noteCreateDate",
        valueFormatter: formatDate,
      },
      {
        headerName: "Created By",
        cellRenderer: (params) =>
          `${params.data.noteCreatedByFirstName} ${params.data.noteCreatedByLastName}`,
      },
    ];
  }

  refreshData() {
    // this._retroSerivce.getRetroInsurcedInfo(this.cessionId).then((data) => {
    //   this.insuredInfoList = data;

    //   if (this.insuredInfoList.length > 0) {
    //     this.insuredInfo = <CessionUpdateInfo>{
    //       insuredId: this.insuredInfoList[0].insuredId,
    //       cessionId: this.insuredInfoList[0].cessionId,
    //       companyName: this.insuredInfoList[0].companyName,
    //       cCedingCompanyId: this.insuredInfoList[0].cCedingCompanyId,
    //       policyNumber: this.insuredInfoList[0].policyNumber,
    //       coverageNumber: this.insuredInfoList[0].coverageNumber,
    //       cessionSequence: this.insuredInfoList[0].cessionSequence,
    //       addToWarningExemptionList: false,
    //       uniquePlanNumber: this.insuredInfoList[0].uniquePlanNumber,
    //       firstName: this.insuredInfoList[0].insuredFirstName,
    //       lastName: this.insuredInfoList[0].insuredLastName,
    //       middleInitial: this.insuredInfoList[0].insuredMiddleInitial
    //     }
    //     var criteria = <GetNotesByParentAndGroupCriteria>{ ParentId: this.cessionId, NoteGroup: "Notes from Cession Update Screen" };
    //     this._commonService.getNotes(criteria).then((data) => this.noteList = data);
    //   }
    // });
    this.populateData();
  }

  rollBackData() {
    this._confirmService.confirm({
      message: "Are you sure you want to rollback this cession update?",
      header: "Rollback",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key: "cessionUpdate",
      accept: () => {
        this._rollbackAggregator
          .rollbackCessionUpdate(this.cessionId)
          .then((data) => {
            this._messageService.add({
              severity: "success",
              detail: "Rollback done successfully",
            });
            this.populateData();
          });
      },
    });
  }
}
