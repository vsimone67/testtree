export interface MembershipModel {
    codeId: string;
    codeName: string;
}