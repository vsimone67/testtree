import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CodeAdminComponent } from './components/code-admin/code-admin.component';
import { CodeEditDailogComponent } from './components/dialogs/code-edit-dailog/code-edit-dailog.component';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [CodeAdminComponent, CodeEditDailogComponent],
  imports: [CommonModule, SharedModule],
})
export class CodeModule {}
