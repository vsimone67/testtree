import { Injectable } from '@angular/core';
import { HttpService } from '../../../services/http/http-service.service';
import { CodeDto } from '../models/codeModel';
import { serviceBase } from './servicebase';

@Injectable({
  providedIn: 'root',
})
export class CodeService extends serviceBase {
  private _codeUrl!: string;

  get codeUrl(): string {
    return this._codeUrl;
  }
  set codeUrl(value: string) {
    this._codeUrl = value;
  }

  constructor(private httpService: HttpService) {
    super(httpService);
  }

  async getCodesByCategoryId(categoryId: string, status: string) {
    return await this._httpService.getData<Array<CodeDto>>(
      `${this._codeUrl}/GetCategoryById/${categoryId}/${status}`
    );
  }
}
