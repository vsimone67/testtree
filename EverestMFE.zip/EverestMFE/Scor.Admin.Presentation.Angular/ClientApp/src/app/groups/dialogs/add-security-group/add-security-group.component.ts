import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { GroupModel } from '../../models/group-model';
import { SecurityGroupsService } from '../../services/security-groups.service';

@Component({
  selector: 'app-add-security-group',
  templateUrl: './add-security-group.component.html',
  styleUrls: ['./add-security-group.component.css'],
})
export class AddGroupsComponent
  extends EditDialogBase<GroupModel>
  implements OnInit
{
  showDialog: boolean = true;
  @Input() currency;
  @Input() showAll: boolean;
  groupName;
  codeDescription;
  codeValue;

  constructor(private groupsService: SecurityGroupsService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {}

  async saveAddTeamMember() {
    await this.groupsService.addSecurityGroup(
      this.groupName,
      this.codeDescription,
      this.codeValue,
      'E0DBB8E9-C449-4A99-9731-7D903B2ADFFA'
    );
    this.submitDialog();
    this.hideDialog();
  }
}
