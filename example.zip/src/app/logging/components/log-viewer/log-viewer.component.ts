import { Component, NgZone, OnDestroy, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { NaarSplitRootViewModel } from "../../models/NaarSplit/naarSplitRootViewModel";
import { SiteConstants } from "@constants/siteConstants";
import { CessionSearchResult } from "@assumed/models/CessionSearchResult";
import { NodeConstants } from "@constants/nodeConstants";
import { CessionHistoryViewModel } from "../../models/NaarSplit/cessionHistoryViewModel";
import { EventService } from "@shared/service/event.service";
import { events } from "@constants/events.model";
import { SplitAnalysisViewModel } from "../../models/NaarSplit/SplitAnalysisViewModel";
import { SplitsService } from "@retro/services/splits.service";
import { CessionViewModel } from "../../models/NaarSplit/cessionViewModel";
import { CessionSearchModel } from "@assumed/models/CessionSearchmodel";
import { AssumedService } from "@assumed/services/assumed.service";
import { SignalrHubService } from "@shared/services/signalr-hub.service";
import { MessageService } from "primeng";
import { AppSettingsService } from "@shared/services/app-settings.service";
import { NaarSplitGenerateInfo } from "../../models/NaarSplit/NaarSplitGenerateInfo";
import { DatePipe } from "@angular/common";
import * as signalR from "@microsoft/signalr";

@Component({
  selector: "app-log-viewer",
  templateUrl: "./log-viewer.component.html",
  styleUrls: ["./log-viewer.component.css"],
})
export class LogViewerComponent implements OnInit, OnDestroy {
  cessionId: string; // Cession Id to pass to the Naar Split Service (this comes from cession search screen or Everest, it is passed on the route (id))
  asOfDate: Date; // As of date to pass to the Naar Split service
  naarSplitInfo: NaarSplitRootViewModel; // View model to hold data retrieved from Naar Split service
  showGraph: boolean = false; // show person-split-viewer component
  showPersonData: boolean = false; // show data coming from cession search screen (if from Everest this will be blank)
  cessionData: CessionSearchResult; // data coming from cession search screen to show on screen
  showSplitDetail: boolean = false; // show split-detail component
  currentCessionHistory: CessionHistoryViewModel; // selected cession history
  currentCession: CessionViewModel; // current selected Cession
  splitsAnalysisList: Array<SplitAnalysisViewModel>; // split analys list user is creating by  adding each history's
  historyDate;
  cessionNumber: string;
  minMonth: number;
  maxMonth: number;
  monthLabel: string;
  showSplitAnalysis: boolean = false;
  searchVisible: boolean = true;
  hasDisconnected: boolean;

  constructor(
    private _splitService: SplitsService,
    private _route: ActivatedRoute,
    private zone: NgZone,
    private _eventService: EventService,
    private _router: Router,
    private _assumedService: AssumedService,
    private _messageService: MessageService,
    private _appSettingsService: AppSettingsService,
    private _splitConnection: SignalrHubService,
    private datePipe: DatePipe
  ) {}

  async ngOnInit() {
    this.splitsAnalysisList = [];
    this.cessionId = this._route.snapshot.paramMap.get("id"); // get ID that will be passeed from the Everest App

    if (this.cessionId !== null) {
      // if value is not undefined, the page was called from Everest
      var searchModel = <CessionSearchModel>{ CessionId: this.cessionId };
      var searchResult = await this._assumedService.searchCession(searchModel);

      // set the current cession info to local storage so the logging screen can ue some of the info
      localStorage.removeItem(SiteConstants.cessionLocalStorage);
      localStorage.setItem(
        SiteConstants.cessionLocalStorage,
        JSON.stringify(searchResult[0])
      );
    }

    var storedCession = localStorage.getItem(SiteConstants.cessionLocalStorage);

    // if true the data has come from the cession search screen (not everest) so show some of the data on the screen
    if (storedCession) {
      this.cessionData = JSON.parse(
        localStorage.getItem(SiteConstants.cessionLocalStorage)
      ) as CessionSearchResult;
      this.showPersonData = true;
    } else {
      this.showPersonData = false; // came from Everest, we do not have this data stored
    }

    this.hasDisconnected = false; // set the disconnect flag to Split Signalr hub to false
    // connect to the retro signlar hub for notifications
    await this.CreateSplitHubConnection();
  }

  ngOnDestroy(): void {
    // remove handlers from connection
    this._splitConnection.Hub.off(SiteConstants.splitErrorEvent);
    this._splitConnection.Hub.off(SiteConstants.splitGeneratedEvent);
    // terminte connection
    this._splitConnection.DisConnect();
  }
  async CreateSplitHubConnection() {
    this._splitConnection.URL = this._appSettingsService.GetValue(
      "splitHubUrl"
    );

    await this._splitConnection.Connect();

    if (this._splitConnection.IsConnected) {
      this.RegisterSplitEvents();
    } else {
      this._messageService.add({
        severity: "error",
        detail: "Unable to connect to Split Hub",
      });
    }
  }

  protected RegisterSplitEvents(): void {
    // subscribe to split error
    this._splitConnection.Hub.on(
      SiteConstants.splitErrorEvent,
      (errorText: string) => {
        this._eventService.sendEvent(events.loadingEvent, false); // turn off loading spinner
        var message = `Error From Split Generation: ${errorText}`;
        this._messageService.add({
          severity: "error",
          detail: message,
          sticky: true,
        });
      }
    );

    // subscribe to generated split
    this._splitConnection.Hub.on(
      SiteConstants.splitGeneratedEvent,
      (naarSplit: NaarSplitRootViewModel) => {
        this._eventService.sendEvent(events.loadingEvent, false); // turn off loading spinner
        this.updateSplitData(naarSplit); // Update the Split Viewer with the data returned
      }
    );

    // register reconnection event
    this._splitConnection.Hub.onreconnecting((error) => {
      this.hasDisconnected = true; // set the flag to disconnected, if true when onclose is called then we show an error message

      if (
        this._splitConnection.Hub.state ===
        signalR.HubConnectionState.Reconnecting
      ) {
        this._messageService.add({
          severity: "warn",
          detail: "Split Hub Connection Lost...Reconnecting",
        });
      }
    });

    this._splitConnection.Hub.onreconnected((connectionId) => {
      if (
        this._splitConnection.Hub.state === signalR.HubConnectionState.Connected
      ) {
        this.hasDisconnected = false; // sucessfully reconnected, set flag back to false
        this._messageService.add({
          severity: "success",
          detail: "Split Hub Re-Connected",
        });
      }
    });

    this._splitConnection.Hub.onclose((connectionId) => {
      // onclose will be called when we close the connection to the hub, we only want to show this message when we disconnected and could not re-establish the connection
      if (this.hasDisconnected) {
        this._messageService.add({
          severity: "error",
          detail:
            "Split Hub Connection Disconected....Please restart your browser!",
          sticky: true,
        });
      }
    });
  }

  // ! This method is called from the Signlar R Hub Event in RegisterSplitEvents via the event "SplitGenerated"
  updateSplitData(listesplits: NaarSplitRootViewModel) {
    this.naarSplitInfo = listesplits;
    let min: string;
    let max: string;
    this.minMonth = null;
    this.maxMonth = null;
    listesplits.cessions.forEach((cession) => {
      cession.cessionHistories.forEach((history) => {
        if (
          !this.minMonth ||
          new Date(history.effectiveDate).getTime()<this.minMonth
        ) {
          this.minMonth = new Date(history.effectiveDate).getTime();
          min = new Date(history.effectiveDate).toLocaleDateString();
        }
        if (
          !this.maxMonth ||
          new Date(history.effectiveDate).getTime()>this.maxMonth
        ) {
          this.maxMonth = new Date(history.effectiveDate).getTime();
          max = new Date(history.effectiveDate).toLocaleDateString();
        }
      });
    });
    if (this.minMonth === this.maxMonth) this.maxMonth++;

    // sort by scorRetentionSequenceNumber
    this.naarSplitInfo.cessions.sort((a, b) => {
      // Sort by scorRetentionSequenceNumber
      // If the first item has a higher number, move it up
      // If the first item has a lower number, move it down
      if (a.scorRetentionSequenceNumber > b.scorRetentionSequenceNumber)
        return 1;
      if (b.scorRetentionSequenceNumber > a.scorRetentionSequenceNumber)
        return -1;
    });

    this.historyDate=[];
    this.historyDate[0]= new Date(this.minMonth).getTime();
    this.historyDate[1]= new Date(this.maxMonth).getTime();
    this.cessionNumber = null;
    this.monthLabel = null;

    this.showGraph = true;
    this.showSplitDetail = false;
  }

  async getNaarSplitInfo() {
    var dateString = `${this.datePipe.transform(this.asOfDate, "MM-dd-yyyy")}`; // transform the date to mmddyyyy
    var splitInfo = <NaarSplitGenerateInfo>{
      CessionId: this.cessionId,
      AsOfDate: dateString,
      ConnectionId: this._splitConnection.ConnectionId,
    };
    this._eventService.sendEvent(events.loadingEvent, true); // turn on loading spinner
    this._splitConnection.InvokeHubMethod("GenerateNaarSplit", splitInfo); // Generate and Get Naar Splits
  }

  // this is called when user selectes node
  nodeSelected(event) {
    if (event.data.metaData == NodeConstants.history) {
      if (!this.showSplitDetail) {
        this.showSplitDetail = true;
        this.currentCessionHistory = event.data.payload;
      } else {
        this.showSplitDetail = false;
        this.currentCessionHistory = <CessionHistoryViewModel>{};
      }
    } else if (event.data.metaData == NodeConstants.cession) {
      this.showSplitDetail = false;
      this.currentCession = event.data.payload;
    }
  }

  filterHistoryDate(date) {
      let mindate=new Date(this.historyDate[0])
    let maxdate=new Date(this.historyDate[1])
     if (mindate.getDate() === 0) mindate.setDate(1);
     if (maxdate.getDate() === 0) maxdate.setDate(1);
    this.monthLabel =
      (mindate.getMonth() +1)+
      "/" +
      mindate.getDate() +
      "/" +
      mindate.getFullYear()+' to '+
      (maxdate.getMonth() +1)+
      "/" +
      maxdate.getDate() +
      "/" +
      maxdate.getFullYear();

    this._eventService.sendEvent(
      events.historyEffectiveDateFilter,
      this.historyDate
    );
  }

  generateData() {
    this.splitsAnalysisList = [];
    this.naarSplitInfo.cessions.forEach((info) => {
      if (
        this.splitsAnalysisList.length === 0 ||
        this.splitsAnalysisList.filter(
          (analysis) => analysis.cessionNumber === info.cessionNumber
        ).length <= 0
      ) {
        let analysis = new SplitAnalysisViewModel();
        analysis.cessionNumber = info.cessionNumber;
        analysis.children = [];
        info.cessionHistories.forEach((history) => {
          let sp = history.splits;
          sp.splits.forEach((row) => analysis.children.push(row));
        });
        analysis.children = analysis.children.sort((a, b) =>
          a.effectiveDate > b.effectiveDate ? 1 : -1
        );
        if (analysis.children.length > 0)
          this.splitsAnalysisList.push(analysis);
      }
    });
    if (this.historyDate)
      this.splitsAnalysisList.forEach((analyis) => {
        analyis.children = analyis.children.filter(
          (cession) => new Date(cession.effectiveDate) <= this.historyDate
        );
      });
    if (this.cessionNumber)
      this.splitsAnalysisList = this.splitsAnalysisList.filter((analyis) =>
        analyis.cessionNumber.toString().includes(this.cessionNumber)
      );

    this.showSplitAnalysis = true;
  }

  hideSearch() {
    this.searchVisible = !this.searchVisible;
  }

  reset() {
    this.historyDate = null;
    this.cessionNumber = null;
    this.asOfDate = null;
    this.monthLabel = null;
    this.naarSplitInfo = null;
    this.showSplitDetail = false;
    this.showSplitAnalysis = false;
  }

  changeCessions(cession) {
    this._eventService.sendEvent(
      events.SCORSequenceFilter ,
      this.cessionNumber
    );
  }
}
