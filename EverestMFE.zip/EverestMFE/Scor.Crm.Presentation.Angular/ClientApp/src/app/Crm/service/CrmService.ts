import { Injectable } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { ActionPlanDto } from '../dto/actionPlanDto';
import { AddressDto } from '../dto/addressDto';
import { CompanyDto } from '../dto/companyDto';
import { CompanyRelationshipDto } from '../dto/companyRelationshipDto';
import { CompanyTargetDto } from '../dto/companyTargetDto';
import { CompanyThresholdVolumeDto } from '../dto/companyThresholdVolumeDto';
import { ContactDto } from '../dto/contactDto';
import { ContactRelationshipDto } from '../dto/contactRelationshipDto';
import { GeneraliAkaDto } from '../dto/generaliAkaDto';
import { PhoneNumberDto } from '../dto/phoneNumberDto';
import { SalesObjectiveDto } from '../dto/salesObjectiveDto';
import { SalesObstacleDto } from '../dto/salesObstacleDto';
import { StrategyDto } from '../dto/strategyDto';
import { UserRelationshipDto } from '../dto/userRelationshipDto';
import { MarketingListContactDto } from '../dto/marketingListContactDto';
import { MarketingListDto } from '../dto/marketingListDto';
import { SalesOpportunityDto } from '../dto/salesOpportunityDto';
import { AppSettingsService, HttpService } from '@scor/common';
import { CodeDto } from '../dto/codeDto';
import { EmployeeDto } from '../dto/employeeDto';

import { AddNoteDto } from '@scor/common/lib/components/notes/models/AddNoteDto';

@Injectable({
  providedIn: 'root',
})
export class CrmService {
  private _serviceUrl: string;
  private _codeUrl: string;
  private noteUrl: string;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this._serviceUrl = `${this._appSettingsService.GetValue('apiGatewayUrl')}/${
      SiteConstants.crmController
    }`;
    this._codeUrl = `${this._appSettingsService.GetValue('apiCodeurl')}/${
      SiteConstants.codeController
    }`;
    this.noteUrl = `${this._appSettingsService.GetValue('apiNoteurl')}`;
  }

  async AddActionPlan(dto: ActionPlanDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddActionPlan`,
      dto
    );
  }

  async AddAddress(dto: AddressDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddAddress`,
      dto
    );
  }

  async AddAka(dto: GeneraliAkaDto) {
    return await this._httpService.postData(`${this._serviceUrl}/AddAka`, dto);
  }

  async AddCompany(dto: CompanyDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddCompany`,
      dto
    );
  }

  async AddCompanyTarget(dto: CompanyTargetDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddCompanyTarget`,
      dto
    );
  }

  async AddCompanyTeamMember(dto: UserRelationshipDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddCompanyTeamMember`,
      dto
    );
  }

  async AddCompanyTreashold(dto: CompanyThresholdVolumeDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddCompanyTreashold`,
      dto
    );
  }

  async AddObjective(dto: SalesObjectiveDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddObjective`,
      dto
    );
  }

  async AddObstacle(dto: SalesObstacleDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddObstacle`,
      dto
    );
  }

  async AddOpportstringy(dto: SalesOpportunityDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddOpportunity`,
      dto
    );
  }

  async AddPhoneNumber(dto: PhoneNumberDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddPhoneNumber`,
      dto
    );
  }

  async AddStrategy(dto: StrategyDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddStrategy`,
      dto
    );
  }

  async DeleteActionPlan(actionPlanId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteActionPlan/${actionPlanId}`
    );
  }

  async DeleteAddress(addressId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteAddress/${addressId}`
    );
  }

  async DeleteAka(akaId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteAka/${akaId}`
    );
  }

  async DeleteCompany(companyId) {
    return await this._httpService.postData<string>(
      `${this._serviceUrl}/DeactivateCompany/${companyId}`,
      companyId
    );
  }
  async ActivateCompany(companyId) {
    return await this._httpService.postData<string>(
      `${this._serviceUrl}/ActivateCompany/${companyId}`,
      companyId
    );
  }

  async DeleteCompanyTarget(compnyTargetId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteCompanyTarget/${compnyTargetId}`
    );
  }

  async DeleteCompanyTeamMember(userRelationship: UserRelationshipDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/DeleteCompanyTeamMember/${userRelationship.companyId}`,
      userRelationship
    );
  }

  async DeleteCompanyTreashold(companyTresholdId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteCompanyTreashold/${companyTresholdId}`
    );
  }

  async DeleteObjective(objectiveId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteObjective/${objectiveId}`
    );
  }

  async DeleteObstacle(objectiveId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteObstacle/${objectiveId}`
    );
  }

  async DeleteOpportstringy(salesOpportunityId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteOpportunity/${salesOpportunityId}`
    );
  }

  async DeletePhoneNumber(phoneNumberId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeletePhoneNumber/${phoneNumberId}`
    );
  }

  async DeleteStrategy(strategyId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteStrategy/${strategyId}`
    );
  }

  async EditActionPlan(dto: ActionPlanDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditActionPlan`,
      dto
    );
  }

  async EditAddress(dto: AddressDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditAddress`,
      dto
    );
  }

  async EditAka(dto: GeneraliAkaDto) {
    return await this._httpService.postData(`${this._serviceUrl}/EditAka`, dto);
  }

  async EditCompany(dto: CompanyDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditCompany`,
      dto
    );
  }

  async EditCompanyTeamMember(dto: UserRelationshipDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditCompanyTeamMember`,
      dto
    );
  }

  async EditCompanyTreashold(dto: CompanyThresholdVolumeDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditCompanyTreashold`,
      dto
    );
  }

  async EditObjective(dto: SalesObjectiveDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditObjective`,
      dto
    );
  }

  async EditObstacle(dto: SalesObstacleDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditObstacle`,
      dto
    );
  }

  async EditOpportunity(dto: SalesOpportunityDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditOpportunity`,
      dto
    );
  }

  async EditPhoneNumber(dto: PhoneNumberDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditPhoneNumber`,
      dto
    );
  }

  async EditStrategy(dto: StrategyDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditStrategy`,
      dto
    );
  }

  async GetActionPlan(actionPlanId) {
    return await this._httpService.getData<ActionPlanDto>(
      `${this._serviceUrl}/GetActionPlan/${actionPlanId}`
    );
  }

  async GetAddress(addressId) {
    return await this._httpService.getData<AddressDto>(
      `${this._serviceUrl}/GetAddress/${addressId}`
    );
  }

  async GetAddressForDemoGroup(demoGroupId) {
    return await this._httpService.getData<Array<AddressDto>>(
      `${this._serviceUrl}/GetAddressForDemoGroup/${demoGroupId}`
    );
  }

  async GetAkaCompany(akaId) {
    return await this._httpService.getData<GeneraliAkaDto>(
      `${this._serviceUrl}/GetAkaCompany/${akaId}`
    );
  }

  async GetAkaForCompany(companyId) {
    return await this._httpService.getData<Array<GeneraliAkaDto>>(
      `${this._serviceUrl}/GetAkaForCompany/${companyId}`
    );
  }

  async GetAllCompanies() {
    return await this._httpService.getData<Array<CompanyDto>>(
      `${this._serviceUrl}/GetAllCompanies`
    );
  }

  async GetAllLegalEntites() {
    return await this._httpService.getData<Array<CompanyDto>>(
      `${this._serviceUrl}/GetAllLegalEntites`
    );
  }

  async GetCompaniesByName(companyName) {
    return await this._httpService.getData<Array<CompanyDto>>(
      `${this._serviceUrl}/GetCompanyByName/${companyName}`
    );
  }

  async GetCompany(companyId) {
    return await this._httpService.getData<CompanyDto>(
      `${this._serviceUrl}/GetCompany/${companyId}`
    );
  }

  async GetCompanyRelationships(parentId) {
    return await this._httpService.getData<Array<CompanyRelationshipDto>>(
      `${this._serviceUrl}/GetCompanyRelationships/${parentId}`
    );
  }

  async GetCompanyTarget(companyTargetId) {
    return await this._httpService.getData<CompanyTargetDto>(
      `${this._serviceUrl}/GetCompanyTarget/${companyTargetId}`
    );
  }

  async GetCompanyTargetsForCompany(companyId) {
    return await this._httpService.getData<Array<CompanyTargetDto>>(
      `${this._serviceUrl}/GetCompanyTargetsForCompany/${companyId}`
    );
  }

  async GetCompanyTreashold(companyTresholdId) {
    return await this._httpService.getData<CompanyThresholdVolumeDto>(
      `${this._serviceUrl}/GetCompanyTreashold/${companyTresholdId}`
    );
  }

  async GetCompanyTreasholdForCompany(companyId) {
    return await this._httpService.getData<Array<CompanyThresholdVolumeDto>>(
      `${this._serviceUrl}/GetCompanyTreasholdForCompany/${companyId}`
    );
  }

  async GetObjective(objectiveId) {
    return await this._httpService.getData<SalesObjectiveDto>(
      `${this._serviceUrl}/GetObjective/${objectiveId}`
    );
  }

  async GetPhoneNumber(phoneNumberId) {
    return await this._httpService.getData<PhoneNumberDto>(
      `${this._serviceUrl}/GetPhoneNumber/${phoneNumberId}`
    );
  }

  async GetPhoneNumberForDemoGroup(demoGroupId) {
    return await this._httpService.getData<Array<PhoneNumberDto>>(
      `${this._serviceUrl}/GetPhoneNumberForDemoGroup/${demoGroupId}`
    );
  }

  async GetRetroCompanies() {
    return await this._httpService.getData<Array<CompanyDto>>(
      `${this._serviceUrl}/GetRetroCompanies`
    );
  }

  async GetSalesActionPlanForStragegy(actionPlanId) {
    return await this._httpService.getData<Array<ActionPlanDto>>(
      `${this._serviceUrl}/GetSalesActionPlanForStragegy/${actionPlanId}`
    );
  }

  async GetSalesObjectiveForStragegy(stragegyId) {
    return await this._httpService.getData<Array<SalesObjectiveDto>>(
      `${this._serviceUrl}/GetSalesObjectiveForStragegy/${stragegyId}`
    );
  }

  async GetSalesObstacle(obstacleId) {
    return await this._httpService.getData<SalesObstacleDto>(
      `${this._serviceUrl}/GetSalesObstacle/${obstacleId}`
    );
  }

  async GetSalesObstacleForStragegy(stragegyId) {
    return await this._httpService.getData<Array<SalesObstacleDto>>(
      `${this._serviceUrl}/GetSalesObstacleForStragegy/${stragegyId}`
    );
  }

  async GetSalesOpportinity(opportstringyId) {
    return await this._httpService.getData<SalesOpportunityDto>(
      `${this._serviceUrl}/GetSalesOpportinity/${opportstringyId}`
    );
  }

  async GetSalesOpportinityForStragegy(stragegyId) {
    return await this._httpService.getData<Array<SalesOpportunityDto>>(
      `${this._serviceUrl}/GetSalesOpportinityForStragegy/${stragegyId}`
    );
  }

  async GetStrategiesForCompany(companyId) {
    return await this._httpService.getData<Array<StrategyDto>>(
      `${this._serviceUrl}/GetStrategiesForCompany/${companyId}`
    );
  }

  async GetStrategy(stragegyId) {
    return await this._httpService.getData<StrategyDto>(
      `${this._serviceUrl}/GetStrategy/${stragegyId}`
    );
  }

  async GetTeamMember(companyId, employeeId) {
    return await this._httpService.getData<UserRelationshipDto>(
      `${this._serviceUrl}/GetTeamMember/${companyId}/${employeeId}`
    );
  }

  async GetTeamMembesForCompany(companyId) {
    return await this._httpService.getData<Array<UserRelationshipDto>>(
      `${this._serviceUrl}/GetTeamMembesForCompany/${companyId}`
    );
  }

  async AddContact(dto: ContactDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddContact`,
      dto
    );
  }

  async AddContactRelationship(dto: ContactRelationshipDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddContactRelationship`,
      dto
    );
  }

  async AddCompanyRelationship(dto: CompanyRelationshipDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddCompanyRelationship`,
      dto
    );
  }

  async AddMarketingList(dto: MarketingListContactDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/AddMarketingList`,
      dto
    );
  }

  async DeleteContact(contactId) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteContact/${contactId}`
    );
  }

  async DeleteContactRelationship(id) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteContactRelationship/${id}`
    );
  }

  async DeleteMarketingList(id) {
    return await this._httpService.getData<string>(
      `${this._serviceUrl}/DeleteMarketingList/${id}`
    );
  }

  async EditContact(dto: ContactDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditContact`,
      dto
    );
  }

  async EditContactRelationship(dto: ContactRelationshipDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditContactRelationship`,
      dto
    );
  }

  async EditMarketingList(dto: MarketingListDto) {
    return await this._httpService.postData(
      `${this._serviceUrl}/EditMarketingList`,
      dto
    );
  }

  async GetAllContacts() {
    return await this._httpService.getData<Array<ContactDto>>(
      `${this._serviceUrl}/GetAllContacts`
    );
  }

  async GetAllMarketingLists() {
    return await this._httpService.getData<Array<MarketingListContactDto>>(
      `${this._serviceUrl}/GetAllMarketingLists`
    );
  }

  async GetContact(contactId) {
    return await this._httpService.getData<ContactDto>(
      `${this._serviceUrl}/GetContact/${contactId}`
    );
  }

  async GetContactRelationship(id) {
    return await this._httpService.getData<ContactRelationshipDto>(
      `${this._serviceUrl}/GetContactRelationship/${id}`
    );
  }

  async GetContactRelationshipsForContact(contactId) {
    return await this._httpService.getData<Array<ContactRelationshipDto>>(
      `${this._serviceUrl}/GetContactRelationshipsForContact/${contactId}`
    );
  }

  async GetMarketingList(id) {
    return await this._httpService.getData<MarketingListContactDto>(
      `${this._serviceUrl}/GetMarketingList/${id}`
    );
  }

  async GetOrganizationTypes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetCompanyOrganizationTypeCodes`
    );
  }

  async GetDivisions() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetGeneraliDivisionCodes`
    );
  }

  async GetIndividualOrSelfTypes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetIndividualOrSelfAdminTypeIdCodes`
    );
  }

  async GetAMBestRating() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetAMBestRatingCodes`
    );
  }

  async GetSPBestRating() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetS&PRatingCodes`
    );
  }

  async GetStates() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetStateCodes`
    );
  }

  async GetCountries() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetGenerali_CountryCodes`
    );
  }

  async GetProvinceCodes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetProvinceCodes`
    );
  }

  async GetCompanyStatus() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetCompanyStatusCodes`
    );
  }

  async GetObjectiveTypes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetSalesObjectiveTypeCodes`
    );
  }

  async GetObstacleTypes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetSalesObstacleTypeCodes`
    );
  }

  async GetOpportunityTypes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetSalesOpportunityTypeCodes`
    );
  }

  async GetThresholdTypes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetThresholdVolumeTypeCodes`
    );
  }

  async GetThresholdReasons() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetThresholdVolumeReasonCodes`
    );
  }

  async GetPhoneTypeCodes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetPhoneTypeCodes`
    );
  }

  async GetAddressTypeCodes() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetAddressTypeCodes`
    );
  }

  async GetRelationships() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetCompanyRelationshipRoleCodes`
    );
  }

  async GetAllEmployees() {
    return await this._httpService.getData<EmployeeDto[]>(
      `${this._serviceUrl}/GetAllEmployees`
    );
  }

  async GetRoles() {
    return await this._httpService.getData<CodeDto[]>(
      `${this._codeUrl}/GetUserRelationshipRoleCodes`
    );
  }
  async CreateNote(dto: AddNoteDto) {
    return await this._httpService.postData(`${this.noteUrl}/CreateNote`, dto);
  }
}
