import { Component, OnInit } from '@angular/core';
import { events } from '@constants/events.model';
import { EventService } from '@scor/common';
import { MessageService } from 'primeng/api';

@Component({
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  private loading: boolean = false;

  notesUrl: string;
  parentId: string;
  noteType: string;
  constructor(
    private messageService: MessageService,
    private _eventService: EventService
  ) {}

  columnDefs = [{ field: 'make' }, { field: 'model' }, { field: 'price' }];

  rowData = [
    { make: 'Toyota', model: 'Celica', price: 35000 },
    { make: 'Ford', model: 'Mondeo', price: 32000 },
    { make: 'Porsche', model: 'Boxter', price: 72000 },
  ];

  ngOnInit(): void {
    this.notesUrl = 'https://USVDEVEVRSTAS3:4351/note';
    this.parentId = 'e05583b6-b8c3-42cc-9487-adfe68baa64c';
    this.noteType = 'Notes from Cession General Screen';
  }

  onClick() {
    this.messageService.add({
      severity: 'success',
      summary: 'Success',
      detail: 'Message From app1',
    });
  }

  onLoading() {
    this.loading = !this.loading;

    this._eventService.sendEvent(events.loadingEvent, this.loading);
  }
}
