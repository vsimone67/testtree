export enum LifeLineRoles {
  RetroUser = "Retro",
  RetroAdmin = "RetroAdministrator",
  Adminstrator = "Administrator",
  LifeLineUser = "LifeLineUser",
  AccountRep = "AccountRep",
  AccountRepManager = "AccountRepManager",
}
