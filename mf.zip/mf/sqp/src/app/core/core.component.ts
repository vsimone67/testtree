import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <div id="sqp">
      <router-outlet></router-outlet>
    </div>
  `,
  styles: [],
})
export class CoreComponent {}
