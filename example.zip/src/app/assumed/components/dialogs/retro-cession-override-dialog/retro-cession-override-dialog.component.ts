import { Component, OnInit } from '@angular/core';
import { RetroCessionOverrideModel } from '@retro/models/RetroCessionOverrideModel';
import { EditDialogBase } from '../EditDialogBase';
import {DropPair} from "@shared/models/dropPair";

@Component({
  selector: 'retro-cession-override-dialog',
  templateUrl: './retro-cession-override-dialog.component.html',
  styleUrls: ['./retro-cession-override-dialog.component.css']
})
export class RetroCessionOverrideDialogComponent extends EditDialogBase<RetroCessionOverrideModel> implements OnInit {
  tablesNumber: Array<DropPair>;

  constructor() { super(); }

  ngOnInit(): void {
    this.tablesNumber =[];
    for(let i=0 ; i<37;i++){
      this.tablesNumber.push({
        value:i,
        label:i.toString()
      })
    }
  }

  cancelDialog() {
    this.showDialog = false;
    this.hideDialog();
  }
}
