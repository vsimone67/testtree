import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { SecurityRolesService } from 'src/app/roles/services/security-roles.service';
import { RoleModel } from '../../models/role-model';

@Component({
  selector: 'app-edit-security-role',
  templateUrl: './edit-security-role.component.html',
  styleUrls: ['./edit-security-role.component.css'],
})
export class EditSecurityRoleComponent
  extends EditDialogBase<RoleModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() selectedData;
  @Input() showAll: boolean;
  roleName;
  applicationId;
  loweredRoleName;
  description;
  rowStatusId;

  constructor(private rolesService: SecurityRolesService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.roleName = this.selectedData.roleName;
    this.description = this.selectedData.description;
  }

  async saveEditTeamMember() {
    if (this.roleName != null) {
      this.loweredRoleName = this.roleName.toLowerCase();
    }

    await this.rolesService.editSecurityRole(
      this.selectedData.roleId,
      this.roleName,
      '5FDCC982-6711-4EBC-92DF-D01F12474071',
      this.loweredRoleName,
      this.description,
      '0C84441F-9FFF-49ED-8E26-7BCE4259EC07'
    );
    //this.showDialog = false;
    this.submitDialog();
    this.hideDialog();
  }
}
