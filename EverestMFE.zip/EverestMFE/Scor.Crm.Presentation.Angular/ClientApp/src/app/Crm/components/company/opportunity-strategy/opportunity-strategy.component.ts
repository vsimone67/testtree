import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {SalesOpportunityDto} from "../../../dto/salesOpportunityDto";
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {CrmService} from "../../../service/CrmService";
import {SiteConstants} from "@constants/siteConstants";
import {ConfirmationService} from "primeng/api";

@Component({
  selector: 'opportunity-strategy',
  templateUrl: './opportunity-strategy.component.html',
  styleUrls: ['./opportunity-strategy.component.css']
})
export class OpportunityStrategyComponent implements OnInit {
  @Input() strategy
  @Input() opportunity: SalesOpportunityDto[]
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;
  showDialog: any;
  selectedOpportunity: SalesOpportunityDto;
  private mode: string;

  constructor(private crmService: CrmService, private confirm: ConfirmationService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 200px;";
    this.columnDefs = this.createColumns();

  }

  EditStrategyOpportunity(data) {
    this.mode = 'edit';
    this.showDialog = true;
    this.selectedOpportunity = data.rowData
  }

  deleteOpportunity(data) {
    this.confirm.confirm({
      message: "Do you want to delete this Opportunity ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        let id = data.rowData.salesOpportunityId
        this.crmService.DeleteOpportstringy(id).then(liste => {
          this.refreshData.emit()
        })
      },
      reject: () => {
      },
    });

  }

  addOpportunity() {
    this.mode = 'add';
    this.showDialog = true;
    this.selectedOpportunity = <SalesOpportunityDto>{}
  }

  submitDialog(opportunity: SalesOpportunityDto) {
    if (this.mode == 'add') {
      opportunity.strategyId = this.strategy;
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      opportunity.createdBy = user.userId;
      opportunity.modifiedBy = user.userId;
      opportunity.moduleReference = null;

      this.crmService.AddOpportstringy(opportunity).then(aka => this.refreshData.emit())
    } else {
      this.crmService.EditOpportunity(opportunity).then(aka => this.refreshData.emit())

    }
  }

  hideDialog() {
    this.showDialog = false;

  }

  private createColumns() {
    return <ColDef[]>[
      {
        field: "salesOpportunityType.codeName",
        headerName: "Type",
        width: 250
      },
      {
        field: "salesOpportunityNote",
        headerName: "Note",
        width: 350
      },
      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.EditStrategyOpportunity.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteOpportunity.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }

}
