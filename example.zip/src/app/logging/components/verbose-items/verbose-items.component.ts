import {Component, Input, OnInit} from '@angular/core';
import {ColDef, GridOptions} from 'ag-grid-community';
import { VerboseItem } from '../../models/NaarSplit/verboseItem';

@Component({
  selector: 'verbose-items',

  templateUrl: './verbose-items.component.html',
  styleUrls: ['./verbose-items.component.css']
})
export class VerboseItemsComponent implements OnInit {
  @Input() verboseList: Array<VerboseItem>;

  columnDefs: Array<ColDef>;
  GridCssStyle: string;
  gridOptions: GridOptions;
  keyword: string;
  FilteredVerbose: Array<VerboseItem>;

  constructor() {
    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 350px;";
    this.gridOptions = <GridOptions>{};

    this.gridOptions.tooltipShowDelay = 500; //default tool tip to 1/2 second
  }

  ngOnInit(): void {
    if (this.verboseList != undefined) {
      this.FilteredVerbose = this.verboseList
    }
  }

  createColumnDefs() {
    return [
      {
        headerName: "Message",
        field: "message",
        tooltipField: 'message',
      },
      {
        headerName: "Message Type",
        field: "messageType"
      }
    ];
  }
  updatetable(key) {
    this.FilteredVerbose = this.verboseList.filter(verbose => verbose.message.toLowerCase().includes(this.keyword.toLowerCase()))
    this.gridOptions.api.refreshCells()
  }
}
