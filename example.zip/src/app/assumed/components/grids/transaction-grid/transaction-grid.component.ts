import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { ColDef } from "ag-grid-community";
import { TreatyCompleteModel } from '@assumed/models/TreatyCompleteModel';
import { TreatyService } from '@shared/services/treaty.service';
import { formatDate } from '@shared/components/grid/formatters/formatDate';
import { formatNumber } from '@shared/components/grid/formatters/formatNumber';
import {formatCurrency, formatCurrencyCent} from '@shared/components/grid/formatters/formatCurrency';
import { LinkCellComponent } from '@shared/components/grid/link-cell/link-cell.component';
import { CessionTransactionModel } from '@assumed/models/CessionTransactionModel';
import { GraphEventModel } from '@assumed/models/GraphEventModel';
import { EventService } from '@shared/services/event.service';
import { events } from '@constants/events.model';
@Component({
  selector: "transaction-grid",
  templateUrl: "./transaction-grid.component.html",
  styleUrls: ["./transaction-grid.component.css"],
})
export class TransactionGridComponent implements OnInit {
  @Input() EventData: GraphEventModel;
  @Output() hidetable: EventEmitter<Boolean> = new EventEmitter<Boolean>()

  TransactionData: Array<CessionTransactionModel>;
  FilterTransactionData: Array<CessionTransactionModel>;
  columnDefs: Array<ColDef>;
  defaultCols: Array<String>
  showTreaty: boolean = false;
  currentCessionNumber: string;
  treatyId: string;
  currentTreaty: TreatyCompleteModel;
  txnTypeFilter: string;
  txnDateFilter: Date;

  constructor(private _treatySerivce: TreatyService, private _eventService: EventService) {
    this.createTransactionColumns();

    // clear any prior txn events
    _eventService.clearEvent(events.tnxTypeFilter);
    // listen for tnxTypeFilter event
    _eventService.getEvent(events.tnxTypeFilter).subscribe(
      txnType => {
        this.txnTypeFilter = txnType;
        this.filterTxnData();

      });

    // listen for tnxDateFilter event
    _eventService.getEvent(events.txnDateFilter).subscribe(
      filterDate => {
        this.txnDateFilter = filterDate;
        this.filterTxnData();
      });

    this.txnTypeFilter = "";
    this.txnDateFilter = new Date("01/01/1980");  // set to a very early date so we can include it in the base search so all records are retrieved for date
  }

  ngOnInit() {
    this.TransactionData = this.EventData.data.payload;
    this.FilterTransactionData = this.TransactionData;
    this.currentCessionNumber = this.EventData.data.everestCessionNumber.toString();
  }

  createTransactionColumns() {
    this.columnDefs = this.getColumns();
    this.defaultCols = this.getDefaultColumns();
  }
  disable(visible) {
    this.hidetable.emit(visible)
  }

  filterTxnData() {
     if (this.txnTypeFilter ) {
      this.FilterTransactionData = this.TransactionData.filter((exp) => new Date(exp.fromDate) >= this.txnDateFilter && exp.transactionType === this.txnTypeFilter);
    } else {
      this.FilterTransactionData = this.TransactionData.filter((exp) => new Date(exp.fromDate) >= this.txnDateFilter);
    }
  }

  async onShowTreatyInfo(gridRow) {
    var transactionRecord = <CessionTransactionModel>gridRow.rowData;
    this.treatyId = transactionRecord.treatyId;
    this.currentTreaty = await this._treatySerivce.getTreatyInfo(this.treatyId);
    this.showTreaty = true;
  }
  hideTreatyDialog() {
    this.showTreaty = false
  }

  getColumns() {
    return [
      {
        headerName: "Company Name",
        field: "companyName",
        cellClass: "text-left"
      }, {
        headerName: "DataSet Name",
        field: "dataSetName",
        cellClass: "text-left"
      }, {
        headerName: "File Path",
        field: "filePath",
        cellClass: "text-left"
      }, {
        headerName: "Transaction File Name",
        field: "trxFileName",
        cellClass: "text-left"
      }, {
        headerName: "Reporting Period From Date",
        field: "reportingPeriodFromDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Reporting Period To Date",
        field: "reportingPeriodToDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Carrier Code",
        field: "carrierCode",
        cellClass: "text-left"
      },
      {
        headerName: "Ceding Company",
        field: "cedingCompany",
        cellClass: "text-left"
      }, {
        headerName: "Transaction Type",
        field: "transactionType",
        cellClass: "text-left"
      }, {
        headerName: "Transaction Indicator",
        field: "transactionIndicator",
        cellClass: "text-left"
      }, {
        headerName: "Transaction Sequence",
        field: "transactionSequence",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "From Date",
        field: "fromDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "To Date",
        field: "toDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Policy Duration",
        field: "policyDuration",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Reinsurance Duration",
        field: "reinsuranceDuration",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Treaty Number",
        field: "treatyNumber",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowTreatyInfo.bind(this),
        },
        cellClass: "text-left"
      }, {
        headerName: "Plan Code",
        field: "planCode",
        cellClass: "text-left"
      }, {
        headerName: "Base Face Amount ",
        field: "baseFaceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Base Nar Amount ",
        field: "baseNaramount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Base Reinsured Amount ",
        field: "baseReinsuredAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Base Retention Amount ",
        field: "baseRetentionAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Base Premium Amount ",
        field: "basePremiumAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Base Allowance Amount ",
        field: "baseAllowanceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Premium Amount1",
        field: "extraPremiumAmount1",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Extra Allowance Amount1",
        field: "extraAllowanceAmount1",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Premium Amount2",
        field: "extraPremiumAmount2",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Extra Allowance Amount2",
        field: "extraAllowanceAmount2",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Premium Amount3",
        field: "extraPremiumAmount3",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Extra Allowance Amount3",
        field: "extraAllowanceAmount3",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Type3",
        field: "extraType3",
        cellClass: "text-left"
      }, {
        headerName: "Policy Fee Amount",
        field: "policyFeeAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Policy Fee Allowance Amount",
        field: "policyFeeAllowanceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Client Message",
        field: "clientMessage",
        cellClass: "text-left"
      }, {
        headerName: "Client Data",
        field: "clientData",
        cellClass: "text-left"
      }, {
        headerName: "Benefit Rider Type",
        field: "benefitRiderType",
        cellClass: "text-left"
      }, {
        headerName: "Benefit Face Amount",
        field: "benefitFaceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Benefit NAR Amount",
        field: "benefitNARAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Benefit Reinsured Amount",
        field: "benefitReinsuredAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Benefit Retention Amount",
        field: "benefitRetentionAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Benefit Premium Amount",
        field: "benefitPremiumAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Benefit Allowance Amount",
        field: "benefitAllowanceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Benefit Mortality Rating",
        field: "benefitMortalityRating",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Benefit Paid To Date",
        field: "benefitPaidToDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Benefit Cancel Date",
        field: "benefitCancelDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Net Premium",
        field: "netPremium",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      },
    ]
  }

  getDefaultColumns() {
    return ["companyName", "fromDate", "toDate", "cedingCompany", "transactionType", "baseFaceAmount", "policyDuration", "treatyNumber", "planCode", "baseNaramount", "basePremiumAmount"]
  }

}
