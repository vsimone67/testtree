import { Component, OnInit, Input, SimpleChange, OnChanges } from '@angular/core';
import { PoolViewModel } from '../../models/NaarSplit/poolViewModel';
import { ColDef } from 'ag-grid-community';
import { formatPercent } from '@shared/components/grid/formatters/formatPercent';
import { formatCurrency } from '@shared/components/grid/formatters/formatCurrency';
import { formatBoolean } from '@shared/functions/formatBoolean';


@Component({
  selector: 'pool',
  templateUrl: './pool.component.html',
  styleUrls: ['./pool.component.css']
})
export class PoolComponent implements OnInit, OnChanges {
  @Input() poolInfo: PoolViewModel;
  columnDefs: Array<ColDef>;
  GridCssStyle: string;

  startDate: string;
  endDate: string;
  captureEligible: string;

  constructor() {

    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 250px;";
  }

  ngOnInit(): void {
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    // if options are passed, override default
    if (changes.poolInfo != undefined) {

      this.startDate = new Date(changes.poolInfo.currentValue.poolStartDate).toLocaleDateString();
      this.endDate = new Date(changes.poolInfo.currentValue.poolEndDate).toLocaleDateString();
      this.captureEligible = formatBoolean(changes.poolInfo.currentValue.isEligibleForRecapture);
    }
  }

  createColumnDefs() {
    return [
      {
        headerName: "Retro Company",
        field: "retroCompany"

      },
      {
        headerName: "Retro Treaty Number",
        field: "retroTreatyNumber",

      },
      {
        headerName: "Retro Treaty Number",
        field: "retroTreatyNumber",

      },
      {
        headerName: "Plan Name",
        field: "planName",
      },
      {
        headerName: "Reinsurance Type",
        field: "reinsuranceType",
      },
      {
        headerName: "Retro Share %",
        field: "retroSharePercentage",
        valueFormatter: formatPercent
      },
      {
        headerName: "Country Rating Group",
        field: "countryRatingGroup",
      },
      {
        headerName: "Binding Type",
        field: "bindingType",
      },
      {
        headerName: "Binding Limit",
        field: "bindingLimit",
        valueFormatter: formatCurrency
      }
    ];
  }
}

