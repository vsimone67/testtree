import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { ColDef } from 'ag-grid-community';
import { AssignedContactModel } from '../../models/assigned-contact.model';
import { TeamMemberModel } from '../../models/team-member.model';
import { OpsteamService } from '../../services/ops-team.service';

@Component({
  selector: 'app-info-team-member',
  templateUrl: './info-team-member.component.html',
  styleUrls: ['./info-team-member.component.css'],
})
export class InfoTeamMemberComponent
  extends EditDialogBase<TeamMemberModel>
  implements OnInit
{
  @Input() team;
  contactList;
  columnDefs;

  constructor(private opsTeamService: OpsteamService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
    this.columnDefs = this.createColumnDefs();
  }

  async getInitialData() {
    const newList = await this.opsTeamService.getContacts(this.team.companyId);

    this.contactList = [];
    newList.forEach((line: AssignedContactModel) => {
      if (line) this.contactList.push(line);
    });
  }

  createColumnDefs() {
    var cols: ColDef[] = [
      {
        headerName: 'Contact',
        field: 'contactFirstName',
        width: 150,
        resizable: true,
        sortable: true,
      },
      {
        headerName: 'Contact',
        field: 'contactLastName',
        width: 150,
        resizable: true,
        sortable: true,
      },
    ];

    return cols;
  }
}
