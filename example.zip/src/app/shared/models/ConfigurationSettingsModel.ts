export interface ConfigurationSettingModel {
  configurationSettingId: string;
  configurationModuleNameId: string | null;
  configurationName: string;
  configurationValue: string;
  createDate: string | null;
  createdBy: string | null;
  modifiedBy: string | null;
  modifiedDate: string | null;
  moduleReference: string | null;
  rowStatusId: string | null;
}
