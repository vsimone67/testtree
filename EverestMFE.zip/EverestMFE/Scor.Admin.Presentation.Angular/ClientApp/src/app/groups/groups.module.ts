import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GroupsContainerComponent } from './components/groups-container/groups-container.component';
import { GroupsResultsComponent } from './components/groups-results/groups-results.component';
import { GroupsSearchComponent } from './components/groups-search/groups-search.component';
import { AddRoleToGroupComponent } from './dialogs/add-role-to-group/add-role-to-group.component';
import { AddGroupsComponent } from './dialogs/add-security-group/add-security-group.component';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [
    GroupsContainerComponent,
    GroupsResultsComponent,
    GroupsSearchComponent,
    AddRoleToGroupComponent,
    AddGroupsComponent,
  ],
  imports: [CommonModule, SharedModule],
  exports: [],
})
export class GroupsModule {}
