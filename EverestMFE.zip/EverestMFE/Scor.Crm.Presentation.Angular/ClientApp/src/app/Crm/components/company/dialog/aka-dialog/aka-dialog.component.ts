import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {GeneraliAkaDto} from "../../../../dto/generaliAkaDto";

@Component({
  selector: 'aka-dialog',
  templateUrl: './aka-dialog.component.html',
  styleUrls: ['./aka-dialog.component.css']
})
export class AkaDialogComponent implements OnInit {
  @Input() aka: GeneraliAkaDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;

  constructor() {
  }

  ngOnInit(): void {
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {

    this.onSubmitDialog.emit(this.aka);
    this.onDialogHide.emit()

  }
}
