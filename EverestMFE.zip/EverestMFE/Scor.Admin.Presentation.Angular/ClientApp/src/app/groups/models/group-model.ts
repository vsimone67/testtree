export interface GroupModel {
    groupId: string;
    groupName: string;
    codeDescription: string;
    codeValue: string;
    moduleReferenceId: string;
    userId: string;
    rowStatusId: string;
}