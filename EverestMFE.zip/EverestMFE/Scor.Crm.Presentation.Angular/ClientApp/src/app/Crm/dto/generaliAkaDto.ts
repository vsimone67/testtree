import { CompanyDto } from './companyDto';

export interface GeneraliAkaDto {
    companyId: string;
    generaliAkaid: string;
    akaname: string;
    akanotes: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
}