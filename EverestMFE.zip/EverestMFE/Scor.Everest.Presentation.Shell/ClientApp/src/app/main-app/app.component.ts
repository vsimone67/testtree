import { Component } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from '@scor/common';
import { MicroFrontEnd } from '../common/models/microFrontEnd';
import { ShellConfig } from './shell/config';
import { ShellService } from './shell/shell.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  date: number;
  version: string;
  environment: string;
  constructor(
    private appsettings: AppSettingsService,
    private shellService: ShellService
  ) {}

  ngOnInit() {
    // gather data for footer
    this.date = new Date().getFullYear();
    this.version = SiteConstants.version;
    this.environment = this.appsettings.GetValue('environment');

    // start Micro Front End setup
    var microFontEnds = <Array<MicroFrontEnd>>(
      this.appsettings.GetValue('microFrontEnds')
    );

    // setup the Micro Font End containers
    var mfeConfig = <ShellConfig>{
      preload: false,
      outletId: 'content',
      clients: {},
    };

    // load each Micro Font End from the appsettings
    microFontEnds.forEach((mfe) => {
      mfeConfig.clients[mfe.name] = {
        loaded: false,
        src: mfe.path,
        element: mfe.element,
        route: mfe.route,
      };
    });

    // initialize the Micro Font Ends, this service will manage loading each service located in appsettings
    this.shellService.init(mfeConfig);
  }
}
