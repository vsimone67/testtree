import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { GroupModel } from '../../models/group-model';
import { SecurityGroupsService } from '../../services/security-groups.service';

@Component({
  selector: 'app-edit-security-group',
  templateUrl: './edit-security-group.component.html',
  styleUrls: ['./edit-security-group.component.css'],
})
export class EditGroupsComponent
  extends EditDialogBase<GroupModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() selectedData;
  @Input() showAll: boolean;
  groupName;
  codeDescription;
  codeValue;
  moduleReferenceId;
  rowStatusId;
  status: any = [];

  constructor(private groupsService: SecurityGroupsService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.groupName = this.selectedData.groupName;
    this.codeDescription = this.selectedData.codeDescription;
    this.codeValue = this.selectedData.codeValue;
    this.moduleReferenceId = this.selectedData.moduleReferenceId;
    this.rowStatusId = this.selectedData.rowStatusId;
  }

  async saveEditTeamMember() {
    await this.groupsService.editSecurityGroup(
      this.selectedData.groupId,
      this.groupName,
      this.codeDescription,
      this.codeValue,
      this.moduleReferenceId,
      this.rowStatusId
    );
    //this.showDialog = false;
    this.submitDialog();
    this.hideDialog();
  }
}
