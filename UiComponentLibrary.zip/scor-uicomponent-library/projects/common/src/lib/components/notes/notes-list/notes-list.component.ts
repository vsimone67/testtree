import {
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChange,
} from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { formatDate } from '../../grid/formatters/formatDate';
import { NotesService } from '../internal-service/notes.service';
import { GetNotesByParentAndGroupCriteria } from '../models/GetNotesByParentAndGroupCriteria';
import { NoteGroupMemberDto } from '../models/noteGroupMemberDto';

@Component({
  selector: 'notes-list',
  templateUrl: './notes-list.component.html',
  styleUrls: ['./notes-list.component.css'],
})
export class NotesListComponent implements OnInit, OnChanges {
  @Input() parentId!: string;
  @Input() noteType!: string;
  @Input() noteUrl!: string;
  noteList!: Array<NoteGroupMemberDto>;
  columnList!: Array<ColDef>;

  constructor(private _notesService: NotesService) {}

  ngOnInit(): void {
    this.columnList = this.getColumns();
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    if (changes.parentId.currentValue != undefined) {
      this._notesService.noteUrl = this.noteUrl;
      this.getNotes();
    }
  }

  getNotes() {
    var criteria = <GetNotesByParentAndGroupCriteria>{
      ParentId: this.parentId,
      NoteGroup: this.noteType,
    };
    this._notesService
      .getNotes(criteria)
      .then((data: Array<NoteGroupMemberDto>) => (this.noteList = data));
  }

  getColumns() {
    return [
      {
        headerName: 'Note',
        field: 'note.noteText',
      },
      {
        headerName: 'Note Date',
        field: 'note.createDate',
        valueFormatter: formatDate,
      },
      {
        headerName: 'Created By',
        cellRenderer: (params: any) =>
          `${params.data.note.createdByNavigation.firstName} ${params.data.note.createdByNavigation.lastName}`,
      },
    ];
  }
}
