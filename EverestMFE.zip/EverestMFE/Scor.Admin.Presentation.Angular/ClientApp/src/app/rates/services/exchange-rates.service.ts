import { Injectable } from '@angular/core';
import { User } from '@auth/models/user';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService, HttpService } from '@scor/common';
import { CurrencyModel } from '../models/currency-model';
import { RateModel } from '../models/rate-model';

@Injectable({
  providedIn: 'root',
})
export class ExchangeRatesService {
  baseApiUrl: string;
  currencyUrl: string;
  countryUrl: string;
  addRateUrl: string;
  deleteRateUrl: string;
  editRateUrl: string;
  currentUser: User;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this.baseApiUrl = `${this._appSettingsService.GetValue(
      'apiGatewayUrl'
    )}/currencyexchange/`;
    this.currencyUrl = this.baseApiUrl + `GetListOfCurrencies`;
    this.countryUrl = this.baseApiUrl + `GetRatesForCurrency?countryId=`;
    this.addRateUrl = this.baseApiUrl + `AddExchangeRate`;
    this.editRateUrl = this.baseApiUrl + `EditExchangeRate`;
    this.deleteRateUrl = this.baseApiUrl + `SetStatus`;
    this.currentUser = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
  }

  async getCurrencies() {
    return await this._httpService.getData<CurrencyModel[]>(
      `${this.currencyUrl}`
    );
  }

  async getExchangeRates(countryId: string) {
    return await this._httpService.getData<RateModel[]>(
      `${this.countryUrl}${countryId}`
    );
  }

  async addExchangeRate(
    exchangeCountryId: string,
    exchangeRate: number,
    startDate: Date
  ) {
    const body = {
      ExchangeCountryId: exchangeCountryId,
      ExchangeRate: exchangeRate,
      StartDate: startDate,
      CreatedBy: this.currentUser.id,
    };

    return await this._httpService.postData(this.addRateUrl, body);
  }

  async editExchangeRate(
    exchangeCountryId: string,
    exchangeRate: number,
    startDate: Date,
    newEffectiveDate: Date
  ) {
    const body = {
      ExchangeCountryId: exchangeCountryId,
      ExchangeRate: exchangeRate,
      StartDate: startDate,
      ModifiedBy: this.currentUser.id,
      newStartDate: newEffectiveDate,
    };

    return await this._httpService.putData(this.editRateUrl, body);
  }

  async deleteExchangeRate(
    exchangeCountryId: string,
    startDate: Date,
    statusId: string
  ) {
    const body = {
      ExchangeCountryId: exchangeCountryId,
      StartDate: startDate,
      StatusId: statusId,
      ModifiedBy: this.currentUser.id,
    };

    return await this._httpService.putData(this.deleteRateUrl, body);
  }
}
