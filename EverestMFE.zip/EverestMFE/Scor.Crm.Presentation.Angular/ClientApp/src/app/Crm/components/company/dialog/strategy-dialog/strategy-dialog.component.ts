import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {StrategyDto} from "../../../../dto/strategyDto";
import {CrmService} from "../../../../service/CrmService";
import {SalesObjectiveDto} from "../../../../dto/salesObjectiveDto";
import {SalesOpportunityDto} from "../../../../dto/salesOpportunityDto";
import {SalesObstacleDto} from "../../../../dto/salesObstacleDto";
import {ActionPlanDto} from "../../../../dto/actionPlanDto";

@Component({
  selector: 'strategy-dialog',
  templateUrl: './strategy-dialog.component.html',
  styleUrls: ['./strategy-dialog.component.css']
})
export class StrategyDialogComponent implements OnInit {
  @Input() strategy: StrategyDto;
  @Input()companyId;
  showDialog: any;
  divisions: any;
  types: any;
  typesObjective: any;
  opportunity: SalesOpportunityDto;
  objective: SalesObjectiveDto;
  obstacle: SalesObstacleDto;
  actionPlan: ActionPlanDto;
  typeOpportunity: any[];
  typeObstacle: any[];
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()

  constructor(private _crmService: CrmService) {
    this.opportunity= <SalesOpportunityDto>{};
    this.objective=<SalesObjectiveDto>{};
    this.obstacle = <SalesObstacleDto>{};
    this.actionPlan=<ActionPlanDto>{}
  }

  ngOnInit(): void {
    this.showDialog=true
    this._crmService.GetDivisions().then(divisions => {
      this.divisions = [];
      divisions.forEach(div => {
        this.divisions.push({
          label: div.codeName,
          value: div.codeId
        })
      })
    })
    this._crmService.GetObjectiveTypes().then(typesObjective => {
      this.typesObjective = [];
      typesObjective.forEach(div => {
        this.typesObjective.push({
          label: div.codeName,
          value: div.codeId
        })
      })
    })
    this._crmService.GetOpportunityTypes().then(typeOpportunity => {
      this.typeOpportunity = [];
      typeOpportunity.forEach(div => {
        this.typeOpportunity.push({
          label: div.codeName,
          value: div.codeId
        })
      })
    })
    this._crmService.GetObstacleTypes().then(typeObstacle => {
      this.typeObstacle = [];
      typeObstacle.forEach(div => {
        this.typeObstacle.push({
          label: div.codeName,
          value: div.codeId
        })
      })
    })
  }

  hideDialog() {
      this.onDialogHide.emit()
  }

  submitDialog() {
    this.strategy.companyId = this.companyId
    this.strategy.salesObjective=[];
    this.strategy.salesObjective.push(this.objective)
    this.strategy.salesObstacle=[];
    this.strategy.salesObstacle.push(this.obstacle)
    this.strategy.salesOpportunity=[];
    this.strategy.salesOpportunity.push(this.opportunity)
    this.strategy.actionPlan=[];
    this.strategy.actionPlan.push(this.actionPlan)
    this.onSubmitDialog.emit(this.strategy)
  }
}
