export interface ClaimRequestReceiptModel {
  companyId: string;
  companyName: string;
  claimId: string | null;
  amountRequested: number | null;
  amountAllocated: number | null;
  totalOutstanding: number | null;
  splitPercent: number | null;
  splitCategoryType: string;
  splitType: string;
  treatyNumber: string;
  activityCount: number | null;
  legalEntityName: string;
  legalEntityId: string | null;
  payorLegalEntityName: string;
  payorLegalEntityId: string | null;
}
