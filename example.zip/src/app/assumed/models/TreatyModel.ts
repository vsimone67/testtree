import { TreatyPlanBasicInfoModel } from "@shared/models/TreatyPlanBasicInfoModel";
import { TreatyPlanModel } from "./TreatyPlanModel";

export interface TreatyModel {
  treatyId: string;
  backDateDays: number | null;
  clientTreatyNumber: string;
  companyContactGroupId: string | null;
  documentGroupId: string | null;
  isConverted: boolean | null;
  noteGroupId: string | null;
  surveyInstanceId: string | null;
  teamAssignmentGroupId: string | null;
  terminatedDate: Date | string | null;
  terminatedForNewBusinessDate: Date | null;
  treatyAmendmentNumber: number | null;
  treatyCategoryId: string;
  treatyEffectiveDate: Date | null;
  treatyMonth: number;
  treatyNumber: string;
  treatyOriginTypeId: string;
  treatySequenceNumber: number;
  treatyTypeId: string | null;
  treatyYear: number;
  workflowInstanceId: string | null;
  createDate: Date | string;
  createdBy: string | null;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;
  treatyCoverageEffectiveDate: Date | null;
  treatyAmendmentCoverageEffectiveDate: Date | null;
  treatyParentId: string | null;
  legalEntityId: string;
  treatyGroupId: string | null;
  treatyPlans: TreatyPlanBasicInfoModel[];
}
