export interface TeamAssignmentGroupModel {
  groupId: string;
  groupDescription: string;
  groupName: string;
  groupSubTypeId: string | null;
  groupTypeId: string;
  parentId: string | null;
  createDate: Date | string;
  createdBy: string | null;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;
  rowStatusId: string | null;
}
