import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyRelationshipComponent } from './company-relationship.component';

describe('CompanyRelationshipComponent', () => {
  let component: CompanyRelationshipComponent;
  let fixture: ComponentFixture<CompanyRelationshipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanyRelationshipComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRelationshipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
