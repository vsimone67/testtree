import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { CessionHistoryModel } from "@assumed/models/CessionHistoryModel";
import { AssumedService } from "@assumed/services/assumed.service";
import { User } from "@auth/models/user";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { formatCurrency } from "@shared/components/grid/formatters/formatCurrency";
import { formatDate } from "@shared/components/grid/formatters/formatDate";
import { GenericGridComponent } from "@shared/components/grid/generic-grid/generic-grid.component";
import { NoteModel } from "@shared/models/NoteModel";
import { ColDef, GridOptions } from "ag-grid-community";
import { ConfirmationService, MessageService } from "primeng";
import { SiteConstants } from "@constants/siteConstants";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { CessionHistoryAggregate } from "@assumed/models/CessionHistoryAggregate";
import { RollbackService } from "@shared/service/rollback.service";
import { AssumedAggregatorService } from "@shared/services/assumedAggregatorService";
import { AssumedRollbackAggregatorService } from "@assumed/service/assumed-rollback-aggregator.serivce";
import { AppSettingsService } from "@shared/service/app-settings.service";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";

@Component({
  selector: "cession-history",
  templateUrl: "./cession-history.component.html",
  styleUrls: ["./cession-history.component.css"],
})
export class CessionHistoryComponent implements OnInit {
  @ViewChild(GenericGridComponent, { static: false }) grid;

  cessionHistoryList: Array<CessionHistoryModel>;
  selectedCessionHistory: CessionHistoryModel;
  currentCessionHistory: CessionHistoryModel;
  noteList: Array<NoteModel>;
  cessionId: string;

  mode: string;
  currentUser: User;
  showHistoryDialog: boolean;
  showNoteDialog: boolean;
  columnDefs: Array<ColDef>;
  isAdmin: boolean;
  gridOption: GridOptions;
  GridCssStyle: string;
  private _reportUrl: string;

  constructor(
    private _assumedService: AssumedService,
    private _AssumedAggregatorService: AssumedAggregatorService,
    private _route: ActivatedRoute,
    private _rollbackAgregator: AssumedRollbackAggregatorService,
    private _rollbackService: RollbackService,
    private _messageService: MessageService,
    private _appSettingsService: AppSettingsService,
    private _confirmService: ConfirmationService
  ) {
    this._reportUrl = `${this._appSettingsService.GetValue(
      SiteConstants.reportUrl
    )}`;
  }

  async ngOnInit() {
    this.cessionId = this._route.snapshot.paramMap.get("id");
    this.showHistoryDialog = false;
    this.showNoteDialog = false;
    this.gridOption = <GridOptions>{};
    this.gridOption.tooltipShowDelay = 500;
    this.GridCssStyle = "width: 100%; height: 500px;";
    this.currentUser = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.isAdmin = LifeLineRoleCheck.isRetroEventsWrite();
    this.columnDefs = this.getColumns();
    this.cessionHistoryList = await this._assumedService.getCessionHistory(
      this.cessionId
    );

    this.sortGrid();
    this.cessionHistoryList.forEach((history) => {
      this._rollbackService
        .hasRollback(history.cessionHistoryId, "CessionHistory")
        .then((rollback: any) => {
          history.hasRollback = rollback.hasRollback;
        });
    });
  }

  sortGrid() {
    // ! We need to fix the assumed service cesion history from returning duplicates, for now filter them out

   console.log("called");
   this.cessionHistoryList = this.cessionHistoryList.filter(
      (history, i, arr) =>
        arr.findIndex(
          (t) => t.cessionHistoryId === history.cessionHistoryId
        ) === i
    );

    this.cessionHistoryList.sort((a, b) => {
      // Sort by reinsurance duration descending
      // If the first item has a higher number, move it up
      // If the first item has a lower number, move it down
      if (b.reinsuranceDuration > a.reinsuranceDuration) return 1;
      if (a.reinsuranceDuration > b.reinsuranceDuration) return -1;

      // If the duration is the same between both items, sort by create date desc
      // If the first item has a higher date, move it up
      // If the first item has a lower date, move it down
      if (b.createDate > a.createDate) return 1;
      if (b.createDate < a.createDate) return -1;
    });
  }
  async refreshGrid() {
    this.cessionHistoryList = await this._assumedService.getCessionHistory(
      this.cessionId
    );

    this.sortGrid();
    this.cessionHistoryList.forEach((history) => {
      this._rollbackService
        .hasRollback(history.cessionHistoryId, "CessionHistory")
        .then((rollback: any) => {
          history.hasRollback = rollback.hasRollback;
        });
    });
  }

  displayNotes() {
    this.showNoteDialog = true;
  }

  saveHistoryData(data) {
    this.showHistoryDialog = false;

    if (this.validateBeforeSave) {
      if (this.mode === "Add") {
        this._AssumedAggregatorService
          .AddCessionHistory(this.selectedCessionHistory)
          .then((data) => {
            this._messageService.add({
              severity: "success",
              detail: "Cession History has been cloned",
            });
            this.refreshGrid();
          });
      } else {
        var cessionHisory = <CessionHistoryAggregate>{
          currentValue: this.currentCessionHistory,
          newValue: this.selectedCessionHistory,
        };
        this._AssumedAggregatorService
          .EditCessionHistory(cessionHisory)
          .then((data) => {
            this._messageService.add({
              severity: "success",
              detail: "Cession History has been updated",
            });
            this.refreshGrid();
          });
      }
    }
  }

  updateGrid(data) {
    if (this.mode === "Add") {
      this.grid.gridApi.updateRowData({ add: [data] });
      this.cessionHistoryList.push(data);
    } else {
      var row = this.cessionHistoryList.findIndex(
        (cession) =>
          cession.cessionHistoryId ===
          this.selectedCessionHistory.cessionHistoryId
      );

      if (row >= 0) {
        this.cessionHistoryList[row] = data;
        this.grid.gridApi.setRowData(this.cessionHistoryList);
      }
    }

    this.sortGrid();
  }

  validateBeforeSave() {
    // TODO add validation logic
    return true;
  }

  editCessionHistory(historyModel) {
    this.mode = "Edit";
    this.showHistoryDialog = true;
    this.updateCessionHistory(historyModel);
  }

  cloneCessionHistory(historyModel) {
    this.mode = "Add";
    this.showHistoryDialog = true;
    this.updateCessionHistory(historyModel);
  }

  updateCessionHistory(historyModel) {
    this.selectedCessionHistory = historyModel.rowData;
    this.selectedCessionHistory.modifiedBy = this.currentUser.userId;
    this.selectedCessionHistory.effectiveDate = new Date(
      this.selectedCessionHistory.effectiveDate
    );
    this.selectedCessionHistory.cancelDate = new Date(
      this.selectedCessionHistory.cancelDate
    );

    this.currentCessionHistory = { ...this.selectedCessionHistory }; // clone
  }

  hideHistoryDialog() {
    this.showHistoryDialog = false;
  }

  hideNotesDialog() {
    this.showNoteDialog = false;
  }

  getColumns() {
    var cols: ColDef[] = [
      {
        headerName: "Effective Date",
        field: "effectiveDate",
        valueFormatter: formatDate,
        width: 130,
        sortable : true
      },
      {
        headerName: "Cancel Date",
        field: "cancelDate",
        valueFormatter: formatDate,
        width: 130,
        sortable : true
      },
      {
        headerName: "Policy Duration  ",
        field: "policyDuration",
        width: 180,
        sortable : true
      },
      {
        headerName: "Reinsurance Duration",
        field: "reinsuranceDuration",
        width: 180,
        sortable : true
      },
      {
        headerName: "Base Naar Amount",
        field: "baseNaramount",
        valueFormatter: formatCurrency,
        width: 180,
        sortable : true
      },
      {
        headerName: "Policy Date",
        field: "policyDate",
        valueFormatter: formatDate,
        width: 130,
        sortable : true
      },
      {
        headerName: "Original Issue Date",
        field: "originalIssueDate",
        valueFormatter: formatDate,
        width: 180,
        sortable : true
      },
      {
        headerName: "Reinsurance Effective Date",
        field: "reinsuranceEffectiveDate",
        valueFormatter: formatDate,
        width: 200,
        sortable : true
      },
      {
        headerName: "Stack Name",
        field: "stackName",
        width: 130,
        sortable : true
      },
      {
        headerName: "Pool Name",
        field: "poolName",
        width: 110,
        sortable : true
      },
      {
        headerName: "Create Date",
        field: "createDate",
        valueFormatter: formatDate,
        width: 120,
        sortable : true
      },
    ];
    if (this.isAdmin) {
      cols.push(
        {
          headerName: "",
          field: "hasRollback",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.onRollBackHistory.bind(this),
            icon: "pi-undo",
            rollback: true,
          },
          width: 5,
          tooltipValueGetter: (params) => "Rollback Cession History",
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.editCessionHistory.bind(this),
            icon: "pi-pencil",
          },
          tooltipValueGetter: (params) => "Edit Cession History ",
          width: 5,
        },
        {
          headerName: "",
          cellRendererFramework: ImageButtonCellComponent,
          cellRendererParams: {
            onClick: this.cloneCessionHistory.bind(this),
            icon: "pi-clone",
          },
          tooltipValueGetter: (params) => "Clone Cession History ",
          width: 5,
        }
      );
    }
    return cols;
  }

  onRollBackHistory(cell) {
    this._confirmService.confirm({
      message: "Are you sure you want to rollback?",
      header: "Rollback",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key: "history",
      accept: () => {
        this._rollbackAgregator
          .rollbackCessionHistory(cell.rowData.cessionHistoryId)
          .then((data) => {
            this._messageService.add({
              severity: "success",
              detail: "Rollback done successfully",
            });
            this.refreshGrid();
          });
      },
    });
  }

  goToInfos() {
    let url = this._reportUrl
      .concat(
        "NarSplitHistoryReport&rs:Command=Render&rc:Parameters=false&CessionId="
      )
      .concat(this.cessionId);
    window.open(url, "_blank");
  }
}
