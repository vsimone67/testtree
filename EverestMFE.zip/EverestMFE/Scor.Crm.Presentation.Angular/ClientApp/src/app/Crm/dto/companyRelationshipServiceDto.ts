export interface CompanyRelationshipServiceDto {
    companyRelationshipId: string;
    reinsurerServiceTypeId: string;
    competitorInfoNote: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
}