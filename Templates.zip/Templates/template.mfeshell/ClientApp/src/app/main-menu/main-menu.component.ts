import { Component, NgZone, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadCrumbModel } from '../common/components/breadcrumb/breadcrumb.model';
import { events } from 'src/assets/constants/events.model';
import { ShellService } from '../main-app/shell/shell.service';
import { EventService } from '@scor/common';

@Component({
  selector: 'main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.css'],
})
export class MainMenuComponent implements OnInit {
  public items: MenuItem[];
  constructor(
    private eventService: EventService,
    private shellService: ShellService
  ) {
    this.items = [];
  }

  ngOnInit(): void {
    this.items = [
      {
        label: 'CCE',
        command: (event) => {
          this.loadMfe('/crm/home', 'CCE', 'crm');
        },
      },
      {
        label: 'Admin',
        items: [
          {
            label: 'Codes',
            command: (event) => {
              this.loadMfe('/admin/codeAdmin', 'Codes', 'admin');
            },
          },
          {
            label: 'Rates',
            command: (event) => {
              this.loadMfe('/admin/rate', 'Rates', 'admin');
            },
          },
          {
            label: 'Groups',
            command: (event) => {
              this.loadMfe('/admin/groups', 'Groups', 'admin');
            },
          },
          {
            label: 'Regions',
            command: (event) => {
              this.loadMfe('/admin/regions', 'Regions', 'admin');
            },
          },
          {
            label: 'Ops Team',
            command: (event) => {
              this.loadMfe('/admin/opsteam', 'Ops Team', 'admin');
            },
          },
          {
            label: 'Roles',
            command: (event) => {
              this.loadMfe('/admin/roles', 'Roles', 'admin');
            },
          },
        ],
      },
    ];
  }

  loadMfe(url: string, label: string, mfe: string) {
    // send breadcrumb event to update the control
    this.eventService.sendEvent(events.breadcrumbEvent, <BreadCrumbModel>{
      url: url,
      label: label,
    });

    // load the Micro Front End Page
    this.shellService.navigate(url);
  }
}
