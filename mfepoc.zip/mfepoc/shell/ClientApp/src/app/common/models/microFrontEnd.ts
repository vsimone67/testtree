export class MicroFrontEnd {
  constructor() {
    this.loaded = false;
  }

  name: string;
  loaded: boolean;
  path: string;
  element: string;
  url: string;
  label: string;
}
