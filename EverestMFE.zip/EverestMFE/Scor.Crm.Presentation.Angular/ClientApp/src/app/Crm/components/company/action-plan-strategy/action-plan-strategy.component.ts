import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ActionPlanDto} from "../../../dto/actionPlanDto";
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {formatDate} from "@shared/functions/formatDate";
import {SalesObjectiveDto} from "../../../dto/salesObjectiveDto";
import {SiteConstants} from "@constants/siteConstants";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'action-plan-strategy',
  templateUrl: './action-plan-strategy.component.html',
  styleUrls: ['./action-plan-strategy.component.css']
})
export class ActionPlanStrategyComponent implements OnInit {
  @Input() strategy: any
  @Input() actions: ActionPlanDto[]
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;
  showDialog: any;
  selectedAction: ActionPlanDto;
  private mode: string;

  constructor(private crmService:CrmService, private confirm:ConfirmationService,
              private _messageService:MessageService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 200px;";
    this.columnDefs = this.createColumns();

  }

  EditStrategyAction(data) {
    this.mode = 'edit';
    this.showDialog = true;
    this.selectedAction = data.rowData
    this.selectedAction.actionPlanDueDate=new Date(this.selectedAction.actionPlanDueDate);
  }

  deleteAction(data) {
    this.confirm.confirm({
      message: "Do you want to delete this Action Plan ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        let id = data.rowData.actionPlanId
        this.crmService.DeleteActionPlan(id).then(liste => {
          this.refreshData.emit()
          this._messageService.add({severity: "success", detail: "Action PLan Has been Deleted"});
        })
      },
      reject: () => {
      },
    });
  }

  addAction() {
    this.mode = 'add';
    this.showDialog = true;
    this.selectedAction = <ActionPlanDto>{}
  }

  private createColumns() {
    return <ColDef[]>[
      {
        field: "actionPlanDueDate",
        headerName: "Due Date",
        valueFormatter: formatDate
      },
      {
        field: "actionPlanName",
        headerName: "Name",
        width: 250
      },
      {
        field: "actionResult",
        headerName: "Result",
        width: 250
      },
      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.EditStrategyAction.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteAction.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }



  submitDialog(action: ActionPlanDto) {
    if (this.mode == 'add') {
      action.strategyId=this.strategy;
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      action.createdBy=user.userId;
      action.modifiedBy=user.userId;
      action.moduleReference=null;

      this.crmService.AddActionPlan(action).then(aka => this.refreshData.emit())
    } else {
      this.crmService.EditActionPlan(action).then(aka => this.refreshData.emit())

    }
  }

  hideDialog() {
    this.showDialog = false;

  }
}
