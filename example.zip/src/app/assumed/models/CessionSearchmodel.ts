export interface CessionSearchModel {
  CedingCompanyId: string | null;
  LeaglEntityId: string | null;
  FirstName: string;
  LastName: string;
  MiddleInitial: string;
  Dob: Date | string | null;
  PolicyNumber: string;
  CessionNumber: string;
  CessionId:string | null;
}
