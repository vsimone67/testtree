
export interface GraphDataModel {

  metaData: string;
  payload: any;
  parentCession: number;
  isExpanded: boolean;
  everestCessionNumber: number;
}
