export enum GuidConstants {
  commitConfigSetting = "F567C2C6-F3AD-4FD0-939F-026CF60566B8",
}
