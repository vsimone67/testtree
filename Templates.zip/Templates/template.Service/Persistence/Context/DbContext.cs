using System;
using Microsoft.EntityFrameworkCore;

namespace template.Service.Persistence.Context
{
    public class MyDbContext : DbContext
    {

    }
}
