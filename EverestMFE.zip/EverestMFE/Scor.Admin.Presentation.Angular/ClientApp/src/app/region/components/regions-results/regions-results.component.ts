import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ImageButtonCellComponent } from '@scor/common';
import { ColDef, GridOptions } from 'ag-grid-community';
import { defaultcols, defaultsCols, pinned } from './column-defs';

@Component({
  selector: 'app-regions-results',
  templateUrl: './regions-results.component.html',
  styleUrls: ['./regions-results.component.css'],
})
export class RegionsResultsComponent implements OnInit {
  @Input() rowData: any[];
  @Input() pagedata: {
    pageNumber: number;
    pageSize: number;
    sortBy: string;
    isDesc: boolean;
  };
  columns: any[];
  @Output() updatepageData: EventEmitter<any> = new EventEmitter<any>();
  @Output() updateSelection: EventEmitter<any> = new EventEmitter<any>();
  @Output() search: EventEmitter<any> = new EventEmitter<any>();
  @Input() filtersinput;
  @Input() loading;

  msgs: any[] = [];
  defaultColDef;
  frameworkComponents;
  gridApi;
  gridColumnApi;
  pinned;
  pinnedCols;
  allcols;
  showCols;
  dropdownList;
  gridOption: GridOptions = {};
  total;
  paginator;
  columnDefs;
  GridCssStyle: string;
  showEditDialog: boolean = false;
  showDeleteDialog: boolean = false;
  selectedRegion;

  constructor() {
    this.paginator = {
      page: 0,
      first: 0,
      rows: 10,
      pageCount: 2,
      defaultrows: 10,
      totalrecord: 0,
    };

    this.allcols = defaultsCols;
    this.showCols = defaultcols;
    this.pinned = [...pinned];

    this.updateCols();
  }

  ngOnInit(): void {
    if (this.rowData && this.rowData.length === 0) {
      this.msgs.push({
        severity: 'info',
        summary: 'No items were found matching the search criteria',
      });
    } else {
      this.msgs = [];
    }

    this.columnDefs = this.createColumnDefs();
  }

  removeCountry(data) {
    this.showDeleteDialog = true;
    this.selectedRegion = data.rowData;
  }

  hideDeleteDialog() {
    this.showDeleteDialog = false;
  }

  saveDelete(data) {
    this.search.emit();
  }

  createColumnDefs() {
    var cols: ColDef[] = [
      {
        headerName: 'Country',
        field: 'countryName',
        width: 250,
        resizable: true,
        sortable: true,
      },
      {
        headerName: '',
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.removeCountry.bind(this),
          icon: 'pi-times',
        },
        width: 25,
      },
    ];

    return cols;
  }

  updatetable(data, total) {
    this.total = total;
    this.paginator.totalrecord = total ? total : 0;

    this.rowData = data;
    if (!this.rowData || this.rowData.length === 0) {
      if (this.msgs.filter((msg) => msg.severity === 'info').length === 0)
        this.msgs.push({
          severity: 'info',
          summary: 'No items were found matching the search criteria',
        });
    } else {
      this.msgs = [];
    }
    this.paginator.totalrecord = total ? total : 0;
    this.constructlastfirst();
  }

  constructlastfirst() {
    if (this.paginator.page === 0) {
      if (this.paginator.rows > this.paginator.totalrecord) {
        this.paginator.last = this.paginator.totalrecord;
      } else {
        this.paginator.last = this.paginator.rows;
      }
      this.paginator.first = 1;
    } else {
      this.paginator.first = this.paginator.page * this.paginator.rows + 1;
      let x = this.paginator.page + 1;
      if (x * this.paginator.rows > this.paginator.totalrecord) {
        this.paginator.last = this.paginator.totalrecord;
      } else {
        this.paginator.last = x * this.paginator.rows;
      }
    }
  }

  autoSizeAll() {
    var allColumnIds = [];

    if (this.gridColumnApi.getAllColumns()) {
      this.gridColumnApi.getAllColumns().forEach(function (column) {
        allColumnIds.push(column.colId);
      });

      this.gridColumnApi.autoSizeColumns(allColumnIds);
    }
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.updatetable(this.rowData, this.total);
    this.autoSizeAll();
  }

  pinColumns(event) {
    if (event.columns[0].pinned) {
      if (!this.pinned.includes(event.columns[0].colId))
        this.pinned.push(event.columns[0].colId);
    } else {
      this.pinned = this.pinned.filter((col) => col !== event.columns[0].colId);
    }
  }

  updatesorting(sort) {
    if (sort.length > 0) {
      this.pagedata.isDesc = sort[0].sort === 'desc';
      this.pagedata.sortBy =
        sort[0].colId.charAt(0).toUpperCase() + sort[0].colId.slice(1);
    } else {
      delete this.pagedata.isDesc;
      delete this.pagedata.sortBy;
    }
    this.updatepageData.emit(this.pagedata);
  }

  updateCols() {
    this.columns = [];
    this.pinnedCols = [];
    this.allcols.forEach((col) => {
      if (
        this.showCols.filter((sh) => sh === col.field).length > 0 ||
        col.pinned
      ) {
        this.columns.push(col);
      }
    });
    this.columns.forEach((col) => {
      if (!col.lockPosition)
        this.pinnedCols.push({ label: col.headerName, value: col.field });
    });

    this.pinned = this.pinned.filter(
      (pi) => this.pinnedCols.filter((col) => col.value === pi).length > 0
    );
  }

  changesorting(sort) {
    this.gridOption.api.showLoadingOverlay();
    this.updatesorting(this.gridOption.api.getSortModel());
  }

  pinCols() {
    this.columns.forEach((col) => {
      if (
        this.pinned.filter((sh) => sh === col.field).length > 0 ||
        col.lockPosition
      ) {
        this.gridOption.columnApi.setColumnPinned(col.field, 'left');
      } else {
        this.gridOption.columnApi.setColumnPinned(col.field, null);
      }
    });
  }

  paginate(data) {
    this.gridOption.api.showLoadingOverlay();
    this.paginator.page = data.page;
    this.paginator.rows = data.rows;
    this.pagedata.pageNumber = data.page + 1;
    this.pagedata.pageSize = data.rows;
    this.updatepageData.emit(this.pagedata);
  }

  updateselection(row) {
    let data =
      this.gridApi.getSelectedNodes() &&
      this.gridApi.getSelectedNodes().length > 0
        ? this.gridApi.getSelectedNodes()[0].data
        : null;
    this.updateSelection.emit(data);
  }
}
