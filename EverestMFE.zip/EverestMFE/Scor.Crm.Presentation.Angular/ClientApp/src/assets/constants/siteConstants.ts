export enum SiteConstants {
  UserToken = 'UserToken',
  authorizationApiUrl = 'authorizationApiUrl',
  authorizationApiController = 'Authorize',
  crmController = 'Crm',
  codeController = 'api/Code',
}
