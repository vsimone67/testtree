import { Routes } from '@angular/router';
import { FlightsSearchComponent } from './flights-search/flights-search.component';
import { VinnypageComponent } from './vinnypage/vinnypage.component';

export const FLIGHTS_ROUTES: Routes = [
    {
      path: 'flights-search',
      component: FlightsSearchComponent
    },
     {
      path: 'vinny',
      component: VinnypageComponent
    }
];
