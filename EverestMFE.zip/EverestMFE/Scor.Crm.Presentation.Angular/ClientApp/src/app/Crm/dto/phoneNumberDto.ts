import { DemographicInfoGroupDto } from './demographicInfoGroupDto';
import { CodeDto } from './codeDto';

export interface PhoneNumberDto {
    phoneNumberId: string;
    accessCode: string;
    areaCode: string;
    countryCode: string;
    demographicInfoGroupId: string | null;
    exchange: string;
    extension: string;
    isPrimaryPhone: boolean | null;
    localNumber: string;
    phoneNumber1: string;
    phoneNumberTypeId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    demographicInfoGroup: DemographicInfoGroupDto;
    phoneNumberType: CodeDto;
}