import { Injectable } from '@angular/core';
import { HttpService } from '../../../services/http/http-service.service';
import { serviceBase } from '../../documents/internal-services/servicebase';
import { AddNoteDto } from '../models/AddNoteDto';
import { GetNotesByParentAndGroupCriteria } from '../models/GetNotesByParentAndGroupCriteria';
import { NoteGroupMemberDto } from '../models/noteGroupMemberDto';

@Injectable({
  providedIn: 'root',
})
export class NotesService extends serviceBase {
  private _noteUrl!: string;

  get noteUrl(): string {
    return this._noteUrl;
  }
  set noteUrl(value: string) {
    this._noteUrl = value;
  }

  constructor(protected _httpService: HttpService) {
    super(_httpService);
  }

  async getNotes(criteria: GetNotesByParentAndGroupCriteria) {
    return await this._httpService.postData<Array<NoteGroupMemberDto>>(
      `${this._noteUrl}/GetNotesByParentAndGroup`,
      criteria
    );
  }

  async addNote(note: AddNoteDto) {
    return await this._httpService.postData(
      `${this._noteUrl}/CreateNote`,
      note
    );
  }
}
