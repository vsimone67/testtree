import { Component, OnInit, Input, SimpleChange, OnChanges } from '@angular/core';
import { RetentionLimitViewModel } from '../../models/NaarSplit/retentionLimitViewModel';
import { formatNumberToCurrency } from '@shared/functions/formatNumberToCurrency';
import { formatBoolean } from '@shared/functions/formatBoolean';

@Component({
  selector: 'retention-limit',
  templateUrl: './retention-limit.component.html',
  styleUrls: ['./retention-limit.component.css']
})
export class RetentionLimitComponent implements OnInit, OnChanges {

  @Input() retentionLimit: RetentionLimitViewModel;

  baseNaarAmt: string;
  baseReinsAMt: string;
  maxRetentionLimit: string;
  excludedFromRetention: string;

  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    // if options are passed, override default
    if (changes.retentionLimit != undefined) {
      this.baseNaarAmt = formatNumberToCurrency(changes.retentionLimit.currentValue.baseNAARAmount);
      this.baseReinsAMt = formatNumberToCurrency(changes.retentionLimit.currentValue.baseReinsuredAmount);
      this.maxRetentionLimit = formatNumberToCurrency(changes.retentionLimit.currentValue.maxGradedRetentionLimit);
      this.excludedFromRetention = formatBoolean(changes.retentionLimit.currentValue.isExcludedFromRetention);

    }

  }
}
