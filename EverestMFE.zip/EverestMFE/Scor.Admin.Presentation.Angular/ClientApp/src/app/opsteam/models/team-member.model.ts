export interface TeamMemberModel {

    companyOperationalTeamRelId: string;
    companyId: string;
    operationalTeamId: string;
    operationalTeamName: string;
    companyOperationalTeamRelCreateDate: Date;
    companyOperationalTeamRelCreateById: string;
    companyOperationalTeamRelCreateBy: string;
    companyOperationalTeamRelModifiedDate: Date;
    companyOperationalTeamRelModifiedById: string;
    companyOperationalTeamModifiedBy: string;
    companyOperationalTeamRelStatus: string;
    companyOperationalTeamRelStatusId: string;
    companyName: string;
    companyStatus: string;
}