import { CessionTransactionModel } from "./CessionTransactionModel";
import { CessionHistoryModel } from "./CessionHistoryModel";
import { CessionOverrideModel } from "./CessionOverrideModel";
import { CessionDetailsModel } from "./CessionDetailsModel";
export interface CessionCompleteModel {
  cessions: CessionDetailsModel;
  override: CessionOverrideModel;
  histories: CessionHistoryModel[];
  transactions: CessionTransactionModel[];
}
