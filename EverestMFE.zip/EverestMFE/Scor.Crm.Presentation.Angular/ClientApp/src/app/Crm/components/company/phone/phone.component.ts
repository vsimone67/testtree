import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {PhoneNumberDto} from "../../../dto/phoneNumberDto";
import {SiteConstants} from "@constants/siteConstants";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'phone',
  templateUrl: './phone.component.html',
  styleUrls: ['./phone.component.css']
})
export class PhoneComponent implements OnInit {
  @Input() phones;
  @Input() groupId;
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;
  showDialog: boolean = false
  selectedPhone: PhoneNumberDto;
  mode: string;

  constructor(private crmService : CrmService, private confirm:ConfirmationService,
              private _messageService:MessageService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 200px;";
    this.gridOptions =<GridOptions>{}
    this.gridOptions.getRowStyle=  (params) => {
      if (params.data.isPrimaryPhone) {
        return { fontWeight: '700' };
      }
    };
    this.columnDefs = this.createColumns();
  }

  EditPhone(data) {
    this.showDialog = true;
    this.selectedPhone = data.rowData;
    this.mode = 'edit'
  }

  deletePhone(data) {
    if(data.rowData.isPrimaryPhone){
      this._messageService.add({severity: "info", detail: "we cannot delete a primary phone Number"});

    }
    else {
      this.confirm.confirm({
        message: "Do you want to delete this Phone Number ?",
        header: "Delete Confirmation",
        icon: "pi pi-info-circle",
        rejectButtonStyleClass: "cleardata",
        accept: () => {
          let id=data.rowData.phoneNumberId
          this.crmService.DeletePhoneNumber(id).then(liste=>{
            this.refreshData.emit()
            this._messageService.add({severity: "success", detail: "Phone Number Has been Deleted"});
          })
        },
        reject: () => {},
      });
    }
  }

  addPhone() {
    this.showDialog = true;
    this.selectedPhone =<PhoneNumberDto>{};
    this.mode = 'add'
  }

  validate(phone:PhoneNumberDto) {
    if (this.mode == 'add') {
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      phone.createdBy=user.userId;
      phone.modifiedBy=user.userId;
      this.crmService.AddPhoneNumber(phone).then(aka => this.refreshData.emit())
    } else {
      this.crmService.EditPhoneNumber(phone).then(aka => this.refreshData.emit())

    }
  }

  hidedialog() {
    this.showDialog = false;
  }

  private createColumns() {
    return <ColDef[]>[
      {
        field: "phoneNumberType.codeName",
        headerName: "Type",
      },
      {
        field: "phoneNumber1",
        headerName: "Number",
      },
      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.EditPhone.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deletePhone.bind(this),
          icon: "pi-trash",

        }
      }
    ];
  }
}
