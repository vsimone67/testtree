import { CompanyDto } from './companyDto';
import { ContactDto } from './contactDto';
import { CodeDto } from './codeDto';
import { CompanyContactGroupDto } from './companyContactGroupDto';

export interface CompanyContactGroupMemberDto {
    contactId: string;
    companyId: string;
    contactRoleTypeId: string;
    groupId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    contact: ContactDto;
    contactRoleType: CodeDto;
    group: CompanyContactGroupDto;
}