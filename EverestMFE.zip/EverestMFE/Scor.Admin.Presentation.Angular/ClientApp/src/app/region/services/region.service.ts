import { Injectable } from '@angular/core';
import { User } from '@auth/models/user';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService, HttpService } from '@scor/common';
import { CountryModel } from '../models/country-model';
import { RegionModel } from '../models/region-model';

@Injectable({
  providedIn: 'root',
})
export class RegionService {
  baseApiUrl: string;
  currentUser: User;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this.baseApiUrl = `${this._appSettingsService.GetValue(
      'apiGatewayUrl'
    )}/regions/`;
    this.currentUser = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
  }

  async getRegions() {
    return await this._httpService.getData<RegionModel[]>(
      `${this.baseApiUrl}GetRegions`
    );
  }

  async getCountriesForRegion(regionId: string) {
    return await this._httpService.getData<CountryModel[]>(
      `${this.baseApiUrl}GetCountriesForReqion?regionId=${regionId}`
    );
  }

  async getAssignableCountries(regionId: string) {
    return await this._httpService.getData<CountryModel[]>(
      `${this.baseApiUrl}GetAssignableCountries?regionId=${regionId}`
    );
  }

  async editRegion(regionId: string, regionName: string) {
    const body = { RegionId: regionId, RegionName: regionName };

    return await this._httpService.putData(
      `${this.baseApiUrl}EditRegion`,
      body
    );
  }

  async addCountryToRegion(regionId: string, countryId: string) {
    const body = {
      RegionId: regionId,
      CountryId: countryId,
      UserId: this.currentUser.id,
    };

    return await this._httpService.postData(
      `${this.baseApiUrl}AddCountryToRegion`,
      body
    );
  }

  async removeCountryFromRegion(regionsCountryRelationshipId: string) {
    const body = {
      RegionsCountryRelationshipId: regionsCountryRelationshipId,
      UserId: this.currentUser.id,
    };

    return await this._httpService.postData(
      `${this.baseApiUrl}RemoveCountryFromRegion`,
      body
    );
  }
}
