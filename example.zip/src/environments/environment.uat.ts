export const environment = {
  production: false,
  authorizationApiUrl: "http://USVDEVEVRSTAS3:3356/api",
  apiGatewayUrl: "http://USVDEVEVRSTAS3:3351"
};

