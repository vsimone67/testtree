import { Injectable } from '@angular/core';
import { CessionHistoryAggregate } from '@assumed/models/CessionHistoryAggregate';
import { CessionHistoryModel } from '@assumed/models/CessionHistoryModel';
import { CessionOverrideAggregate } from '@assumed/models/cessionOverrideAggregate';
import { CessionPoolBindingOverrideAggregateModel } from '@assumed/models/CessionPoolBindingOverrideAggregateModel';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from './app-settings.service';

import { HttpService } from './http-service.service';

@Injectable({
  providedIn: 'root'
})
export class AssumedAggregatorService {

  private _aggregatorUrl: string;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    this._aggregatorUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.assumedAggregatorController}`;
  }

  async AddCessionHistory(cessionHistory: CessionHistoryModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateAddCessionHistory`, cessionHistory);
  }

  async EditCessionHistory(cessionHistory: CessionHistoryAggregate) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateEditCessionHistory`, cessionHistory);
  }

  async SaveCessionOverride(cessionGeneral: CessionOverrideAggregate) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateCessionOverride`, cessionGeneral);
  }

  async EditPoolBindingOverride(poolBinding: CessionPoolBindingOverrideAggregateModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateEditCessionPoolOverride`, poolBinding);
  }

}
