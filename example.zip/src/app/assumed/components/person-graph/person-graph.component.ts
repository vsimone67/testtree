import {
  Component,
  OnInit,
  ViewEncapsulation,
  Output,
  EventEmitter,
  Input,
  OnChanges,
  SimpleChange,
} from "@angular/core";
import * as shape from "d3-shape";
import { Edge, Node, Layout } from "@swimlane/ngx-graph";
import { Subject } from "rxjs";
import { PersonModel } from "@assumed/models/PersonModel";
import { CessionCompleteModel } from "@assumed/models/CessionCompleteModel";
import { CessionDetailsModel } from "@assumed/models/CessionDetailsModel";
import { ClaimService } from "src/app/claim/services/claim.service";
import { CustomDagreNodesOnlyLayout } from "./DagreNodesOnlyLayout";
import { GraphEventModel } from "@assumed/models/GraphEventModel";
import { NodeConstants } from "@constants/nodeConstants";

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: "person-graph",
  templateUrl: "./person-graph.component.html",
  styleUrls: ["./person-graph.component.css"],
})
export class PersonGraphComponent implements OnInit, OnChanges {
  @Input() person: PersonModel;
  @Output() nodeClicked = new EventEmitter();

  // ngx variables
  layout: Layout;
  curve: any = shape.curveLinear;
  draggingEnabled: boolean = true;
  panningEnabled: boolean = true;
  zoomEnabled: boolean = true;
  autoZoom: boolean = false;
  autoCenter: boolean = false;
  update$: Subject<boolean> = new Subject();
  center$: Subject<boolean> = new Subject();
  zoomToFit$: Subject<boolean> = new Subject();

  cessionNodes: Node[] = [];
  cessionLinks: Edge[] = [];

  // set orientation for graph
  layoutSettings = {
    orientation: "TB",
  };

  // node id's used to reference node data and create relationships
  personId: string = "person";
  cessionId: string = "cession";
  cessionLinkId: string = "cessionLink";
  splitId: string = "split";
  splitLinkId: string = "splitLink";
  poolId: string = "pool";
  poolLinkId: string = "poolLink";
  stackId: string = "stack";
  stackLinkId: string = "stackLink";
  cessionOverrideId: string = "overide";
  cessionOverrideLinkId: string = "overrideLink";
  cessionHistoryId: string = "history";
  cessionHistoryLinkId: string = "historyLink";
  cessionTransactionId: string = "transaction";
  cessionTransactionLinkId: string = "transactionLink";
  cessionRetroCessionId: string = "retro";
  cessionRetroCessionLinkId: string = "retroLink";
  claimId: string = "claim";
  claimLinkId: string = "claimLink";
  constructor(private _claimService: ClaimService) {
    this.layout = new CustomDagreNodesOnlyLayout();
  }

  ngOnInit(): void {}

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if options are passed, override default
    if (changes.person != undefined) {
      this.person = changes.person.currentValue;

      // sort by scorRetentionSequenceNumber
      this.person.cessions.sort((a, b) => {
        // Sort by scorRetentionSequenceNumber
        // If the first item has a higher number, move it up
        // If the first item has a lower number, move it down
        if (
          a.cessions.scorRetentionSequenceNumber >
          b.cessions.scorRetentionSequenceNumber
        )
          return 1;
        if (
          b.cessions.scorRetentionSequenceNumber >
          a.cessions.scorRetentionSequenceNumber
        )
          return -1;
      });
      this.ConvertCessionToGraph();
      this.updateGraph();
    }
  }

  centerGraph() {
    this.zoomToFit$.next(true);
  }
  fitGraph() {
    this.center$.next(true);
  }

  updateGraph() {
    this.update$.next(true);
  }

  ConvertCessionToGraph() {
    // Add top person node, all child nodes will branch off of this
    this.resetGraph();

    if (this.person !== null) {
      // Angular will call this twice as the @Input get updated, check to make sure the person @Input is valid before you draw it

      this.addNode(
        this.personId,
        this.person.firstName + " " + this.person.lastName,
        this.person,
        "",
        "",
        "Person",
        0,
        0,
        ""
      );

      // Add Cessions to Person Node
      let currentCession = 1;
      this.person.cessions.forEach((cession) =>
        this.addCession(cession, currentCession++)
      );
    }
  }

  addCession(cession: CessionCompleteModel, currentCession) {
    var tooltip = `Cession: ${cession.cessions.generaliCessionNumber}\n Policy: ${cession.cessions.policyNumber}\n Coverage No: ${cession.cessions.coverageNumber}\n Cession Seq: ${cession.cessions.cessionSequence}\n Unique Plan No: ${cession.cessions.uniquePlanNumber}\n `;
    this.addNode(
      this.cessionId + currentCession.toString(),
      `Scor Seq #: ${cession.cessions.scorRetentionSequenceNumber}`,
      cession,
      this.cessionLinkId + currentCession.toString(),
      this.personId,
      "Cession",
      currentCession,
      cession.cessions.generaliCessionNumber,
      tooltip
    );
  }

  addCessionDetail(cession: CessionCompleteModel, currentCession: number) {
    this.addEmptySplit(
      cession.cessions,
      currentCession,
      cession.cessions.scorRetentionSequenceNumber
    );

    // Add Cession History
    this.addCessionHistory(
      cession.histories,
      currentCession,
      cession.cessions.scorRetentionSequenceNumber
    );

    // Add Cession Transaction
    this.addCessionTransaction(
      cession.transactions,
      currentCession,
      cession.cessions.scorRetentionSequenceNumber
    );

    //TODO: This was populated in prototype now defaulting to blanks

    // Add Retro Cessions
    this.addBlankRetroCession(
      cession.cessions,
      currentCession,
      cession.cessions.scorRetentionSequenceNumber
    );
    // Add Pool
    this.addBlankPool(
      cession.cessions,
      currentCession,
      cession.cessions.scorRetentionSequenceNumber
    );

    // Add Stack
    this.addBlankStack(
      cession.cessions,
      currentCession,
      cession.cessions.scorRetentionSequenceNumber
    );

    // Add Cession OveridescorRetentionSequenceNumber);

    this._claimService
      .cessionHasClaims(cession.cessions.cessionId)
      .then((hasClaim) => {
        if (hasClaim) {
          this.addBlankClaim(
            cession.cessions,
            currentCession,
            cession.cessions.scorRetentionSequenceNumber
          );
          this.updateGraph();
        }
      });

    // update the graph and drop down the nodes
    this.updateGraph();
  }

  removeCessionDetail(currentCession: number) {
    //TODO: refactor this to be more efficient, it works for now

    var idToDelete = []; // holds the id in the array to delete

    // iternate through the cessionNode array and capture all the id's that need to be removed
    this.cessionNodes.forEach((node) => {
      if (node.id.indexOf(currentCession.toString()) > -1) {
        if (
          node.id.indexOf(this.cessionId + currentCession.toString()) === -1
        ) {
          idToDelete.push(node.id);
        }
      }
    });

    // iterate through all the id's that were flagged to delete and remove them from the cessionNode array
    idToDelete.forEach((index) => {
      let indexToDelete = this.cessionNodes.findIndex((d) => d.id === index); //find index in your array
      this.cessionNodes.splice(indexToDelete, 1); //remove element from array
    });

    // iternate through the cessionLink array and capture all the id's that need to be removed
    idToDelete = [];
    this.cessionLinks.forEach((node) => {
      if (node.id.indexOf(currentCession.toString()) > -1) {
        if (
          node.id.indexOf(this.cessionLinkId + currentCession.toString()) === -1
        ) {
          idToDelete.push(node.id);
        }
      }
    });

    // iterate through all the id's that were flagged to delete and remove them from the cessinnLink array
    idToDelete.forEach((index) => {
      let indexToDelete = this.cessionLinks.findIndex((d) => d.id === index); //find index in your array
      this.cessionLinks.splice(indexToDelete, 1); //remove element from array
    });

    // redraw the graph on the screen with the updated nodes and links that were removed
    this.updateGraph();
  }

  addCessionHistory(
    cessionHistory,
    currentCession: number,
    everestCession: number
  ) {
    this.addNode(
      this.cessionHistoryId + currentCession.toString(),
      NodeConstants.history,
      cessionHistory,
      this.cessionHistoryLinkId + currentCession.toString(),
      this.cessionId + currentCession.toString(),
      NodeConstants.history,
      currentCession,
      everestCession,
      ""
    );
  }

  addCessionTransaction(
    cessionTransaction,
    currentCession: number,
    everestCession: number
  ) {
    this.addNode(
      this.cessionTransactionId + currentCession.toString(),
      NodeConstants.transaction,
      cessionTransaction,
      this.cessionTransactionLinkId + currentCession.toString(),
      this.cessionId + currentCession.toString(),
      NodeConstants.transaction,
      currentCession,
      everestCession,
      ""
    );
  }

  addBlankRetroCession(
    cession: CessionDetailsModel,
    currentCession: number,
    everestCession: number
  ) {
    this.addNode(
      this.cessionRetroCessionId + currentCession.toString(),
      NodeConstants.retro,
      cession,
      this.cessionRetroCessionLinkId + currentCession.toString(),
      this.cessionId + currentCession.toString(),
      NodeConstants.retro,
      currentCession,
      everestCession,
      ""
    );
  }

  addBlankStack(
    cession: CessionDetailsModel,
    currentCession: number,
    everestCession: number
  ) {
    this.addNode(
      this.stackId + currentCession.toString(),
      NodeConstants.stack,
      cession,
      this.stackLinkId + currentCession.toString(),
      this.cessionId + currentCession.toString(),
      NodeConstants.stack,
      currentCession,
      everestCession,
      ""
    );
  }

  addBlankPool(
    cession: CessionDetailsModel,
    currentCession: number,
    everestCession: number
  ) {
    this.addNode(
      this.poolId + currentCession.toString(),
      NodeConstants.pool,
      cession,
      this.poolLinkId + currentCession.toString(),
      this.cessionId + currentCession.toString(),
      NodeConstants.pool,
      currentCession,
      everestCession,
      ""
    );
  }
  addCessionOverride(cessionOverride, currentCession, everestCession: number) {
    // dp not show the override node if there is no data
    if (cessionOverride !== null) {
      this.addNode(
        this.cessionOverrideId + currentCession.toString(),
        NodeConstants.override,
        cessionOverride,
        this.cessionOverrideLinkId + currentCession.toString(),
        this.cessionId + currentCession.toString(),
        NodeConstants.override,
        currentCession,
        everestCession,
        ""
      );
    }
  }

  addBlankClaim(
    cession: CessionDetailsModel,
    currentCession: number,
    everestCession: number
  ) {
    this.addNode(
      this.claimId + currentCession.toString(),
      NodeConstants.claim,
      cession,
      this.claimLinkId + currentCession.toString(),
      this.cessionId + currentCession.toString(),
      NodeConstants.claim,
      currentCession,
      everestCession,
      ""
    );
  }
  addEmptySplit(
    cession: CessionDetailsModel,
    currentCession: number,
    cessionNumber: number
  ) {
    this.addNode(
      this.splitId + currentCession.toString(),
      NodeConstants.split,
      cession,
      this.splitLinkId + currentCession.toString(),
      this.cessionId + currentCession.toString(),
      NodeConstants.split,
      currentCession,
      cessionNumber,
      ""
    );
  }

  addNode(
    nodeId: string,
    nodeLabel: string,
    nodeData: any,
    linkId: string,
    linkSource: string,
    dataType: string,
    cessionNumber: number,
    everestCessionNumber: number,
    tooltip: string
  ) {
    this.cessionNodes.push({
      id: nodeId,
      label: nodeLabel,
      data: {
        metaData: dataType,
        payload: nodeData,
        parentCession: cessionNumber,
        isExpanded: false,
        everestCessionNumber: everestCessionNumber,
        tooltip: tooltip,
      },
    });

    // balnk link id means top node and it will not link to anyting so do not associate anyting with it
    if (linkId != "") {
      this.cessionLinks.push({
        id: linkId,
        source: linkSource,
        target: nodeId,
      });
    }
  }

  // when user clicks node sent event to parent to evalute
  displayNodeData(event: GraphEventModel) {
    // if cession is clicked expand or collapse cession
    if (event.data.metaData === "Cession") {
      if (!event.data.isExpanded) {
        this.resetAllCessions();
        event.data.isExpanded = true;
        this.addCessionDetail(event.data.payload, event.data.parentCession);
      } else {
        event.data.isExpanded = false;
        this.removeCessionDetail(event.data.parentCession);
      }
    } else {
      this.resetNodes();
      event.data.isExpanded = !event.data.isExpanded; // make all
    }
    this.nodeClicked.emit(event);
  }

  resetGraph() {
    this.cessionNodes = [];
    this.cessionLinks = [];
  }

  resetNodes() {
    this.cessionNodes.forEach((node) => {
      if (node.data.metaData !== NodeConstants.cession) {
        node.data.isExpanded = false;
      }
    });
  }

  resetCession() {
    this.cessionNodes.forEach((node) => {
      if (node.data.metaData === NodeConstants.cession) {
        node.data.isExpanded = false;
      }
    });
  }

  resetAllCessions() {
    this.cessionNodes.forEach((node) => {
      if (node.data.metaData === NodeConstants.cession) {
        node.data.isExpanded = false;
        this.removeCessionDetail(node.data.parentCession);
      }
    });
  }

  // getcolor(label, level) {

  //   if (level.toLowerCase().includes('cession')) return '#9E6C80'
  //   else if (level.toLowerCase().includes('person')) return '#0e6a81'
  //   else return '#30A9C7'
  // }

  getcolor(node: Node) {
    var retColor = "#30A9C7"; // default color

    if (node.id.toLowerCase().includes("cession") && !node.data.isExpanded) {
      retColor = "#9E6C80";
    } else if (
      node.id.toLowerCase().includes("cession") &&
      node.data.isExpanded
    ) {
      retColor = "#800000";
    } else if (node.data.isExpanded) {
      retColor = "#00bfff";
    }

    return retColor;
  }
}
