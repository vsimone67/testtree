export const environment = {
  production: false,
  env: 'prod',
  standalone: true,
};
