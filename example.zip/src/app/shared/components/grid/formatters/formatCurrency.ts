import {formatNumber, formatNumberCent, formatNumberSplits} from "./formatNumber";

export function formatCurrency(data) {
  return "$" + formatNumber(data);
}

export function formatCurrencyCent(data) {
  return "$" + formatNumberCent(data);
}

export function formatCurrencySplits(data) {
  return "$" + formatNumberSplits(data);
}
