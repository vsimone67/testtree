import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {AddressDto} from "../../../dto/addressDto";
import {SiteConstants} from "@constants/siteConstants";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {
  @Input() address;
  @Input() groupId;
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;
  mode: string;
  showDialog: boolean;
  selectedAddress: AddressDto

  constructor(private crmService: CrmService, private confirm: ConfirmationService,
              private _messageService: MessageService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 200px;";
    this.gridOptions = <GridOptions>{}
    this.gridOptions.getRowStyle = (params) => {
      if (params.data.isPrimaryAddress) {
        return {fontWeight: '700'};
      }
    };
    this.columnDefs = this.createColumns();
  }

  EditAddress(data) {
    this.mode = 'edit';
    this.showDialog = true;
    this.selectedAddress = data.rowData;
  }

  deleteAddress(data) {
    if (data.rowData.isPrimaryAddress) {
      this._messageService.add({severity: "info", detail: "we cannot delete a primary Address"});

    } else {
      this.confirm.confirm({
        message: "Do you want to delete this Address ?",
        header: "Delete Confirmation",
        icon: "pi pi-info-circle",
        rejectButtonStyleClass: "cleardata",
        accept: () => {
          let id = data.rowData.addressId
          this.crmService.DeleteAddress(id).then(liste => {
            this.refreshData.emit()
            this._messageService.add({severity: "success", detail: "Address Has been Deleted"});
          })
        },
        reject: () => {
        },
      });
    }
  }

  addAddress() {
    this.mode = 'add';
    this.showDialog = true;
    this.selectedAddress = <AddressDto>{};
  }

  validate(address: AddressDto) {
    if (this.mode == 'add') {
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      address.createdBy = user.userId;
      address.modifiedBy = user.userId;
      address.demographicInfoGroupId = this.groupId
      this.crmService.AddAddress(address).then(aka => this.refreshData.emit())
    } else {
      this.crmService.EditAddress(address).then(aka => this.refreshData.emit())

    }
  }

  hidedialog() {
    this.showDialog = false;
  }

  private createColumns() {
    return <ColDef[]>[
      {
        field: "addressType.codeName",
        headerName: "Type",
      },
      {
        field: "addressLine1",
        headerName: "Address",
      },
      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.EditAddress.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteAddress.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }
}
