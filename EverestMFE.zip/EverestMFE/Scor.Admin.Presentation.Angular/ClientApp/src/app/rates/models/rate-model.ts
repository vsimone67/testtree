export interface RateModel {
    exchangeCountryId: string;
    exchangeRate: number;
    startDate: Date;
    endDate: Date;
    countryCode: string;
}