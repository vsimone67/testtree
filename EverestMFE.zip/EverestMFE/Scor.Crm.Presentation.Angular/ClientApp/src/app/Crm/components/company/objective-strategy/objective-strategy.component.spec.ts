import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObjectiveStrategyComponent } from './objective-strategy.component';

describe('ObjectiveStrategyComponent', () => {
  let component: ObjectiveStrategyComponent;
  let fixture: ComponentFixture<ObjectiveStrategyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObjectiveStrategyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ObjectiveStrategyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
