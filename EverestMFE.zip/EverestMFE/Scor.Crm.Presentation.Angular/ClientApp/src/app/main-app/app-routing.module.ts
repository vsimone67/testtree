import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainCrmComponent } from '../Crm/components/main-crm/main-crm.component';
import { CoreComponent } from './core/core.component';
import { EmptyComponent } from './empty/empty.component';

const routes: Routes = [
  {
    path: 'crm',
    component: CoreComponent,
    children: [{ path: 'home', component: MainCrmComponent }],
  },
  { path: '**', component: EmptyComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
