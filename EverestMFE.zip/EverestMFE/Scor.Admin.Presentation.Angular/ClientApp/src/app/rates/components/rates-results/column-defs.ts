export const defaultsCols = [
    {
      headerName: 'Country Code',
      field: 'countryCode', width: 150, resizable: true, sortable: true,
    }, {
      headerName: 'Exchange Rate',
      field: 'exchangeRate',
      minWidth: 150,
      resizable: true,
      sortable: true
    }, {
      headerName: 'Effective Date', field: 'effectiveDate', width: 50,
      resizable: true, sortable: true,  
    },
    {
      headerName: 'End Date', field: 'endDate',
      width: 200, resizable: true, sortable: true,
    }, 
  ]
  
  export const defaultcols = ['countryCode', 'exchangeRate', 'effectiveDate', 'endDate'];
  export const pinned = []
  