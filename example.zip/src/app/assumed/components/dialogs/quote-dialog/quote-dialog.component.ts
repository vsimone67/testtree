import { Component, OnInit, Input } from '@angular/core';
import { QuoteModel } from '@assumed/models/QuoteModel';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';

@Component({
  selector: 'quote-dialog',
  templateUrl: './quote-dialog.component.html',
  styleUrls: ['./quote-dialog.component.css']
})
export class QuoteDialogComponent extends DialogBase implements OnInit {

  @Input() quote: QuoteModel;
  constructor() { super(); }

  ngOnInit(): void {
  }

}
