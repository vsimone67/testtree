import { Output, EventEmitter, Input, Component } from "@angular/core";
import { DialogBase } from "./dialog-base";

@Component({
  template: "",
})
export class EditDialogBase<T> extends DialogBase {
  @Input() dialogData: T;
  @Output() onDialogSubmit: EventEmitter<T> = new EventEmitter<T>();

  showDialog: boolean = true;

  constructor() {
    super();
  }

  ngOnInit() {}

  submitDialog() {
    this.onDialogSubmit.emit(this.dialogData);
  }
}
