export interface ScorGradedLimitScheduleModel{
    ScorGradedLimitScheduleId: string;
    RetentionScheduleName: string;
    CreateDate: Date | string;
    CreatedBy: string | null;
    ModifiedDate: Date | string | null;
    ModifiedBy: string | null;
    ModuleReference: string | null;
    RowStatusId: string | null;
}