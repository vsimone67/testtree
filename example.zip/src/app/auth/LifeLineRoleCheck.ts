import { AppModule } from "../app.module";
import { LifeLineRoles } from "./models/lifeLineRoles";
import { AuthenticationService } from "./services/authentication.service";

export class LifeLineRoleCheck {
  static canViewCessionAnalysis(): boolean {
    return this.isUser();
  }

  static canViewLogging() {
    return this.isUser();
  }

  static canEditCession() {
    return this.isUser();
  }

  static isAdminisrator() {
    return (
      this.isCessionDetailWrite() ||
      this.isCessionDetailCompanyWrite() ||
      this.isRetroEventsWrite()
    );
  }

  static isUser() {
    var authenticationService: AuthenticationService = AppModule.injector.get(
      AuthenticationService
    );
    return authenticationService.isUserInRoles([
      LifeLineRoles.RetroAdmin,
      LifeLineRoles.Adminstrator,
      LifeLineRoles.RetroUser,
      LifeLineRoles.LifeLineUser,
      LifeLineRoles.AccountRep,
      LifeLineRoles.AccountRepManager,
    ]);
  }

  static isCessionDetailWrite() {
    var authenticationService: AuthenticationService = AppModule.injector.get(
      AuthenticationService
    );
    return authenticationService.isUserInRoles([
      LifeLineRoles.Adminstrator,
      LifeLineRoles.AccountRep,
      LifeLineRoles.AccountRepManager,
    ]);
  }

  static isCessionDetailCompanyWrite() {
    var authenticationService: AuthenticationService = AppModule.injector.get(
      AuthenticationService
    );
    return authenticationService.isUserInRoles([
      LifeLineRoles.Adminstrator,
      LifeLineRoles.AccountRep,
      LifeLineRoles.AccountRepManager,
    ]);
  }

  static isRetroEventsWrite() {
    var authenticationService: AuthenticationService = AppModule.injector.get(
      AuthenticationService
    );
    return authenticationService.isUserInRoles([
      LifeLineRoles.RetroAdmin,
      LifeLineRoles.Adminstrator,
    ]);
  }

  static canEditCompany() {
    return this.isCessionDetailWrite();
  }
}
