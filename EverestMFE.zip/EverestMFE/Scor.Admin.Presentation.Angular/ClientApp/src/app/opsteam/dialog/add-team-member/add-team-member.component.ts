import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { TeamMemberModel } from '../../models/team-member.model';
import { OpsteamService } from '../../services/ops-team.service';

@Component({
  selector: 'app-add-team-member',
  templateUrl: './add-team-member.component.html',
  styleUrls: ['./add-team-member.component.css'],
})
export class AddTeamMemberComponent
  extends EditDialogBase<TeamMemberModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  selectedCompany;
  @Input() team;
  @Input() showAll: boolean;

  constructor(private opsTeamService: OpsteamService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    const newList = await this.opsTeamService.getAddableMembers(
      this.team.teamName,
      this.showAll
    );

    this.companyList = [];
    newList.forEach((line: TeamMemberModel) => {
      if (line)
        this.companyList.push({
          label: line.companyName,
          value: line.companyId,
        });
    });
  }

  async saveAddTeamMember() {
    await this.opsTeamService.postNewTeamMember(
      this.team.teamName,
      this.selectedCompany,
      '00000000-0000-0000-0000-000000000000'
    );
    //this.showDialog = false;
    this.submitDialog();
    this.hideDialog();
  }
}
