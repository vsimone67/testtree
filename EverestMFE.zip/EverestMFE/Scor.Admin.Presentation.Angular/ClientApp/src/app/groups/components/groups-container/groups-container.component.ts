import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SecurityGroupsService } from '../../services/security-groups.service';

import { GroupsResultsComponent } from '../groups-results/groups-results.component';

@Component({
  selector: 'app-groups-container',
  templateUrl: './groups-container.component.html',
  styleUrls: ['./groups-container.component.css'],
  providers: [DatePipe],
})
export class GroupsContainerComponent implements OnInit {
  @ViewChild(GroupsResultsComponent) table: GroupsResultsComponent;
  page: any = {
    pageNumber: 1,
    pageSize: 10,
  };
  filters;
  rows;
  selectedRuns: any;
  loadingTable: boolean = false;
  selectedCurrency;

  constructor(
    private groupsService: SecurityGroupsService,
    private router: Router
  ) {}

  ngOnInit(): void {}

  async search(filters: any) {
    if (filters) {
      this.filters = filters;
    }

    if (filters.groupId) {
      const groups = await this.groupsService.getGroupMembers(filters.groupId);

      this.rows = groups;

      this.table.updatetable(groups, groups.length);
    } else {
      this.table.updatetable({}, 0);
    }
  }

  async searchWithExistingFilters() {
    if (this.filters.groupId) {
      const currencies = await this.groupsService.getGroupMembers(
        this.filters.groupId
      );
      this.rows = currencies;

      this.table.updatetable(currencies, currencies.length);
    } else {
      this.table.updatetable({}, 0);
    }
  }

  async selectCurrency(data: any) {}

  async changePage(page) {
    this.selectedRuns = null;
    this.page = page;

    const first = (page - 1) * page.pageSize;
    const last = page * page.pageSize;

    if (this.rows && this.rows.length > 0) {
      this.table.updatetable(this.rows.slice(first, last), page.pageSize);
    } else {
      this.getInitialData();
    }
  }

  async getInitialData() {
    this.loadingTable = false;
    this.rows = [];
    this.table.updatetable(this.rows, 0);
  }
}
