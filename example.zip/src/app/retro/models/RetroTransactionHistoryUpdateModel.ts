export interface RetroTransactionHistoryUpdateModel {
  RetroTransactionId: string;
  ReportToDate: Date;
  CompanyName: string;
  SplitType: string;
  TransactionTypeId: string;
  TransactionIndicator: string;
  IsReversed: boolean;
  TransactionSequence: number; //editable
  TransactionFromDate: Date;//editable
  TransactionToDate: Date;//editable
  SplitAmount: number;
  GrossBasePremium: number | null;//editable
  BaseAllowance: number | null;
  ExciseTax: number | null;//ed
  PremiumTax: number | null;//edi
  GrossTempFlatExtraPremium: number | null;//edi
  TempFlatExtraAllowance: number | null;//edi
  GrossPermFlatExtraPremium: number | null;//ed
  PermFlatExtraAllowance: number | null;//ed
  GrossPolicyFeePremium: number | null;//ed
  PolicyFeeAllowance: number | null;//ed
  CashSurrenderValue: number | null;//ed
  RetroExpense: number | null;//ed
  IsActiveRetro: boolean;
  Note: string;
  UserName: string;
  CessionId: string
  UpdateUserId: string

}
