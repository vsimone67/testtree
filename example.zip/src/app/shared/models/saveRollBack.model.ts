export interface SaveRollbackModel {
  ActionType: string;
  ParentId: string;
  ScreenId: string;
  ScreenName: string;
  Data: any;
}
