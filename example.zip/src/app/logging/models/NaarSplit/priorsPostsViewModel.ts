import { PriorsViewModel } from "./priorsViewModel";
import { PostsViewModel } from "./postsViewModel";

export interface PriorsPostsViewModel {
  priors: PriorsViewModel;
  posts: PostsViewModel;
}
