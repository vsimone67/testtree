import { Component, OnInit } from '@angular/core';
import { events } from '@constants/events.model';
import { EventService } from '@shared/services/event.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css'],
})
export class Page1Component implements OnInit {
  private loading: boolean = false;
  constructor(private messageService: MessageService, private _eventService: EventService) {}

    columnDefs = [
        { field: 'make' },
        { field: 'model' },
        { field: 'price' }
    ];

    rowData = [
        { make: 'Toyota', model: 'Celica', price: 35000 },
        { make: 'Ford', model: 'Mondeo', price: 32000 },
        { make: 'Porsche', model: 'Boxter', price: 72000 }
    ];


  ngOnInit(): void {
    //this.router.initialNavigation();
  }

  onClick() {
      this.messageService.add({severity:'success', summary: 'Success', detail: 'Message From mfetemplate, whew!'});
  }

  onLoading() {
    this.loading = ! this.loading;

    this._eventService.sendEvent(events.loadingEvent, this.loading);
  }
}
