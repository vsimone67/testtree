import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { SecurityRolesService } from 'src/app/roles/services/security-roles.service';
import { RoleMemberModel } from '../../models/role-member-model';
import { RoleModel } from '../../models/role-model';

@Component({
  selector: 'app-add-member-to-role',
  templateUrl: './add-member-to-role.component.html',
  styleUrls: ['./add-member-to-role.component.css'],
})
export class AddMemberToRoleComponent
  extends EditDialogBase<RoleModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() selectedData;
  roleName: string;
  userId;
  roleId;
  users: any = [];

  constructor(private rolesService: SecurityRolesService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.roleId = this.selectedData.roleId;
    this.roleName = this.selectedData.roleName;

    const members = await this.rolesService.getUnassignedMembers(
      this.selectedData.roleId
    );

    this.users = [];
    members.forEach((line: RoleMemberModel) => {
      if (line)
        this.users.push({
          label: line.fullName,
          value: line.userId,
        });
    });
  }

  async confirm() {
    await this.rolesService.addUserToRole(this.userId, this.roleId);
    this.submitDialog();
    this.hideDialog();
  }

  deny() {
    this.hideDialog();
  }

  updateDrops(data) {
    this.userId = data.value;
  }
}
