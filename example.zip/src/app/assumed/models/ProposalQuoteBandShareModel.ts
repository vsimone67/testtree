export interface ProposalQuoteBandShareModel {
  PlanName: string;
  BandName: string;
  ProposalQuoteBandShareModifiedDate: Date | string | null;
  ProposalQuoteBandShareCreateDate: Date | string | null;
  CurrentSharePercent: number | null;
  TargetSharePercent: number | null;
  WonSharePercent: number | null;
  CurrentShareTypeIdCodeName: string;
  ShareDealTypeIdCodeName: string;
  TargetShareTypeIdCodeName: string;
  WonShareTypeIdCodeName: string;
  ProposalQuoteBandReportingFrequencyName: string;
  TargetAlphaSplitFrom: string;
  TargetAlphaSplitTo: string;
  CurrentAlphaSplitFrom: string;
  CurrentAlphaSplitTo: string;
  WonAlphaSplitFrom: string;
  WonAlphaSplitTo: string;
  ProposalQuoteBandShareChangeName: string;
  QuoteBandId: string | null;
  ProposalId: string | null;

}
