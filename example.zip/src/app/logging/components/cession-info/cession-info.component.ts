import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { CessionViewModel } from '../../models/NaarSplit/cessionViewModel';

@Component({
  selector: 'cession-info',
  templateUrl: './cession-info.component.html',
  styleUrls: ['./cession-info.component.css']
})
export class CessionInfoComponent implements OnInit,OnChanges {
  @Input() currentCession: CessionViewModel;

  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {

  }

}
