import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { RetroCessionModel } from "../models/RetroCessionModel";
import { SiteConstants } from "@constants/siteConstants";
import { PoolModel } from "@retro/models/PoolModel";
import { CodeModel } from "@shared/models/CodeModel";
import { environment } from "@environment/environment";
import { vwRetroCessionDetail } from "@retro/models/VwRetroCessionDetail";
import { RetroCessionOverrideModel } from "@retro/models/RetroCessionOverrideModel";
import { RetroRecaptureProgramOverrideModel } from "@retro/models/RetroRecaptureProgramOverrideModel";
import { RetroTransactionHistoryModel } from "@retro/models/RetroTransactionHistoryModel";
import { VwInsuredCessionSearch } from "@retro/models/VwInsuredCessionSearchModel";
import { CessionUpdateInfo } from "@retro/models/CessionUpdateInfo";
import { RetroTransactionHistoryUpdateModel } from "@retro/models/RetroTransactionHistoryUpdateModel";
import { VwRetroPoolTreaties } from "@retro/models/VwRetroPoolTreaties";
import { RetroPoolModel } from "@retro/models/RetroPoolModel";
import { RetroQuotePlanModel } from "@retro/models/retroQuotePlanModel";
import { RetroQuoteBandModel } from "@retro/models/RetroQuoteBandModel";
import { AppSettingsService } from "@shared/services/app-settings.service";
import { PagedListModel } from "@shared/models/grid/paged-list.model";
import { RetroTxnSearchModel } from "@assumed/models/RetroTxnSearchModel";

@Injectable({
  providedIn: "root",
})
export class RetroService {
  private _retroUrl: string;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    //this._retroUrl = `${environment.apiGatewayUrl}/${SiteConstants.retroController}`;
    this._retroUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${
      SiteConstants.retroController
    }`;
  }

  async getRetrDataForCession(cessionId: string) {
    return await this._httpService.getData<Array<RetroCessionModel>>(
      `${this._retroUrl}/GetRetroCessionsByCessionId/${cessionId}`
    );
  }
  async getRetroPools(retroOverrideId: string) {
    return await this._httpService.getData<Array<PoolModel>>(
      `${this._retroUrl}/GetRetroPoolsByOverrideRetroPoolId/${retroOverrideId}`
    );
  }
  async getCodesByCategory(categoryName: string) {
    var cat = encodeURI(categoryName);
    return await this._httpService.getData<Array<CodeModel>>(
      `${this._retroUrl}/GetCodesByCategoryName/${cat}`
    );
  }

  async getRetroDeatails(cessionId: string) {
    return await this._httpService.getData<Array<vwRetroCessionDetail>>(
      `${this._retroUrl}/GetRetroCessionDetails/${cessionId}`
    );
  }

  async getRetroOverrides(retroCessionId: string) {
    return await this._httpService.getData<Array<RetroCessionOverrideModel>>(
      `${this._retroUrl}/GetRetroOverrides/${retroCessionId}`
    );
  }

  async AddRetroOverride(retroOverride: RetroCessionOverrideModel) {
    return await this._httpService.postData(
      `${this._retroUrl}/AddRetroOverride`,
      retroOverride
    );
  }

  async EditRetroOverride(retroOverride: RetroCessionOverrideModel) {
    return await this._httpService.postData(
      `${this._retroUrl}/EditRetroOverride`,
      retroOverride
    );
  }

  async DeleteRetroOverride(retroOverride) {
    return await this._httpService.postData(
      `${this._retroUrl}/DeleteRetroOverride`,
      retroOverride
    );
  }

  async getRetroRecaptureProgramOverrides(retroCessionId: string) {
    return await this._httpService.getData<
      Array<RetroRecaptureProgramOverrideModel>
    >(`${this._retroUrl}/GetRetroRecaptureProgramOverrides/${retroCessionId}`);
  }

  async AddRetroRecaptureProgramOverride(
    retroRecapture: RetroRecaptureProgramOverrideModel
  ) {
    return await this._httpService.postData(
      `${this._retroUrl}/AddRetroRecaptureProgramOverride`,
      retroRecapture
    );
  }

  async EditRetroRecaptureProgramOverride(
    retroRecapture: RetroRecaptureProgramOverrideModel
  ) {
    return await this._httpService.postData(
      `${this._retroUrl}/EditRetroRecaptureProgramOverride`,
      retroRecapture
    );
  }

  async DeleteRetroRecaptureProgramOverride(
    retroRecapture: RetroRecaptureProgramOverrideModel
  ) {
    return await this._httpService.postData(
      `${this._retroUrl}/DeleteRetroRecaptureProgramOverride`,
      retroRecapture
    );
  }

  async getRetroTransactionHistoryCriteria(
    searchCriteria: RetroTxnSearchModel
  ) {
    return await this._httpService.postData(
      `${this._retroUrl}/GetRetroTxnsPaged`,
      searchCriteria
    );
  }

  async updateRetroTransactionHistory(
    model: RetroTransactionHistoryUpdateModel
  ) {
    return await this._httpService.postData(
      `${this._retroUrl}/UpdateRetroTransactionHistory`,
      model
    );
  }

  async getRetroInsuredInfo(cessionId: string) {
    return await this._httpService.getData<CessionUpdateInfo>(
      `${this._retroUrl}/GetInsuredInfo/${cessionId}`
    );
  }

  async saveCessionInsuredInfo(cessionInfo: CessionUpdateInfo) {
    return await this._httpService.postData(
      `${this._retroUrl}/SaveCessionInsuredInfo`,
      cessionInfo
    );
  }

  async getRetroTreaties(retroPoolId: string) {
    return await this._httpService.getData<Array<VwRetroPoolTreaties>>(
      `${this._retroUrl}/GetRetroPoolTreaties/${retroPoolId}`
    );
  }

  async getAllRetroPools() {
    return await this._httpService.getData<Array<RetroPoolModel>>(
      `${this._retroUrl}/GetRetroPools`
    );
  }

  async getQuotePlan(retroQuoteId: string) {
    return await this._httpService.getData<Array<RetroQuotePlanModel>>(
      `${this._retroUrl}/GetRetroPlans/${retroQuoteId}`
    );
  }

  async getRetroBand(retroQuotePlanId: string) {
    return await this._httpService.getData<Array<RetroQuoteBandModel>>(
      `${this._retroUrl}/GetRetroBands/${retroQuotePlanId}`
    );
  }
}
