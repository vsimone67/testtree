export const events = {
  loadingEvent: 'loadingEvent'

};
