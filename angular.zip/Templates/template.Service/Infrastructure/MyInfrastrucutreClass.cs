using System;

namespace template.Service.Infrastructure
{
    public class MyInfrastrucutreClass
    {

    }
}
