import {
  Component,
  OnInit,
  Input,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { ColDef, GridOptions } from 'ag-grid-community';
import { DocumentService } from '../internal-services/document.service';
import { HttpEventType } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { CodeService } from '../internal-services/code.service';
import { FileUpload } from 'primeng/fileupload';
import { FormBuilder, FormGroup } from '@angular/forms';
import { User } from '../models/user';
import { DocumentDto } from '../models/documentModel';
import { CodeDto } from '../models/codeModel';
import { formatDate } from '../../grid/formatters/formatDate';
import { ImageButtonCellComponent } from '../../grid/image-button-cell/image-button-cell.component';

@Component({
  selector: 'document-list',
  templateUrl: './document-list.component.html',
  styleUrls: ['./document-list.component.css'],
})
export class DocumentListComponent implements OnInit {
  @Input() GroupId: string;
  @Input() DocumentUrl: string;
  @Input() CodeUrl: string;
  @Input() User: User;
  @Input() CodeCategory: string;
  @Input() Region: string;
  @Input() SearchField: string;

  @ViewChild('fileInput', { static: false }) fileInput: FileUpload;

  public columnDefs: Array<ColDef>;
  public gridOptions: GridOptions;
  private _gridApi: any;
  public _displayDialog: boolean;
  public _documents: Array<DocumentDto>;
  public _documentToUpload: DocumentDto;
  public _documentCategories: Array<CodeDto>;
  public _selectedDocumnetCategory: CodeDto;
  public _mode: string;
  public _payload: FormGroup;

  constructor(
    public _docService: DocumentService,
    public _codeService: CodeService,
    public _confirmService: ConfirmationService,
    public _formBuilder: FormBuilder
  ) {
    this.gridOptions = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: false,
    };

    this._displayDialog = false;
    this._documentToUpload = <DocumentDto>{};
    this._documentCategories = new Array<CodeDto>();
    this.GroupId = '';
    this.DocumentUrl = '';
    this.CodeUrl = '';
    this.User = <User>{};
    this.Region = '';
    this.SearchField = '';
    this.CodeCategory = '';
    this.fileInput = <FileUpload>{};
    this.columnDefs = [];
    this._documents = [];
    this._selectedDocumnetCategory = <CodeDto>{};
    this._mode = '';
    this._payload = <FormGroup>{};
  }

  ngOnInit() {
    this.createColumnDefs();

    this._payload = this._formBuilder.group({
      profile: [''],
    });
  }

  createColumnDefs() {
    this.columnDefs = [
      {
        headerName: 'Date',
        field: 'documentScanDate',
        valueFormatter: formatDate,
      },
      {
        headerName: 'Created By',
        cellRenderer: (params) =>
          `${params.data.createdByNavigation.firstName} ${params.data.createdByNavigation.lastName}`,
      },
      {
        headerName: 'Category',
        field: 'documentCategory.codeName',
      },
      {
        headerName: 'Name',
        field: 'documentName',
      },
      {
        headerName: '',
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onViewDocument.bind(this),
          icon: 'pi-file',
        },
        width: 20,
        tooltipValueGetter: (params) => 'View Document',
      },
      {
        headerName: '',
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditDocument.bind(this),
          icon: 'pi-pencil',
        },
        width: 20,
        tooltipValueGetter: (params) => 'Edit Document',
      },
      {
        headerName: '',
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onDeleteDocument.bind(this),
          icon: 'pi-times',
        },
        width: 20,
        tooltipValueGetter: (params) => 'Delete Document',
      },
    ];
  }

  async loadDropdowns() {
    if (this._documentCategories.length === 0) {
      this._documentCategories = await this._codeService.getCodesByCategoryId(
        this.CodeCategory,
        'ACTIVE'
      );
    }
  }

  onGridReady(params: any) {
    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this._gridApi = params.api;
  }

  async ngOnChanges(changes: SimpleChanges) {
    // set the passed URL to both services
    this._codeService.codeUrl = this.CodeUrl;
    this._docService.documentUrl = this.DocumentUrl;
    this.User = changes.User.currentValue;
    this._documents = await this._docService.getDocumentByGroup(this.GroupId);
  }

  onAddDocument() {
    this._mode = 'Add';
    this.loadDropdowns();
    this._documentToUpload = <DocumentDto>{};
    this._displayDialog = true;
  }

  async onEditDocument(data: any) {
    this._mode = 'Edit';
    await this.loadDropdowns();
    this._documentToUpload = data.rowData;

    this._documentToUpload.documentReceivedDate = new Date(
      this._documentToUpload.documentReceivedDate
    );

    this._selectedDocumnetCategory = this._documentCategories.find(
      (category) =>
        category.codeId === this._documentToUpload.documentCategoryId
    )!;
    this._displayDialog = true;
  }
  async onDeleteDocument(data: any) {
    this._confirmService.confirm({
      message: 'Do you want to delete this document?',
      header: 'Delete Document',
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'Yes',
      rejectLabel: 'No',
      accept: async () => {
        await this._docService.deleteDocument(
          data.rowData.documentId,
          this.User.userId
        );

        this._documents = await this._docService.getDocumentByGroup(
          this.GroupId
        );
      },
    });
  }

  async onViewDocument(data: any) {
    this._docService
      .downloadFile(data.rowData.documentUrl, this.User.userId)
      .subscribe((data) => {
        switch (data.type) {
          case HttpEventType.Response:
            const downloadedFile = new Blob([data.body!], {
              type: data.body!.type,
            });
            const url = window.URL.createObjectURL(downloadedFile);
            window.open(url);
            break;
        }
      });
  }

  async saveDocument() {
    this._displayDialog = false;

    var currentUser = this.User;
    var fileToUpload = this.fileInput.files[0];

    var receivedDate = this._documentToUpload.documentReceivedDate.toLocaleString();
    var newReceivedDate = receivedDate.substring(0, receivedDate.indexOf(','));

    let input = new FormData();
    input.append('Name', this._documentToUpload.documentName);
    input.append('DocumentCategoryId', this._selectedDocumnetCategory.codeId);
    input.append('ReceivedDate', newReceivedDate);
    input.append('Description', this._documentToUpload.documentDescription);
    input.append('UserId', currentUser.userId);
    input.append('DocumentGroupId', this.GroupId);
    input.append('Region', this.Region);
    input.append('SearchField', this.SearchField);
    input.append('Mode', this._mode);
    input.append('file', fileToUpload);

    if (this._mode !== 'Add') {
      input.append('DocumentId', this._documentToUpload.documentId);
      input.append('FileNetUrl', this._documentToUpload.documentUrl);
    }

    this._docService.uploadFile(input).subscribe((res) => {
      this._docService
        .getDocumentByGroup(this.GroupId)
        .then((documents) => (this._documents = documents));
    });
  }
}
