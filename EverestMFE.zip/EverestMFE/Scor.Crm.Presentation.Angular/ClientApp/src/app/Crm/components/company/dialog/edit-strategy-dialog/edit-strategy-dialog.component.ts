import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {StrategyDto} from "../../../../dto/strategyDto";
import {CrmService} from "../../../../service/CrmService";

@Component({
  selector: 'edit-strategy-dialog',
  templateUrl: './edit-strategy-dialog.component.html',
  styleUrls: ['./edit-strategy-dialog.component.css']
})
export class EditStrategyDialogComponent implements OnInit {
  @Input() strategy: StrategyDto;
  showDialog: boolean =true;
  divisions: any;
  types: any;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()

  constructor(private _crmService: CrmService) {}

  ngOnInit(): void {
    this._crmService.GetDivisions().then(divisions => {
      this.divisions = [];
      divisions.forEach(div => {
        this.divisions.push({
          label: div.codeName,
          value: div.codeId
        })
      })
    })
  }
  hideDialog() {
    this.showDialog=false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    this.showDialog=false;
    this.onSubmitDialog.emit(this.strategy)
  }
}
