import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';

import { filter } from 'rxjs/operators';
import { OpsteamService } from '../../services/ops-team.service';
import { OpsteamResultsComponent } from '../opsteam-results/opsteam-results.component';

@Component({
  selector: 'app-opsteam-container',
  templateUrl: './opsteam-container.component.html',
  styleUrls: ['./opsteam-container.component.css'],
  providers: [DatePipe],
})
export class OpsteamContainerComponent implements OnInit {
  @ViewChild(OpsteamResultsComponent) table: OpsteamResultsComponent;
  page: any = {
    pageNumber: 1,
    pageSize: 10,
  };
  filters;
  rows;
  selectedRuns: any;
  loadingTable: boolean = false;

  constructor(private opsTeamService: OpsteamService) {}

  ngOnInit(): void {}

  async search(filters: any) {
    if (filters) {
      this.filters = filters;
    } else {
      this.table.updatetable({}, 0);
      return;
    }

    if (filters.teamName) {
      const teamMembers = await this.opsTeamService.getTeamMembers(
        filters.teamName
      );
      this.rows = teamMembers;

      this.table.updatetable(teamMembers, teamMembers.length);
    } else {
      this.table.updatetable({}, 0);
    }
  }

  async searchWithExistingFilters() {
    if (this.filters.teamName) {
      const teamMembers = await this.opsTeamService.getTeamMembers(
        this.filters.teamName
      );
      this.rows = teamMembers;

      this.table.updatetable(teamMembers, teamMembers.length);
    } else {
      this.table.updatetable({}, 0);
    }
  }

  async changePage(page) {
    this.selectedRuns = null;
    this.page = page;

    const first = (page - 1) * page.pageSize;
    const last = page * page.pageSize;

    if (this.rows && this.rows.length > 0) {
      this.table.updatetable(this.rows.slice(first, last), page.pageSize);
    } else {
      this.getInitialData();
    }
  }

  async getInitialData() {
    this.loadingTable = false;
    this.rows = [];
    this.table.updatetable(this.rows, 0);
  }
}
