import { CessionUpdateInfo } from "./CessionUpdateInfo";

export interface CessionUpdateInfoAggregate {
  currentValue: CessionUpdateInfo,
  newValue: CessionUpdateInfo
}
