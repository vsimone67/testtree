import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {SalesObjectiveDto} from "../../../../dto/salesObjectiveDto";
import {CrmService} from "../../../../service/CrmService";

@Component({
  selector: 'objective-dialog',
  templateUrl: './objective-dialog.component.html',
  styleUrls: ['./objective-dialog.component.css']
})
export class ObjectiveDialogComponent implements OnInit {
  @Input() objective: SalesObjectiveDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  types

  constructor(private _crmService: CrmService) {
  }

  ngOnInit(): void {
    this._crmService.GetObjectiveTypes().then(typesOb => {
      this.types = [];
      typesOb.forEach(t => {
        this.types.push({
          label: t.codeName,
          value: t.codeId,
          data: t
        })
      })
    })
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    if (this.objective.salesObjectiveTypeId) {
      this.objective.salesObjectiveType = this.types.filter(ty => ty.value === this.objective.salesObjectiveTypeId)[0].data;


    }
    this.onSubmitDialog.emit(this.objective);
    this.onDialogHide.emit()

  }
}
