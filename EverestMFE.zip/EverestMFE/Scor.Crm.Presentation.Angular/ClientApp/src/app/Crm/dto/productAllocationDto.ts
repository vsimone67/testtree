import { CompanyDto } from './companyDto';
import { GeneraliProductAllocationDto } from './generaliProductAllocationDto';

export interface ProductAllocationDto {
    companyId: string;
    salesPlanGroupId: string;
    allocationPercentageAmount: number | null;
    productAllocationTypeId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    generaliProductAllocation: GeneraliProductAllocationDto;
}