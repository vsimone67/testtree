import { HttpService } from '../../../services/http/http-service.service';

export class serviceBase {
  constructor(protected _httpService: HttpService) {}

  protected async getData<T>(url: string) {
    return await this._httpService.getData<T>(url);
  }

  protected async postData<T>(url: string, model: T) {
    return await this._httpService.postData<T>(url, model);
  }
}
