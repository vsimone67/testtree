export interface StackCapacityViewModel {
    companyName: string;
    treatyNumber: string;
    retentionSharePercentage: number | null;
    isStackPassThru: boolean;
}