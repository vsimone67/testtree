import { Component, OnInit, AfterViewInit, Input } from '@angular/core';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'toast',
  templateUrl: './scor-toast.component.html',
  styleUrls: ['./scor-toast.component.css'],
})
export class ScorToastComponent implements OnInit, AfterViewInit {
  @Input() keepAlive: number = 7000;
  timeout: any;

  constructor(private _messageService: MessageService) {}

  ngOnInit() {}

  ngAfterViewInit() {
    this.initTimeout();
  }

  initTimeout() {
    this.timeout = setTimeout(() => {
      this._messageService.clear();
    }, this.keepAlive);
  }

  clearTimeout() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
  }
}
