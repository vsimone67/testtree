import { QuoteModel } from './QuoteModel';

export interface QuoteCompleteModel {

  quote: QuoteModel;

}
