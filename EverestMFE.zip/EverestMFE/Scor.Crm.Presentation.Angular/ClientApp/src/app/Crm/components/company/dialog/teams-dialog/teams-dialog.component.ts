import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {UserRelationshipDto} from "../../../../dto/userRelationshipDto";
import {CrmService} from "../../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";
import {CompanyDto} from "../../../../dto/companyDto";

@Component({
  selector: 'teams-dialog',
  templateUrl: './teams-dialog.component.html',
  styleUrls: ['./teams-dialog.component.css']
})
export class TeamsDialogComponent implements OnInit {
  @Input() isedit: boolean;
  @Input() team: UserRelationshipDto;
  @Input() parentCompany: CompanyDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  employees;
  roles;

  constructor(private crmService: CrmService) {
  }

  ngOnInit(): void {
    this.crmService.GetAllEmployees().then(employees => {
      this.employees = [];
      employees.forEach(t => {
        this.employees.push({
          label: t.firstName.concat(',').concat(t.lastName),
          value: t.employeeId,
        })
      })
    })
    this.crmService.GetRoles().then(role => {
      this.roles = [];
      role.forEach(r => {
        this.roles.push({
          label: r.codeName,
          value: r.codeId
        })
      })
    })
  }

  hideDialog() {
    this.onDialogHide.emit()
  }

  submitDialog() {
    this.onSubmitDialog.emit(this.team)
  }
}
