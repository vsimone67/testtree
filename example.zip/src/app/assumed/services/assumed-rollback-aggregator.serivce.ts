import { Injectable } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from '../../shared/services/app-settings.service';
import { HttpService } from '../../shared/services/http-service.service';

@Injectable({
  providedIn: 'root'
})
export class AssumedRollbackAggregatorService {

  private _rollbackAggregatorUrl: string;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    this._rollbackAggregatorUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.assumedRollbackAggregatorController}`;
  }

  async rollbackCessionOverride(screenId: string) {
    return await this._httpService.postData(`${this._rollbackAggregatorUrl}/RollbackCessionOverride?screenId=${screenId}`,"");
  }

  async rollbackCessionPoolBindingOverride(screenId: string) {
    return await this._httpService.postData(`${this._rollbackAggregatorUrl}/RollbackCessionPoolBindingOverride?screenId=${screenId}`,"");
  }

  async rollbackCessionHistory(screenId: string) {
    return await this._httpService.postData(`${this._rollbackAggregatorUrl}/RollbackCessionHistory?screenId=${screenId}`,"");
  }
}
