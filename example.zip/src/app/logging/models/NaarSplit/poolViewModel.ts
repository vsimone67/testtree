import { PoolCapacityViewModel } from "./poolCapacityViewModel";

export interface PoolViewModel {
  poolName: string;
  poolStartDate: string;
  poolEndDate: string;
  poolType: string;
  isEligibleForRecapture: boolean;
  poolCapacities: PoolCapacityViewModel[];
}
