import { DepartmentDto } from './departmentDto';
import { EmployeeDto } from './employeeDto';

export interface DepartmentEmployeeDto {
    employeeId: string;
    departmentId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    department: DepartmentDto;
    employee: EmployeeDto;
}