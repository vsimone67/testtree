import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { SiteConstants } from '@constants/siteConstants';
import { VwUwClassModel } from '@shared/models/VwUwClassModel'
import { AppSettingsService } from './app-settings.service';

@Injectable({
  providedIn: "root",
})

export class UnderwritingService {

  private _underwritingUrl: string;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {

    //this._underwritingUrl = `${environment.apiGatewayUrl}/${SiteConstants.underwritingController}`;
    this._underwritingUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.underwritingController}`;
  }

  async getRetroRiskClasses() {
    return await this._httpService.getData<Array<VwUwClassModel>>(
      `${this._underwritingUrl}/GetRetroRiskClasses`);
  }


}
