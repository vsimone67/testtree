export class GridStyleModel {
  public width: string;
  public height: string;

  constructor() {
    this.width = '';
    this.height = '';
  }
}
