import {Component, OnInit, Input, Output, EventEmitter, SimpleChange, OnChanges, ViewChild} from "@angular/core";
import { ColDef } from "ag-grid-community";
import { StackCapacityModel } from "@assumed/models/StackCapacityModel";
import { formatNumber } from '@shared/components/grid/formatters/formatNumber';
import { PricingService } from '@pricing/services/pricing.service';
import { GraphEventModel } from '@assumed/models/GraphEventModel';
import {ConfigurableGridComponent} from "@shared/componentsgrid/configurable-grid/configurable-grid.component";

@Component({
  selector: "stack-grid",
  templateUrl: "./stack-grid.component.html",
  styleUrls: ["./stack-grid.component.css"],
})
export class StackGridComponent implements OnInit {
  @ViewChild(ConfigurableGridComponent, { static: false }) grid;

  @Input() EventData: GraphEventModel;
  @Output() hidetable: EventEmitter<Boolean> = new EventEmitter<Boolean>()

  stackData: Array<StackCapacityModel>;
  columnDefs: Array<ColDef>;
  currentCessionNumber: string;
  defaultStackCols: Array<String>;
  loading: boolean;

  constructor(private _pricingService: PricingService) {
    this.createStackColumns();
  }

  createStackColumns() {
    this.columnDefs = this.createColumns();
    this.defaultStackCols = this.createDefaultColumns();
  }
  async ngOnInit() {
    this.loading = true;
    await this._pricingService.getStackForCession(this.EventData.data.payload.retentionStackName).then(data=>{
      this.stackData =data ;
      this.grid.updateRowData(this.stackData);
    })
    this.currentCessionNumber = this.EventData.data.everestCessionNumber.toString();
    this.loading = false;
  }
  hide(visible) {
    this.hidetable.emit(visible);
  }

  createColumns() {
    return [
      {
        headerName: "Stack Name",
        field: "stackName",
        cellClass: "text-left"
      },
      {
        headerName: "Stack Pass Thru Type",
        field: "stackPassThruType",
        cellClass: "text-left"
      },
      {
        headerName: "Stack Participant",
        field: "stackParticipant",
        cellClass: "text-left"
      },
      {
        headerName: "Single Joint Type",
        field: "singleJointType",
        cellClass: "text-left"
      },
      {
        headerName: "Is Netted For Third Party",
        field: "isNettedForThirdParty",
        cellClass: "text-left"
      },
      {
        headerName: "Retention Share Percentage",
        field: "retentionSharePercentage",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Treaty Number",
        field: "treatyNumber",
        cellClass: "text-left"
      },
      {
        headerName: "Quote Number",
        field: "quoteNumber",
        cellClass: "text-left"
      },
      {
        headerName: "Reinsurance Type",
        field: "reinsuranceType",
        cellClass: "text-left"
      },

    ];
  }

  createDefaultColumns() {
    return ["stackName", "stackPassThruType", "stackParticipant"];
  }
}
