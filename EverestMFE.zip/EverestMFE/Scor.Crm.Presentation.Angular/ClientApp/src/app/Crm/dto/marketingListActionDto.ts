import { MarketingListDto } from './marketingListDto';

export interface MarketingListActionDto {
    marketingListActionId: string;
    marketingListId: string;
    actionDate: string;
    actionType: string;
    actionName: string;
    actionDescription: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string;
    marketingList: MarketingListDto;
}