import { CessionPoolBindingOverrideModel } from "./CessionPoolBindingOverrideModel";

export interface CessionPoolBindingOverrideAggregateModel {
  CurrentValue: CessionPoolBindingOverrideModel;
  NewValue: CessionPoolBindingOverrideModel;
}
