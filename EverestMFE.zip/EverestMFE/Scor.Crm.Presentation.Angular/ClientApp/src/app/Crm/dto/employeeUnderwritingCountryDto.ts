import { EmployeeUnderwritingDto } from './employeeUnderwritingDto';

export interface EmployeeUnderwritingCountryDto {
    employeeId: string;
    countryCodeId: string;
    currencyCodeId: string;
    maximumViewAmount: number | null;
    criticalIllnessMaxViewAmount: number | null;
    disabilityMaxViewAmount: number | null;
    maximumDecisionAmount: number | null;
    criticalIllnessMaxDecisionAmount: number | null;
    disabilityMaxDecisionAmount: number | null;
    allowHighDollarCases: boolean;
    allowJointCases: boolean;
    allowPreviousCases: boolean | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string | null;
    ltcmaxViewAmount: number | null;
    ltcmaxDecisionAmount: number | null;
    minimumViewAmount: number | null;
    criticalIllnessMinViewAmount: number | null;
    disabilityMinViewAmount: number | null;
    ltcminViewAmount: number | null;
    employee: EmployeeUnderwritingDto;
}