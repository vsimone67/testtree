import { Component, OnInit, Input } from '@angular/core';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';
import { ClaimCompleteModel } from 'src/app/claim/models/claimCompleteModel';
import { ColDef } from 'ag-grid-community';
import { formatDate } from '@shared/components/grid/formatters/formatDate';
import { formatNumber } from '@shared/components/grid/formatters/formatNumber';
import { ClaimService } from 'src/app/claim/services/claim.service';
import { ClaimModel } from 'src/app/claim/models/claimModel';


@Component({
  selector: 'claims-dialog',
  templateUrl: './claims-dialog.component.html',
  styleUrls: ['./claims-dialog.component.css']
})
export class ClaimsDialogComponent extends DialogBase implements OnInit {
  @Input() cessionId: string;

  claimInfo: ClaimCompleteModel;
  beneficiaryPersonCols: Array<ColDef>;
  requestReceiptCols: Array<ColDef>;
  beneficiaryEntitiesCols: Array<ColDef>;
  claimBaseAmt: string;
  constructor(private _claimsService: ClaimService) {
    super();
    this.beneficiaryPersonCols = this.createBeneficiaryPersonCols();
    this.requestReceiptCols = this.createRequestReceiptCols();
    this.beneficiaryEntitiesCols = this.createBeneficiaryEntitiesCols();

    // create empty class to supress error messages
    this.claimInfo = <ClaimCompleteModel>{};
    this.claimInfo.claim = <ClaimModel>{};
    this.claimInfo.claimBeneficiaryEntities = [];
    this.claimInfo.claimBeneficiaryPersons = [];
    this.claimInfo.claimRequestsReceipts = [];

  }

  async ngOnInit() {
    this.showDialog = false;
    this.claimInfo = await this._claimsService.getClaimDataForCession(this.cessionId);
    this.claimBaseAmt = this.claimInfo.claim.claimBaseAmount.toLocaleString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
    this.showDialog = true;
  }

  createBeneficiaryPersonCols() {
    return [
      {
        headerName: "First Name",
        field: "firstName"
      },
      {
        headerName: "Last Name",
        field: "lastName"
      },
      {
        headerName: "Date of Birth",
        field: "dateOfBirth",
        valueFormatter: formatDate
      }
    ];
  }

  createBeneficiaryEntitiesCols() {
    return [
      {
        headerName: "Entity",
        field: "entityName"
      },
      {
        headerName: "Fein",
        field: "fein"
      },
    ];
  }
  createRequestReceiptCols() {
    return [
      {
        headerName: "Company Name",
        field: "companyName"
      },
      {
        headerName: "Amt Requested",
        field: "amountRequested",
        valueFormatter: formatNumber
      },
      {
        headerName: "Amt Allocated",
        field: "amountAllocated",
        valueFormatter: formatNumber
      },
      {
        headerName: "Total Outstanding",
        field: "totalOutstanding",
        valueFormatter: formatNumber,
        width: 110
      },
      {
        headerName: "Split %",
        field: "splitPercent",
        valueFormatter: formatNumber,
        width: 100
      },
      {
        headerName: "Split Type",
        field: "splitType",
        width: 100

      },
      {
        headerName: "Split Category Type",
        field: "splitCategoryType",
        width: 100
      },
      {
        headerName: "Treaty No",
        field: "treatyNumber",
        width: 100
      },
      {
        headerName: "Activity Count",
        field: "activityCount",
        width: 100
      },
      {
        headerName: "LegalEntity Name",
        field: "legalEntityName",

      }

    ];
  }

  hideDialog() {
    this.onDialogHide.emit(true);
  }


}
