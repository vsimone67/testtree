export interface PostsViewModel {
    retainedNAAR: number;
    retainedCeded: number;
}