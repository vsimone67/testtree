import { CodeDto } from './codeDto';
import { UnderwritingSeriesDto } from './underwritingSeriesDto';

export interface UnderwritingSeriesDecisionLanguageDto {
    decisionLanguageId: string;
    seriesId: string;
    languageId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    language: CodeDto;
    series: UnderwritingSeriesDto;
}