import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {SalesObjectiveDto} from "../../../../dto/salesObjectiveDto";
import {CrmService} from "../../../../service/CrmService";
import {SalesObstacleDto} from "../../../../dto/salesObstacleDto";

@Component({
  selector: 'obstacle-dialog',
  templateUrl: './obstacle-dialog.component.html',
  styleUrls: ['./obstacle-dialog.component.css']
})
export class ObstacleDialogComponent implements OnInit {

  @Input() obstacle: SalesObstacleDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  types

  constructor(private _crmService: CrmService) {
  }

  ngOnInit(): void {
    this._crmService.GetObstacleTypes().then(typesOb => {
      this.types = [];
      typesOb.forEach(t => {
        this.types.push({
          label: t.codeName,
          value: t.codeId,
          data: t
        })
      })
    })
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    if (this.obstacle.obstacleTypeId) {
      this.obstacle.obstacleType = this.types.filter(ty => ty.value === this.obstacle.obstacleTypeId)[0].data;
    }
    this.onSubmitDialog.emit(this.obstacle);
    this.onDialogHide.emit()

  }

}
