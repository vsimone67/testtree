import { DepartmentEmployeeDto } from './departmentEmployeeDto';
import { DepartmentRelationshipDto } from './departmentRelationshipDto';

export interface DepartmentDto {
    departmentId: string;
    departmentName: string;
    departmentDescription: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    departmentEmployee: DepartmentEmployeeDto[];
    departmentRelationshipChildDepartment: DepartmentRelationshipDto[];
    departmentRelationshipParentChild: DepartmentRelationshipDto[];
}