export const environment = {
  production: false,
  env: 'local'

};
