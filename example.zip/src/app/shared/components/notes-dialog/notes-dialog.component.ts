import { Component, Input, OnInit } from '@angular/core';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';

@Component({
  selector: 'notes-dialog',
  templateUrl: './notes-dialog.component.html',
  styleUrls: ['./notes-dialog.component.css']
})
export class NotesDialogComponent extends DialogBase implements OnInit {
  @Input() cessionId: string;
  @Input() noteType: string;

  constructor() { super();}

  ngOnInit(): void {
  }

}
