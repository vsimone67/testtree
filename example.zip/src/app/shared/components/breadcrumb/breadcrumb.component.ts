import { Component, OnInit } from "@angular/core";
import { MenuItem } from "primeng/api";
import { isNullOrUndefined } from "util";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { filter } from "rxjs/operators";
import { SiteConstants } from "@constants/siteConstants";
import { AuthenticationService } from "@auth/services/authentication.service";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";

@Component({
  selector: "breadcrumb",
  templateUrl: "./breadcrumb.component.html",
  styleUrls: ["./breadcrumb.component.css"],
})
export class BreadcrumbComponent implements OnInit {
  static readonly ROUTE_DATA_BREADCRUMB = "breadcrumb";
  static readonly ROUTE_DATA_BREADCRUMB_PARENT_NAME = "parentName";
  static readonly ROUTE_DATA_BREADCRUMB_PARENT_URL = "parentUrl";
  readonly home = { icon: "pi pi-home", routerLink: "/" };
  menuItems: MenuItem[];
  items: MenuItem[];
  allItems: MenuItem[];
  isHomePage: boolean = false;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        this.menuItems = this.createBreadcrumbs(this.activatedRoute.root);
        this.createMenu(this.activatedRoute.root);
        this.isHomePage =
          this.router.url === "/" || this.router.url === "/home";
      });
  }
  createMenu(root: ActivatedRoute) {
    let id = null;
    root.children[0].params.forEach((li) => {
      if (li["id"]) {
        id = li["id"];
      }
    });

    this.allItems = [];

    // Only add the jump to for the cession analysis and logging if they have a role of Retro User
    if (LifeLineRoleCheck.isUser()) {
      this.allItems.push({
        label: "Cession Analysis",
        icon: "pi pi-chart-bar",
        routerLink: `${SiteConstants.cessionAnalysisRoute}/${id}`,
      });

      this.allItems.push({
        label: "Naar Split Logging",
        icon: "pi pi-list",
        routerLink: `${SiteConstants.logRoute}/${id}`,
      });
    }

    // Only add the jump to for the cession update and logging if they have a role of Retro Admin
    if (LifeLineRoleCheck.isUser()) {
      this.allItems.push({
        label: "Edit Cession Information",
        icon: "pi pi-pencil",
        routerLink: `${SiteConstants.editCessionRoute}/${id}`,
      });
    }

    this.items = this.allItems.filter(
      (element) =>
        this.menuItems.filter((men) => men.label === element.label).length <= 0
    );
  }
  private createBreadcrumbs(
    route: ActivatedRoute,
    url: string = "#",
    breadcrumbs: MenuItem[] = []
  ): MenuItem[] {
    const children: ActivatedRoute[] = route.children;

    if (children.length === 0) {
      return breadcrumbs;
    }

    for (const child of children) {
      const routeURL: string = child.snapshot.url
        .map((segment) => segment.path)
        .join("/");
      if (routeURL !== "") {
        url += `/${routeURL}`;
      }
      const label =
        child.snapshot.data[BreadcrumbComponent.ROUTE_DATA_BREADCRUMB];

      if (!isNullOrUndefined(label)) {
        const parentName =
          child.snapshot.data[
            BreadcrumbComponent.ROUTE_DATA_BREADCRUMB_PARENT_NAME
          ];

        if (!isNullOrUndefined(parentName)) {
          const parentUrl =
            child.snapshot.data[
              BreadcrumbComponent.ROUTE_DATA_BREADCRUMB_PARENT_URL
            ];

          breadcrumbs.push({ label: parentName, url: parentUrl });
        }

        breadcrumbs.push({ label: label, url });
      }

      return this.createBreadcrumbs(child, url, breadcrumbs);
    }
  }
}
