import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThresholdDialogComponent } from './threshold-dialog.component';

describe('ThresholdDialogComponent', () => {
  let component: ThresholdDialogComponent;
  let fixture: ComponentFixture<ThresholdDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ThresholdDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ThresholdDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
