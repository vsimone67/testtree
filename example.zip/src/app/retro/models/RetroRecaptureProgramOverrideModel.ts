export interface RetroRecaptureProgramOverrideModel {
  id: number;
  retroCessionId: string;
  recaptureAsOfDate: Date;
  //  recaptureAsOf: Date | string;
  retentionLimitAtTimeOfRecapture: number;
  createDate: string;
  createdBy: string;
  createById: string;
  modifiedDate: string;
  ModifiedById: string;
  hasRollback: boolean;
}


