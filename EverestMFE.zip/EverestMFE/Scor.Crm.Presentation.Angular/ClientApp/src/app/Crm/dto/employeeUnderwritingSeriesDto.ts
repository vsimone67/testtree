import { EmployeeUnderwritingDto } from './employeeUnderwritingDto';
import { UnderwritingSeriesDto } from './underwritingSeriesDto';

export interface EmployeeUnderwritingSeriesDto {
    employeeId: string;
    seriesId: string;
    allowDecision: boolean | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string;
    employee: EmployeeUnderwritingDto;
    series: UnderwritingSeriesDto;
}