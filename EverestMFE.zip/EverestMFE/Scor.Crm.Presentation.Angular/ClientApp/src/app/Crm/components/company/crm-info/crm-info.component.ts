import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CompanyDto} from "../../../dto/companyDto";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'crm-info',
  templateUrl: './crm-info.component.html',
  styleUrls: ['./crm-info.component.css']
})
export class CrmInfoComponent implements OnInit {
  @Input() company: CompanyDto
  @Output() refreshCompany: EventEmitter<any> = new EventEmitter<any>()
  @Output() closeAll: EventEmitter<any> = new EventEmitter<any>()
  showCompany: boolean;
  selectedCompany: any;
  private mode: string;

  constructor(private crmService: CrmService, private confirm: ConfirmationService,
              private _messageService: MessageService) {
  }

  ngOnInit(): void {
  }

  addCompany() {
    this.selectedCompany = <CompanyDto>{};
    this.mode = 'add'
    this.showCompany = true;
  }

  hideDialog() {
    this.showCompany = false
  }

  saveCompany(company: CompanyDto) {
    if (this.mode == 'edit') {
      this.crmService.EditCompany(company).then(company => {
        this.refreshCompany.emit()
      })
    } else {
      this.crmService.AddCompany(company).then(company => {
        this.refreshCompany.emit()
      })
    }

  }

  editCompany() {
    this.selectedCompany = this.company;
    this.mode = 'edit'
    this.showCompany = true;
  }

  deleteCompany() {
    this.confirm.confirm({
      message: "Do you want to delete this Company ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        this.crmService.DeleteCompany(this.company.companyId).then(liste => {
          this.refreshCompany.emit()
          this._messageService.add({severity: "success", detail: "Company Has been Deleted"});
        })
      },
      reject: () => {
      },
    });
  }

  activateCompany() {
    this.crmService.ActivateCompany(this.company.companyId).then(liste => {
      this.refreshCompany.emit()
      this._messageService.add({severity: "success", detail: "Company Has been Activated"});
    })
  }
}
