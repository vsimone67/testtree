import { CodeDto } from './codeDto';
import { StrategyDto } from './strategyDto';

export interface SalesObstacleDto {
    salesObstacleId: string;
    obstacleNote: string;
    obstacleTypeId: string;
    strategyId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    obstacleType: CodeDto;
    strategy: StrategyDto;
}