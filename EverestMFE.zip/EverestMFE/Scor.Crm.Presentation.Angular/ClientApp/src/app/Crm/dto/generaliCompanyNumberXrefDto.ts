export interface GeneraliCompanyNumberXrefDto {
    companyId: string;
    generaliCompanyNumber: number;
    aain: string;
    fein: string;
    gnaic: string;
    naic: string;
    countrycode: string;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
}