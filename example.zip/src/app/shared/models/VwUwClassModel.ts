export interface VwUwClassModel
{
    UwclassId: string;
    UwclassTypeId: string | null;
    UwclassTobaccoTypeId: string | null;
    PreferredLevelTypeId: string | null;
    UwclassCode: string;
    UwclassName: string;
    UwclassCreateDate: Date | string;
    UwclassCreatedBy: string | null;
    UwclassModifiedDate: Date | string | null;
    UwclassModifiedBy: string | null;
    UwclassModuleReference: string | null;
    UwclassRowStatusId: string | null;
    UwclassTypeIdCodeName: string;
    UwclassTypeIdCodeValue: string;
   UwclassTobaccoTypeIdCodeName: string;
   
    UwclassTobaccoTypeIdCodeValue: string;
   
    UwclassTobaccoTypeIdSequenceNumber: number | null;
   
    PreferredLevelTypeIdCodeName: string;
  }
