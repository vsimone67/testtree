export interface CountryRegionModel {
    countryId: string;
    regionId: string;
    userId: string;
}