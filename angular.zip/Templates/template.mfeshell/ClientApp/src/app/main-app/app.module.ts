import {
  APP_INITIALIZER,
  CUSTOM_ELEMENTS_SCHEMA,
  NgModule,
} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AuthModule } from '@auth/auth.module';
import { AuthenticationService } from '@auth/services/authentication.service';
import { AppSettingsService } from '@scor/common';
import { SharedModule } from 'src/app/common/shared.module';
import { MainMenuComponent } from '../main-menu/main-menu.component';
import { AppComponent } from './app.component';
import { initApp } from './initApp';

@NgModule({
  declarations: [AppComponent, MainMenuComponent],
  imports: [BrowserModule, SharedModule, AuthModule],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      deps: [AppSettingsService, AuthenticationService],
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {}
