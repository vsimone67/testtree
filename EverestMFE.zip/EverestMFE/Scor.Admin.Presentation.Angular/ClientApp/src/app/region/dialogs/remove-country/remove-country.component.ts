import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { CountryRegionModel } from '../../models/country-region-model';
import { RegionService } from '../../services/region.service';

@Component({
  selector: 'app-remove-country',
  templateUrl: './remove-country.component.html',
  styleUrls: ['./remove-country.component.css'],
})
export class RemoveCountryComponent
  extends EditDialogBase<CountryRegionModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() selectedData;
  regionName: string;
  countryName: string;
  currencyName;

  constructor(private regionService: RegionService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.regionName = this.selectedData.regionName;
    this.countryName = this.selectedData.countryName;
  }

  async confirm() {
    await this.regionService.removeCountryFromRegion(
      this.selectedData.regionsCountryRelationshipId
    );
    this.submitDialog();
    this.hideDialog();
  }

  deny() {
    this.hideDialog();
  }
}
