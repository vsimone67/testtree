import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScorToastComponent } from './scor-toast.component';
import { MessagesModule } from 'primeng/messages';
import { MessageService } from 'primeng/api';

@NgModule({
  declarations: [ScorToastComponent],
  imports: [CommonModule, MessagesModule],
  exports: [ScorToastComponent],
  providers: [MessageService],
})
export class ScorToastModule {}
