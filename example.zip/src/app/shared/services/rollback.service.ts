import { Injectable } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { RollbackKeyModel } from '@shared/models/rollbackKey.model';
import { SaveRollbackModel } from '@shared/models/saveRollBack.model';
import { AppSettingsService } from './app-settings.service';
import { HttpService } from './http-service.service';

@Injectable({
  providedIn: 'root'
})
export class RollbackService {

  private _rollbackUrl: string;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    this._rollbackUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.rollbackController}`;
  }

  async hasRollback(screenId:string, screenName: string) {
    return await this._httpService.getData<boolean>(`${this._rollbackUrl}/HasRollback/${screenId}/${screenName}`);
  }

  async getRollback(screenId:string, screenName: string) {
    return await this._httpService.getData<SaveRollbackModel>(`${this._rollbackUrl}/HasRollback`);
  }

}
