export interface StackCapacityModel {
  stackName: string;
  stackPassThruType: string;
  stackParticipant: string;
  singleJointType: string;
  isNettedForThirdParty: boolean;
  retentionSharePercentage: number | null;
  treatyNumber: string;
  quoteNumber: string;
  reinsuranceType: string;
  reinsuranceTypeId: string | null;
  everstCessionNumber: number;
}
