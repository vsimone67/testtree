import {Component, EventEmitter, Input, OnInit, Output, SimpleChange, ViewChild} from "@angular/core";
import { ColDef } from "ag-grid-community";
import {formatCurrency, formatCurrencyCent} from '@shared/components/grid/formatters/formatCurrency';
import { formatNumber } from '@shared/components/grid/formatters/formatNumber';
import { formatDate } from '@shared/components/grid/formatters/formatDate';
import { RetroCessionModel } from '@retro/models/RetroCessionModel';
import { RetroService } from '@retro/services/retro.service';
import { GraphEventModel } from '@assumed/models/GraphEventModel';
import {ConfigurableGridComponent} from "@shared/componentsgrid/configurable-grid/configurable-grid.component";

@Component({
  selector: "retro-grid",
  templateUrl: "./retro-grid.component.html",
  styleUrls: ["./retro-grid.component.css"],
})
export class RetroGridComponent implements OnInit {
  @ViewChild(ConfigurableGridComponent, { static: false }) grid;

  @Input() EventData: GraphEventModel;
  @Output() hidetable: EventEmitter<Boolean> = new EventEmitter<Boolean>();

  RetroData: Array<RetroCessionModel>;
  currentCessionNumber: string;
  columnDefs: Array<ColDef>;
  defaultColsRetro: Array<String>;
  loading: boolean;
  constructor(private _retroService: RetroService) {
    this.createRetroColumns();
    this.currentCessionNumber = "";
  }

  async ngOnInit() {
    this.loading = true;
    await this._retroService.getRetrDataForCession(this.EventData.data.payload.cessionId).then(data=>{
      this.RetroData = data ;
      this.grid.updateRowData(this.RetroData);

    })
    this.currentCessionNumber = this.EventData.data.everestCessionNumber.toString();
    this.loading = false;
  }

  createRetroColumns() {
    this.columnDefs = this.getColumns();
    this.defaultColsRetro = this.getDefaultColumns();
  }

  hide(visible) {
    this.hidetable.emit(visible)
  }

  getColumns() {
    return [
      {
        headerName: "Company Name",
        field: "companyName",
        cellClass: "text-left"
      },
      {
        headerName: "Retro Treaty Number",
        field: "retroTreatyNumber",
        cellClass: "text-left"
      },
      {
        headerName: "Insured Table # At Issue",
        field: "insuredTableNumberAtIssue",
        cellClass: "text-left",
        valueFormatter: formatNumber

      }, {
        headerName: "2nd Insured Table # At Issue",
        field: "secondInsuredTableNumberAtIssue",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Active",
        field: "IsActive",
        cellClass: "text-left"
      }, {
        headerName: "Converted",
        field: "IsConverted",
        cellClass: "text-left"
      }, {
        headerName: "Split Amount",
        field: "splitAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Paid From Date",
        field: "paidFromDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Paid To Date",
        field: "paidToDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Retro Duration",
        field: "retroDuration",
        cellClass: "text-left"

      }, {
        headerName: "Retro Effective Date",
        field: "retroEffectiveDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Retro Cancel Date",
        field: "retroCancelDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      },
      {
        headerName: "Status Code Value",
        field: "statusCodeValue",
        cellClass: "text-left"
      },
      {
        headerName: "Status Category Name",
        field: "statusCategoryName",
        cellClass: "text-left"
      }, {
        headerName: "Status Category Value",
        field: "statusCategoryValue",
        cellClass: "text-left"
      },
      {
        headerName: "Base Allowance Amount",
        field: "baseAllowanceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Base Premium Amount",
        field: "basePremiumAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Excise Tax Amount",
        field: "exciseTaxAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Allowance Amount 1",
        field: "extraAllowanceAmount1",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Allowance Amount 2",
        field: "extraAllowanceAmount2",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Allowance Amount 3",
        field: "extraAllowanceAmount3",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Extra Premium Amount 1",
        field: "extraPremiumAmount1",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Extra Premium Amount 2",
        field: "extraPremiumAmount2",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Extra Premium Amount 3",
        field: "extraPremiumAmount3",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Policy Fee Allowance Amount",
        field: "policyFeeAllowanceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Policy Fee Amount",
        field: "policyFeeAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Policy Tax Amount",
        field: "premiumTaxAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent
      }, {
        headerName: "Months In Billing Period",
        field: "monthsInBillingPeriod",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Retro Expense Amount",
        field: "retroExpenseAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }
    ]
  }

  getDefaultColumns() {
    return ["companyName", "retroTreatyNumber", "splitAmount"];
  }

}
