import { NgModule } from '@angular/core';
import { AppSettingsService } from './app-settings.service';

@NgModule({
  declarations: [],
  imports: [],
  exports: [],
  providers: [AppSettingsService],
})
export class AppSettingsModule {}
