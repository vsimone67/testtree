export interface DropPair {
  label:string;
  value : string | boolean |number
}
