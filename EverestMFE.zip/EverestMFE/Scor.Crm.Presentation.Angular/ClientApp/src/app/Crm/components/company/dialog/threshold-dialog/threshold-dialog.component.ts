import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CompanyThresholdVolumeDto} from "../../../../dto/companyThresholdVolumeDto";
import {CrmService} from "../../../../service/CrmService";

@Component({
  selector: 'threshold-dialog',
  templateUrl: './threshold-dialog.component.html',
  styleUrls: ['./threshold-dialog.component.css']
})
export class ThresholdDialogComponent implements OnInit {
  @Input() threshold:CompanyThresholdVolumeDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  types;
  reasons;
  years;
  constructor(private crmService:CrmService) { }

  ngOnInit(): void {
    this.years=[]
    for(let i=2005 ; i<new Date().getFullYear();i++){
      this.years.push({
        label: i.toString(),
        value: i,
      })
    }
    this.crmService.GetThresholdTypes().then(threstypes => {
      this.types = [];
      threstypes.forEach(t => {
        this.types.push({
          label: t.codeName,
          value: t.codeId,
          data: t
        })
      })
    })
    this.crmService.GetThresholdReasons().then(reasons => {
      this.reasons = [];
      reasons.forEach(t => {
        this.reasons.push({
          label: t.codeName,
          value: t.codeId,
          data: t
        })
      })
    })
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    this.onSubmitDialog.emit(this.threshold);
    this.onDialogHide.emit()
  }
}
