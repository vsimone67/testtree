import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChange,} from "@angular/core";
import {ColDef, GridApi, GridOptions} from "ag-grid-community";
import * as XLSX from 'xlsx'
import * as FileSaver from 'file-saver';

@Component({
  selector: "configurable-grid",
  templateUrl: "./configurable-grid.component.html",
  styleUrls: ["./configurable-grid.component.css"],
})
export class ConfigurableGridComponent implements OnInit, OnChanges {
  @Input() options: GridOptions;
  @Input() defaultcols: Array<String>;
  @Input() ColumnDefs: Array<ColDef>;
  @Input() RowData: Array<any>;
  @Input() GridStyle: any;
  @Input() RowClassRules: any;
  @Input() loading: boolean;
  @Input() tableName: string;
  @Input() buttonText: string;
  @Input() showHideButton: boolean;
  height:number=400;
  @Output() disableVisible: EventEmitter<Boolean> = new EventEmitter<Boolean>();
  appliedRowData: Array<any>
  visible: boolean = false;
  colsShown: any[];
  listeCols: Array<any>;
  appliedCols: Array<ColDef>
  gridApi: GridApi;
  currentGridOptons: GridOptions;
  sortModel: {
    colId: string;
    sort: string;
  }[] = []
  lastSortModel: {
    colId: string;
    sort: string;
  }[] = [];
  sortingOrder = ['desc', 'asc', null];
  heightGrid:number= 400;

  constructor() {
    this.defaultGridOptions();
    this.defaultGridWidthandHeight();
    this.RowClassRules = {};
    this.showHideButton = true;
    this.loading = false;
  }

  updateCols() {
    this.appliedCols = this.ColumnDefs.filter(col => this.colsShown.includes(col.field));
    localStorage.setItem(this.tableName, this.colsShown.toString());
    this.updateRowData()
  }

  callsorting(event) {
    let sort = this.currentGridOptons.api.getSortModel()
    // new Sort
    if (JSON.stringify(this.sortModel) !== JSON.stringify(sort)) {
      if ((!this.sortModel || this.sortModel.length === 0) && sort.length > 0) {
        this.sortModel.push(this.currentGridOptons.api.getSortModel()[0]);
        this.currentGridOptons.api.setSortModel(this.sortModel)

      } else if (this.sortModel && this.sortModel.length > 0 && sort && sort.length > 0) {
        //update sorting
        let currentsort = sort[0]
        let found = this.sortModel.filter(sortmo => sortmo.colId === currentsort.colId).length <= 0;
        if (found) {
          // new columns to be sorted
          this.sortModel.push(currentsort);
        } else {
          // update sorting value
          this.sortModel.forEach(sort => {
            if (sort.colId == currentsort.colId) sort.sort = currentsort.sort
          })
        }
        this.currentGridOptons.api.setSortModel(this.sortModel)

      } else if (this.sortModel && this.sortModel.length > 0 && sort.length === 0) {
        //delete sorting
        let colId = '';
        this.currentGridOptons.columnApi.getAllDisplayedColumns().forEach(col => {
          if (col.getSort() === null && !colId) {
            colId = col.getColId();
          }
        })
        this.sortModel = this.sortModel.filter(sort => sort.colId !== colId);
        this.currentGridOptons.api.setSortModel(this.sortModel)

      }
      this.lastSortModel = sort;
    }
let sorting="";
    this.sortModel.forEach(sort=>sorting = sorting.concat(sort.colId).concat(':').concat(sort.sort).concat(","))
    localStorage.setItem(this.tableName+'Sort', sorting)
  }


  async ngOnInit() {

    let table = localStorage.getItem(this.tableName);
    if (table) {
      this.colsShown = table.split(',')
      this.appliedCols = [];
      this.colsShown.forEach(col => {
        this.appliedCols.push(this.ColumnDefs.filter(column => col === column.field)[0])
      })
    } else {
      this.colsShown = this.defaultcols;
      this.appliedCols = [];
      this.colsShown.forEach(col => {
        this.appliedCols.push(this.ColumnDefs.filter(column => col === column.field)[0])
      })
    }
    if (this.ColumnDefs) {
      this.listeCols = [];
      this.ColumnDefs.forEach(col => {
        this.listeCols.push({label: col.headerName, value: col.field})
      })
      this.listeCols.sort((a,b)=> a.label.toLowerCase().localeCompare(b.label))
    }
    if (this.RowData) {
      this.updateRowData()
    }
  let sort= localStorage.getItem(this.tableName+'Sort');
    if(sort){
      this.sortModel= [];
      sort.split(',').forEach(sortmodel=>{
       let model =  {
         colId:sortmodel.split(':')[0],
         sort:sortmodel.split(':')[1]
       } ;
       this.sortModel.push(model)
      });
     if(this.gridApi) this.currentGridOptons.api.setSortModel(this.sortModel)

    }
  }

  public updateRowData(rowData?) {
    if (rowData) this.RowData = rowData
    if (this.RowData) {
      let tableValues = [];
      let newElement: string;
      this.appliedRowData = [];
      this.RowData.forEach(element => {
        newElement = ""
        this.colsShown.forEach(key => {
          if (element[key]) newElement = newElement.concat(element[key])
        })

        if (tableValues.length === 0 || !tableValues.includes(newElement)) {
          this.appliedRowData.push(element)
        }
        if (!tableValues.includes(newElement)) tableValues.push(newElement)
      })
    }
  }

  onGridReady(params) {
    this.currentGridOptons.api.setSortModel(this.sortModel)

    params.api.sizeColumnsToFit(); // size grid to take up all availibe realestate
    this.gridApi = params.api;
    this.visible = true
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    // if options are passed, override default
    if (changes.options != undefined) {
      this.currentGridOptons = changes.options.currentValue;
    }

    // if style is passed, override default
    if (changes.GridStyle != undefined) {
      this.GridStyle = changes.GridStyle.currentValue;
    }

    if (changes.RowClassRules != undefined) {
      this.RowClassRules = changes.RowClassRules.currentValue;
    }
    if (changes.RowData != undefined) {
      this.RowData = changes.RowData.currentValue;
      if (this.gridApi) this.updateRowData(changes.RowData.currentValue)
    }
  }

  defaultGridOptions() {
    this.currentGridOptons = {
      defaultColDef: {
        sortable: true,
        resizable: true,
        width: 150
      },
      pagination: false,
      paginationAutoPageSize: true,
    };
  }

  defaultGridWidthandHeight() {
    this.GridStyle = {
      width: "100%",
      maxHeight: this.heightGrid + "px",
      height: "100%",
      minHeight: "250px",

    };
  }

  public refresh() {
    this.gridApi.redrawRows();
  }

  updateVisible(data) {
    this.visible = data
    if (!data) {
      this.disableVisible.emit(false)
    }
  }

  changeCols(event) {
    let cols: any[] = event.columnApi.getAllGridColumns();
    this.colsShown = []
    for (let col of cols) {
      var colDef = col.getColDef();
      if (colDef.field && colDef.field !== '')
        this.colsShown.push(colDef.field)
    }
    this.updateRowData()

    localStorage.setItem(this.tableName, this.colsShown.toString());
    if (this.gridApi !== undefined) {
      this.gridApi.sizeColumnsToFit();
    }
  }

  exportToExcel() {
    let shownData = [];
    this.RowData.forEach(row => {
      let obj: any = {};
      this.colsShown.forEach(col => {
        obj[col] = row[col]
      });
      shownData.push(obj)
    });

    const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const EXCEL_EXTENSION = '.xlsx';
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(shownData);

    worksheet["!cols"] = [];
    this.colsShown.forEach(col => {
      worksheet["!cols"].push({width: 35})
    })
    const workbook: XLSX.WorkBook = {Sheets: {'data': worksheet}, SheetNames: ['data']};
    const excelBuffer: any = XLSX.write(workbook, {bookType: 'xlsx', type: 'array'});
    const data: Blob = new Blob([excelBuffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, this.tableName + '_export' + EXCEL_EXTENSION);
  }

  expandgrid() {
    this.heightGrid = this.heightGrid+200
    this.GridStyle.maxHeight = this.heightGrid+"px";
  }

  collapseGrid() {
    if(this.heightGrid<=200)this.heightGrid=200;
    else this.heightGrid = this.heightGrid - 200;
    this.GridStyle.maxHeight = this.heightGrid+"px";

  }
}
