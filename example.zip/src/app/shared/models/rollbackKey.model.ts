export interface RollbackKeyModel {
  ScreenId: string;
  ScreenName: string;
}
