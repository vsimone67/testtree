import { Component, OnInit, Output } from '@angular/core';
import { QuotePlanBandModel } from '@assumed/models/QuotePlanBandModel';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';

@Component({
  selector: 'quote-plan-band-dialog',
  templateUrl: './quote-plan-band-dialog.component.html',
  styleUrls: ['./quote-plan-band-dialog.component.css']
})
export class QuotePlanBandComponent extends DialogBase implements OnInit {
  @Output() quotePlanBandModel: QuotePlanBandModel;
  constructor() { super(); }

  ngOnInit(): void {
  }

}
