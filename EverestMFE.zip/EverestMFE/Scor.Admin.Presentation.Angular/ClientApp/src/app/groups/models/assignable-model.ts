export interface AssignableModel {
    roleId: string;
    roleName: string;
    applicationId: string;
}