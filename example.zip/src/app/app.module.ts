import { BrowserModule } from "@angular/platform-browser";
import { NgModule, APP_INITIALIZER, Injector } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { SharedModule } from "@shared/shared.module";
import { CessionModule } from "./assumed/assumed.module";
import { RetroModule } from "./retro/retro.module";
import { MainNavigationComponent } from "./navigation/components/main-navigation/main-navigation.component";
import { LoggingModule } from "./logging/logging.module";
import { ClearLocalStorageComponent } from "./admin/components/clear-local-storage/clear-local-storage.component";
import { AdminModule } from "./admin/admin.module";
import { SiteConstants } from "@constants/siteConstants";
import { AuthModule } from "@auth/auth.module";
import { AuthenticationService } from "@auth/services/authentication.service";
import { AssumedRoutingModule } from "@assumed/assumed-routing.module";
import { LoggingRoutingModule } from "./logging/logging-routing.module";
import { AppSettingsService } from "@shared/services/app-settings.service";
import { environment } from "@environment/environment";
import { DatePipe } from "@angular/common";
// this method will be called by the angular framework upon startup and will not call the app mouldue unitl it completes
// it will ensure the appsettings and tranlation files are loaded pror to the app being ready
export function initApp(
  appSettings: AppSettingsService,
  authService: AuthenticationService
) {
  return () => {
    return new Promise<void>((resolve) => {
      appSettings
        .LoadConfigData(
          `assets/app-settings/appsettings.${environment.env}.json`
        ) //load app config file
        .then(() => authService.login()) // have the user loging
        .then(() => resolve()) // all is done return control back to angular
        .catch((error) =>
          alert(
            "Error connecting to authorization service...Please make sure it is running, message from server: " +
              error.message
          )
        );
    });
  };
}

@NgModule({
  declarations: [AppComponent, MainNavigationComponent],
  imports: [
    BrowserModule.withServerTransition({ appId: "ng-cli-universal" }),
    CessionModule,
    RetroModule,
    SharedModule,
    LoggingModule,
    LoggingRoutingModule,
    AdminModule,
    AssumedRoutingModule,
    AuthModule,
    RouterModule.forRoot([
      {
        path: `${SiteConstants.clearStorageRoute}`,
        data: { breadcrumb: "Clear Local Storage" },
        component: ClearLocalStorageComponent,
        pathMatch: "full",
      },
    ]),
  ],
  providers: [
    DatePipe,
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      deps: [AppSettingsService, AuthenticationService],
      multi: true,
    },
  ],

  bootstrap: [AppComponent],
})
export class AppModule {
  static injector: Injector; // global injector service so we can get a service reference outside constructor (in JS functions like ag-grid)

  constructor(injector: Injector) {
    AppModule.injector = injector; // store injector to be used later
  }
}
