import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { SplitModel } from "../models/SplitModel";
import { SiteConstants } from '@constants/siteConstants';
import { NaarSplitRootViewModel } from 'src/app/logging/models/NaarSplit/naarSplitRootViewModel';
import { AppSettingsService } from '@shared/services/app-settings.service';
import {DatePipe} from "@angular/common";

@Injectable({
  providedIn: "root",
})
export class SplitsService {

  private _splitsUrl: string;

  constructor(private datePipe:DatePipe,
    private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    //this._splitsUrl = `${environment.apiGatewayUrl}/${SiteConstants.splitsController}`;
    this._splitsUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.splitsController}`;
  }

  async getSplitsForCession(cessionId: string) {
    return await this._httpService.getData<Array<SplitModel>>(
      `${this._splitsUrl}/GetSplitsByCessionId/${cessionId}`
    );
  }

  async generateNaarSplits(cessionId: string, asOfDate: Date) {

    // chagne date format from / to - so we can call the api
    var dateString = `${this.datePipe.transform(asOfDate, 'MM-dd-yyyy')}`

    return await this._httpService.getData<string>(`${this._splitsUrl}/GenerateNaarSplits/${cessionId}/${dateString}`
    );
  }

  async getNaarSplitsForView(cessionId: string, asOfDate: Date) {
    // chagne date format from / to - so we can call the api
    var dateString = `${this.datePipe.transform(asOfDate, 'MM-dd-yyyy')}`

    return await this._httpService.getData<NaarSplitRootViewModel>(`${this._splitsUrl}/GetNaarSplits/${cessionId}/${dateString}`);
  }

  async addNaarSplit(model: SplitModel) {
    return await this._httpService.postData(`${this._splitsUrl}/AddNaarSplit`,model);
  }


}
