import { Component, OnInit, Input } from '@angular/core';
import { eventConstants } from '../../services/event/event.constants';
import { EventService } from '../../services/event/event.service';

@Component({
  selector: 'loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.css'],
})
export class LoadingComponent implements OnInit {
  @Input() show: boolean;

  constructor(private _eventService: EventService) {
    this.show = false;

    _eventService
      .getEvent(eventConstants.loadingEvent)
      .subscribe((spinnerState: any) => {
        this.show = spinnerState;
      });
  }

  ngOnInit(): void {}
}
