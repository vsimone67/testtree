import {NgModule} from "@angular/core";
import {RetroService} from "./services/retro.service";
import {SharedModule} from "@shared/shared.module";
import {SplitsService} from "./services/splits.service";
import {RetroGridComponent} from './components/grids/retro-grid/retro-grid.component';
import {SplitsGridComponent} from './components/grids/splits-grid/splits-grid.component';
import { RetroRollbackAggregatorService } from "./services/retro-rollback-aggregator.service";

@NgModule({
  declarations: [RetroGridComponent, SplitsGridComponent ],
  imports: [SharedModule],
  providers: [RetroService, SplitsService,RetroRollbackAggregatorService],
  exports: [RetroGridComponent, SplitsGridComponent],
})
export class RetroModule {
}
