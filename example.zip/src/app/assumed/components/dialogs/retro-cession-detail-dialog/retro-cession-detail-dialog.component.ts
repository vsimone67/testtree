import {Component, OnChanges, OnInit, SimpleChange, ViewChild} from '@angular/core';
import {User} from '@auth/models/user';
import {RetroCessionOverrideModel} from '@retro/models/RetroCessionOverrideModel';
import {RetroRecaptureProgramOverrideModel} from '@retro/models/RetroRecaptureProgramOverrideModel';
import {vwRetroCessionDetail} from '@retro/models/VwRetroCessionDetail';
import {RetroService} from '@retro/services/retro.service';
import {ImageButtonCellComponent} from '@shared/components/grid';
import {formatBooleanToWord} from '@shared/components/grid/formatters/formatBooleanToWord';
import {formatCurrency} from '@shared/components/grid/formatters/formatCurrency';
import {formatNumber} from '@shared/components/grid/formatters/formatNumber';
import {formatDate} from '@shared/functions/formatDate';
import {formatDate as formatDateGrid} from '@shared/components/grid/formatters/formatDate'
import {formatNumberToCurrency} from '@shared/functions/formatNumberToCurrency';
import {ColDef, GridOptions} from 'ag-grid-community';
import {ConfirmationService, MessageService} from 'primeng';
import {EditDialogBase} from '../EditDialogBase';
import {SiteConstants} from "@constants/siteConstants";
import {RetroAggregatorService} from '@shared/services/retroAggregator.service';
import {RollbackService} from "@shared/service/rollback.service";
import {RetroRollbackAggregatorService} from "@retro/service/retro-rollback-aggregator.service";
import {LifeLineRoles} from "@auth/models/lifeLineRoles";

@Component({
  selector: 'retro-cession-detail-dialog',
  templateUrl: './retro-cession-detail-dialog.component.html',
  styleUrls: ['./retro-cession-detail-dialog.component.css']
})
export class RetroCessionDetailDialogComponent extends EditDialogBase<vwRetroCessionDetail> implements OnInit, OnChanges {

  @ViewChild("retroOverride", {static: false}) retroOverrideGrid;
  @ViewChild("retroRecapture", {static: false}) retroRecaptureGrid;
  splitAmount: string;
  effectiveDate: string
  cancelDate: string;
  retroCessionOverrideList: Array<RetroCessionOverrideModel>;
  retroRecaptureProgramOverrideList: Array<RetroRecaptureProgramOverrideModel>;
  overrideRowToEdit: RetroCessionOverrideModel;
  recaptureRowToEdit: RetroRecaptureProgramOverrideModel;

  retrorOverrideColumnList: Array<ColDef>;
  retroRecaptureProgramColumnList: Array<ColDef>;
  recaptureGridoption:GridOptions
  overrideGridoption:GridOptions
  showOverride: boolean;
  showRecapture: boolean;

  overrideMode: string;
  recaptureMode: string;
isAdmin:boolean=false;
  constructor(private _retroSerivce: RetroService, private _confirmService: ConfirmationService, private _messageService: MessageService,
              private rollback:RollbackService , private _RetroAggregatorService: RetroAggregatorService,
              private _rollbackAgregator:RetroRollbackAggregatorService) {
    super();
  }

  ngOnInit(): void {
    this.retrorOverrideColumnList = this.getRetroCessionOverrideColumns();
    this.retroRecaptureProgramColumnList = this.getRetroRecaptureOverrideColumns();
    this.showOverride = false;
    this.showRecapture = false;
    this.recaptureGridoption = <GridOptions>{};
    this.recaptureGridoption.tooltipShowDelay = 500;
    this.overrideGridoption = <GridOptions>{};
    this.overrideGridoption.tooltipShowDelay = 500;
    var currentUser: User = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
    this.isAdmin = currentUser.roles.filter(role => role.role === LifeLineRoles.Adminstrator).length > 0

  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    // if options are passed, override default
    if (changes.dialogData != undefined) {
      this.splitAmount = formatNumberToCurrency(changes.dialogData.currentValue.narAmount);
      this.effectiveDate = formatDate(changes.dialogData.currentValue.retroEffectiveDate);
      this.cancelDate = formatDate(changes.dialogData.currentValue.retroCancelDate);

     this.refreshRetroOverride();
     this.refreshRetroRecapture()

    }

  }

  onAddRetroCessionOverride() {
    this.overrideRowToEdit = <RetroCessionOverrideModel>{};
    this.overrideRowToEdit.retroCessionId = this.dialogData.retroCessionId;
    this.overrideRowToEdit.overrideRateTableId = "00000000-0000-0000-0000-000000000000"
    this.overrideMode = "Add";
    this.showOverride = true;

  }

  onAddRetroCaptureProgramOverride() {

    this.recaptureRowToEdit = <RetroRecaptureProgramOverrideModel>{};
    this.recaptureRowToEdit.retroCessionId = this.dialogData.retroCessionId;
    this.recaptureMode = "Add";
    this.showRecapture = true;
  }

  onEditRetroCessionOverride(data) {
    this.overrideRowToEdit = data.rowData;
    this.overrideMode = "Edit";
    this.showOverride = true;
  }

  onEditRetroRecaptureOverride(data) {
    this.recaptureRowToEdit = data.rowData;
    this.recaptureRowToEdit.recaptureAsOfDate = new Date(this.recaptureRowToEdit.recaptureAsOfDate);  //! primeng does not like the format returned from Everest, make it a typescript type date to fix issue
    this.recaptureMode = "Edit";
    this.showRecapture = true;
  }

  onDeleteRetroCessionOverride(data) {

    this._confirmService.confirm({
      message: "Are you sure you want to delete this Override?",
      header: "Delete",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key : "retroCession",
      accept: () => {
        this._retroSerivce.DeleteRetroOverride(data.rowData).finally(() => {
          this.refreshRetroOverride();
          this._messageService.add({severity: "success", detail: "Retro Cession Override Has been Deleted"});
        });
      },
    });

  }

  onDeleteRetroRecaptureOverride(data) {
    this._confirmService.confirm({
      message: "Are you sure you want to delete this Recapture?",
      header: "Delete",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key: "Recapture",
      accept: () => {
        this._retroSerivce.DeleteRetroRecaptureProgramOverride(data.rowData).finally(() => {
          this.refreshRetroRecapture()
          this._messageService.add({severity: "success", detail: "Retro Recapture Override Has been Deleted"});
        });
      },
    });
  }

  onOverrideSubmit(data) {
    this.showOverride = false;

    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );

    data.createdBy = currentUser.userId;
    data.modifiedBy = currentUser.userId;

    if (this.overrideMode === "Add") {
      this._RetroAggregatorService.addRetroCessionOverride(data).then((savedOverride:RetroCessionOverrideModel) => this.overrideRowToEdit.id = savedOverride.id).finally(() => {
        this._messageService.add({severity: "success", detail: "Retro Override Has been Added"})
        this.refreshRetroOverride();
      });
    } else {
      this._RetroAggregatorService.editRetroCessionOverride(data).finally(() => {
        this._messageService.add({severity: "success", detail: "Retro Override Has been Updated"})
        this.refreshRetroOverride();
      });
    }

  }

  updateOverrideGrid() {

    if (this.overrideMode === "Add") {
      this.retroOverrideGrid.gridApi.updateRowData({add: [this.overrideRowToEdit]});
      this.retroCessionOverrideList.push(this.overrideRowToEdit);
    } else {
      var row = this.retroCessionOverrideList.findIndex(
        (rating) => rating.id === this.overrideRowToEdit.id
      );

      if (row >= 0) {
        this.retroCessionOverrideList[row] = this.overrideRowToEdit;
        this.retroOverrideGrid.gridApi.setRowData(this.retroCessionOverrideList);
      }
    }
  }


  onRecaptureSubmit(data) {
    this.showRecapture = false;

    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );

    data.createdBy = currentUser.userId;
    data.modifiedById = currentUser.userId;

    if (this.recaptureMode === "Add") {
      this._RetroAggregatorService.addRetroRecaptureOverride(data).then((savedRecapture: RetroRecaptureProgramOverrideModel) => this.recaptureRowToEdit.id = savedRecapture.id).finally(() => {
        this._messageService.add({severity: "success", detail: "Retro Recapture Has been Added"})
        this.refreshRetroRecapture();
      });
    } else {
      this._RetroAggregatorService.editRetroRecaptureOverride(data).finally(() => {
        this._messageService.add({severity: "success", detail: "Retro Recapture Has been Updated"})
        this.refreshRetroRecapture();
      });
    }
  }

  updateRecaptureGrid() {

    if (this.recaptureMode === "Add") {
      this.retroRecaptureGrid.gridApi.updateRowData({add: [this.recaptureRowToEdit]});
      this.retroRecaptureProgramOverrideList.push(this.recaptureRowToEdit);
    } else {
      var row = this.retroRecaptureProgramOverrideList.findIndex(
        (recapture) => recapture.id === this.recaptureRowToEdit.id
      );

      if (row >= 0) {
        this.retroRecaptureProgramOverrideList[row] = this.recaptureRowToEdit;
        this.retroRecaptureGrid.gridApi.setRowData(this.retroRecaptureProgramOverrideList);
      }
    }
  }

  hideOverrideDialog() {
    this.showOverride = false;
  }

  hideRecaptureDialog() {
    this.showRecapture = false;
  }

  getRetroCessionOverrideColumns() {
    let cols:any=  [
      {
        headerName: "Allow Override",
        field: "overrideAllowRecapture",
        valueFormatter: formatBooleanToWord
      },
      {
        headerName: "Binding Limit",
        field: "overrideRetroBindingLimit",
        valueFormatter: formatCurrency
      },
      {
        headerName: "Rate Factor",
        field: "overrideRateFactor",
        valueFormatter: formatNumber
      },
      {
        headerName: "Table Rating",
        field: "retroTableRating"
      },
      {
        headerName: "Table Number",
        field: "retroTableNumber"
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditRetroCessionOverride.bind(this),
          icon: "pi-pencil",
        },
        tooltipValueGetter: (params) => 'Edit Retro Cession Override ',
        width: 25,
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onDeleteRetroCessionOverride.bind(this),
          icon: "pi-times",
        },
        tooltipValueGetter: (params) => 'Delete Retro Cession Override ',
        width: 25,
      }
    ];
    if(this.isAdmin){
      cols.push({
        headerName: "",
        field: "hasRollback",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onRollBackOverride.bind(this),
          icon: "pi-undo",
          rollback: true,
        },
        width: 25,
        tooltipValueGetter: (params) => 'Rollback Cession History'
      })
    }
  return cols;
  }

  getRetroRecaptureOverrideColumns() {
    let cols :any=  [
      {
        headerName: "Recapture As Of Date",
        field: "recaptureAsOfDate",
        valueFormatter: formatDateGrid
      },
      {
        headerName: "Retention Limit At Recapture",
        field: "retentionLimitAtTimeOfRecapture",
        valueFormatter: formatCurrency
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditRetroRecaptureOverride.bind(this),
          icon: "pi-pencil",
        },
        tooltipValueGetter: (params) => 'Edit Retro Recapture Override ',
        width: 25,
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onDeleteRetroRecaptureOverride.bind(this),
          icon: "pi-times",
        },
        tooltipValueGetter: (params) => 'Delete Retro Recapture Override ',
        width: 25,
      }
    ];
    if(this.isAdmin){
      cols.push({
        headerName: "",
        field: "hasRollback",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onRollBackRetroRecaptureOverride.bind(this),
          icon: "pi-undo",
          rollback: true,
        },
        width: 25,
        tooltipValueGetter: (params) => 'Rollback Cession History'
      })
    }
    return cols;
  }
  onRollBackOverride(data){
    this._confirmService.confirm({
      message: "Are you sure you want to rollback this retrocession override?",
      header: "Rollback",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key : "retroCession",
      accept: () => {

        this._rollbackAgregator.retroCessionOverrideRollback(data.rowData.id).then(data=>{
          this._messageService.add({severity: "success", detail: "Rollback done successfully"});
          this.refreshRetroOverride()
        })
      },
    });

  }
  onRollBackRetroRecaptureOverride(data){
    this._confirmService.confirm({
      message: "Are you sure you want to rollback this Retro Capture Override?",
      header: "Rollback",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key : "Recapture",
      accept: () => {
        this._rollbackAgregator.retroCaptureProgramOverrideRollback(data.rowData.id).then(data=>{
          this._messageService.add({severity: "success", detail: "Rollback done successfully"});
          this.refreshRetroRecapture();
        })

      },
    });
  }
refreshRetroRecapture(){
  this._retroSerivce.getRetroRecaptureProgramOverrides(this.dialogData.retroCessionId).then((exp) => {
    this.retroRecaptureProgramOverrideList = exp
    this.retroRecaptureProgramOverrideList.forEach(recapture=> {
      this.rollback.hasRollback(recapture.id.toString(), "RetroRecaptureProgramOverride").then((data:any)=>{
        recapture.hasRollback= data.hasRollback
      })
    })
  });
}
refreshRetroOverride(){
  this._retroSerivce.getRetroOverrides(this.dialogData.retroCessionId).then((exp) => {
    this.retroCessionOverrideList = exp;
    this.retroCessionOverrideList.forEach(retrocession=> {
      this.rollback.hasRollback(retrocession.id.toString(), "RetroCessionOverride").then((data:any)=>{
        retrocession.hasRollback= data.hasRollback
      })
    })
  });
}
}

