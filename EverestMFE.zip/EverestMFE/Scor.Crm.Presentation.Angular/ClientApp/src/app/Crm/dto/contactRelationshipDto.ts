import { ContactDto } from './contactDto';

export interface ContactRelationshipDto {
    contactRelationshipId: string;
    childContactId: string;
    parentContactId: string;
    contactRelationshipNote: string;
    contactRelationshipTypeId: string;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    childContact: ContactDto;
    parentContact: ContactDto;
}