import { CodeDto } from "./codeModel";

export interface CodeCategoryDto {
  codeCategoryId: string;
  codeCategoryDescription: string;
  codeCategoryName: string;
  createDate: string | null;
  createdBy: string | null;
  modifiedDate: string | null;
  modifiedBy: string | null;
  moduleReference: string | null;
  rowStatusId: string | null;
  code: CodeDto[];
}
