import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChange, ViewChild} from "@angular/core";
import {ColDef} from "ag-grid-community";
import {PoolCapacityModel} from "@assumed/models/PoolCapacityModel";
import {formatNumber} from '@shared/components/grid/formatters/formatNumber';
import {formatDate} from '@shared/components/grid/formatters/formatDate';
import {formatCurrency} from '@shared/components/grid/formatters/formatCurrency';
import {PricingService} from '@pricing/services/pricing.service';
import {GraphEventModel} from '@assumed/models/GraphEventModel';
import {ConfigurableGridComponent} from "@shared/componentsgrid/configurable-grid/configurable-grid.component";
import {LinkCellComponent} from "@shared/componentsgrid/link-cell/link-cell.component";
import {TreatyService} from "@shared/service/treaty.service";
import {TreatyCompleteModel} from "@assumed/models/TreatyCompleteModel";
import {RetroQuoteModel} from "@retro/models/retroQuoteModel";
import {RetroQuoteBandRateModel} from "@retro/models/retroQuoteBandRateModel";
import {RetroQuotePlanModel} from "@retro/models/retroQuotePlanModel";

@Component({
  selector: "pool-grid",
  templateUrl: "./pool-grid.component.html",
  styleUrls: ["./pool-grid.component.css"],
})
export class PoolGridComponent implements OnInit, OnChanges {
  @ViewChild(ConfigurableGridComponent, {static: false}) grid;

  poolData: Array<PoolCapacityModel>;
  @Input() EventData: GraphEventModel;
  @Output() hidetable: EventEmitter<Boolean> = new EventEmitter<Boolean>();
  currentCessionNumber: string;
  columnDefs: Array<ColDef>;
  defaultCols: Array<String>;
  loading: boolean;
  treatyId: string;
  showTreaty: boolean = false;
  showRetroQuote: boolean = false;
  showRetroQuotePlan: boolean = false;
  showRetroQuoteBandRate: boolean = false;

  currentTreaty: TreatyCompleteModel;
  currentRetroQuoteList: Array<RetroQuoteModel>;
  currentRetroQuoteBandRate: Array<RetroQuoteBandRateModel>;
  currentRetroQuotePlanList: Array<RetroQuotePlanModel>;

  constructor(private _pricingService: PricingService, private _treatySerivce: TreatyService) {
    this.createPoolColumns();
    this.currentCessionNumber = "";
  }

  createPoolColumns() {
    this.columnDefs = this.createColumns();
    this.defaultCols = this.createDefaultColumns();

  }

  async ngOnInit() {
    this.loading = true;
    await this._pricingService.getPoolForCession(this.EventData.data.payload.retroPoolName).then(data=>{
      this.poolData=data;
      this.grid.updateRowData(this.poolData)
    })
    this.currentCessionNumber = this.EventData.data.everestCessionNumber.toString();
    this.loading = false;
  }

  hide(visible) {
    this.hidetable.emit(visible)
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    // if options are passed, override default
    // if (changes.PoolData != undefined && this.PoolData !== undefined) {
    //   if (this.PoolData.length > 0)
    //     this.currentCessionNumber = this.PoolData[0].everstCessionNumber.toString();
    // }
  }

  createColumns() {
    return [
      {
        headerName: "Pool Name",
        field: "poolName",
        cellClass: "text-left"
      },
      {
        headerName: "Pool Company Name",
        field: "poolCompanyName",
        cellClass: "text-left"
      },
      {
        headerName: "Treaty Number",
        field: "treatyNumber",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowTreatyInfo.bind(this)
        },
        cellClass: "text-left"
      },
      {
        headerName: "Quote Number",
        field: "quoteNumber",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowRetroQuote.bind(this)
        },
        cellClass: "text-left"
      },
      {
        headerName: "Plan Name",
        field: "planName",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowRetroQuotePlan.bind(this)
        },
        cellClass: "text-left"
      },
      {
        headerName: "Band Name",
        field: "bandName",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowRetroQuoteBandRate.bind(this)
        },
        cellClass: "text-left"
      },
      {
        headerName: "Share Percent",
        field: "sharePercent",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Fixed Amount",
        field: "fixedAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      },
      {
        headerName: "Retro Graded Binding Limit",
        field: "retroGradedBindingLimit",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Same Company Exclusion",
        field: "isSameCompanyExclusion",
        cellClass: "text-left"
      },
      {
        headerName: "Minimum Cession Size",
        field: "minimumCessionSize",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Min Age",
        field: "minAge",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Max Age",
        field: "maxAge",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Min Table Number",
        field: "minTableNumber",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Max Table Number",
        field: "maxTableNumber",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Country Rating",
        field: "countryRating",
        cellClass: "text-left"
      },
      {
        headerName: "Reinsurance Type",
        field: "reinsuranceType",
        cellClass: "text-left"
      },
      {
        headerName: "Single Joint Type",
        field: "singleJointType",
        cellClass: "text-left"
      },

      {
        headerName: "Allow Recapture",
        field: "allowRecapture",
        cellClass: "text-left"
      },
      {
        headerName: "Recapture Years",
        field: "recaptureYears",
        cellClass: "text-left",
        valueFormatter: formatNumber
      },
      {
        headerName: "Recapture Program Date",
        field: "recaptureProgramDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      },

    ];
  }

  createDefaultColumns() {
    return ["poolName", "poolCompanyName", "treatyNumber", "quoteNumber"];
  }

  async onShowTreatyInfo(gridRow) {
    var poolrecord = <PoolCapacityModel>gridRow.rowData;
    this.treatyId = poolrecord.treatyId;

    this.currentTreaty = await this._treatySerivce.getTreatyInfo(this.treatyId);
    this.showTreaty = true;
  }

  hideTreatyDialog() {
    this.showTreaty = false;
  }

 async onShowRetroQuote(gridRow) {
    var poolRecord = <PoolCapacityModel>gridRow.rowData;
    this.currentRetroQuoteList = await this._pricingService.getRetroQuote(poolRecord.retroQuoteId);
    this.showRetroQuote = true;

  }

  hideRetroQuoteDialog() {
    this.showRetroQuote = false;
  }

  async onShowRetroQuoteBandRate(gridRow) {
    var poolRecord = <PoolCapacityModel>gridRow.rowData;
    this.currentRetroQuoteBandRate = await this._pricingService.getRetroQuoteBandRates(poolRecord.retroQuoteBandId);
    this.showRetroQuoteBandRate = true;

  }

  hideRetroQuoteBandRate() {
    this.showRetroQuoteBandRate = false;
  }

  async onShowRetroQuotePlan(gridRow) {
    var poolRecords = <PoolCapacityModel>gridRow.rowData;
    this.currentRetroQuotePlanList = await this._pricingService.getRetroQuotePlan(poolRecords.retroQuotePlanId);
    this.showRetroQuotePlan = true;

  }
  hideRetroQuotePlan() {
    this.showRetroQuotePlan = false;
  }


}
