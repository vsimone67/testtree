import { Component, OnInit } from '@angular/core';
import { EventService } from '@scor/common';
import { MenuItem } from 'primeng/api';
import { events } from 'src/assets/constants/events.model';
import { BreadCrumbModel } from './breadcrumb.model';

@Component({
  selector: 'breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css'],
})
export class BreadcrumbComponent implements OnInit {
  readonly home = { icon: 'pi pi-home', url: '/#' };
  menuItems: MenuItem[];
  isHomePage: boolean = false;

  constructor(private eventService: EventService) {}

  ngOnInit(): void {
    this.eventService
      .getEvent(events.breadcrumbEvent)
      .subscribe(
        (breadcrumb) => (this.menuItems = this.createBreadcrumb(breadcrumb))
      );
  }

  private createBreadcrumb(breadcrumb: BreadCrumbModel) {
    var breadcrumbs: MenuItem[] = [];

    if (breadcrumb.parentLabel !== undefined)
      breadcrumbs.push({
        label: breadcrumb.parentLabel,
        url: breadcrumb.parentUrl,
      });

    breadcrumbs.push({ label: breadcrumb.label, url: breadcrumb.url });

    return breadcrumbs;
  }

  public breadCrumbClicked(event) {
    // if home is hit clear all breadcrumbs shown
    if (event.item.url === '/#') {
      this.menuItems = [];
    }
  }
}
