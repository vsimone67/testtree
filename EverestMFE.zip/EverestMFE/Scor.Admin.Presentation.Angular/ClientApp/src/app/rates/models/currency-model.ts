export interface CurrencyModel {
    codeId: string;
    codeName: string;
}