export class PagedListModel<T> {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalCount: number;

  hasPrevious: boolean;
  hasNext: boolean;

  payload: Array<T>;

  constructor() {
    this.totalCount = 0;
    this.payload = new Array<T>();
  }
}
