export interface ExtractCompanyContactsHistoryDto {
    extractCompanyContactHistoryId: string;
    extractCompanyContactId: string;
    companyId: string | null;
    contactEmailAddress: string;
    reportTypeId: string | null;
    isGroupContact: boolean | null;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
}