import { CompanyDto } from './companyDto';
import { EmployeeDto } from './employeeDto';

export interface UserRelationshipDto {
    companyId: string;
    employeeId: string;
    roleTypeId: string;
    isPrimary: boolean;
    userRelationshipNote: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    employee: EmployeeDto;
    extnumber:string;
}
