export interface VerboseItem {
  message: string;
  messageType: string;
}
