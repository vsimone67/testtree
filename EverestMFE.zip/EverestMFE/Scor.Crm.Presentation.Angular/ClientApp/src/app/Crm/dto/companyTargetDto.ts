import { CompanyDto } from './companyDto';

export interface CompanyTargetDto {
    companyTargetId: string;
    companyId: string;
    targetYear: number;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
}