export interface CompanyMinimalModel {
  CompanyId: string;
  CompanyName: string;
}
