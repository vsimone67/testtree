import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyRelationshipDialogComponent } from './company-relationship-dialog.component';

describe('CompanyRelationshipDialogComponent', () => {
  let component: CompanyRelationshipDialogComponent;
  let fixture: ComponentFixture<CompanyRelationshipDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanyRelationshipDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRelationshipDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
