import {
  ApplicationRef,
  APP_INITIALIZER,
  Injector,
  NgModule,
} from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';
import { AuthModule } from '@auth/auth.module';
import { AuthenticationService } from '@auth/services/authentication.service';
import { environment } from '@environment/environment';
import { SharedModule } from '@shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreComponent } from './core/core.component';
import { EmptyComponent } from './empty/empty.component';
import { initApp } from './initApp';
import { HomeComponent } from './home/home.component';
import { AppSettingsService, NotesModule } from '@scor/common';
import { Page2Component } from './page2/page2.component';

@NgModule({
  declarations: [AppComponent, HomeComponent, CoreComponent, EmptyComponent, Page2Component],
  imports: [
    BrowserModule,
    SharedModule,
    AuthModule,
    AppRoutingModule,
    NotesModule,
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      deps: [AppSettingsService, AuthenticationService],
      multi: true,
    },
  ],

  entryComponents: [AppComponent],
})
export class AppModule {
  constructor(private injector: Injector) {}

  ngDoBootstrap(appRef: ApplicationRef) {
    // if you are testing locally bootstrap the AppComponent, if not create custom elements
    if (environment.standalone) {
      appRef.bootstrap(AppComponent);
    } else {
      const appElement = createCustomElement(AppComponent, {
        injector: this.injector,
      });
      customElements.define('app2-app', appElement);
    }
  }
}
