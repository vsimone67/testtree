import { Component, OnInit } from "@angular/core";
import { SiteConstants } from "@constants/siteConstants";
import { AppSettingsService } from "@shared/services/app-settings.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
})
export class AppComponent implements OnInit {
  title: string;
  date: number;
  version: string;
  environment: string;

  constructor(private _appSettingsService: AppSettingsService) {}
  ngOnInit(): void {
    this.title = "app";
    this.date = new Date().getFullYear();
    this.version = SiteConstants.version;
    this.environment = this._appSettingsService.GetValue("environment");
  }
}
