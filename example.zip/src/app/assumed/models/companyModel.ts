﻿/* Auto Generated */

import { BaseModel } from "./baseModel"

export interface CompanyModel extends BaseModel {
    companyId: any;
    aain: string;
    accountId: string;
    aMBestNumber: string;
    aMBestRating?: any;
    companyName: string;
    companyStatus?: any;
    companyTypeId?: any;
    countryOfDomicileId?: any;
    demographicInfoGroupId?: any;
    description: string;
    documentGroupId?: any;
    facUnderwritingTeamId?: any;
    fein: string;
    generaliCompanyNumber: number;
    generaliDivisionId?: any;
    gnaic: string;
    groupCompanyTypeId?: any;
    isOFAC?: boolean;
    isUpdatedByLegalEvent?: boolean;
    mIBParticipant?: boolean;
    naic: string;
    newBusinessPotential?: number;
    noteGroupId?: any;
    organizationTypeId?: any;
    provinceOfDomicileId?: any;
    sPRating?: any;
    stateOfDomicileId?: any;
    thresholdTypeId: any;
    thresholdVolumeProjected?: number;
    vATIdentificationNumber: string;
    website: string;
    hasNoFinancials: boolean;
    isReportingCompany: boolean;
    isLegalEntity: boolean;
    isInternalRetro: boolean;
    affiliateAccountingLedgerId?: any;
    omegaSubsidiaryCode: string;
    omegaSubsidiaryLedgerCode: string;
    isAEGONCompany: boolean;
    stateOfDomicile: any;
    countryOfDomicile: any;
    provinceOfDomicile: any;
    amBestRatingCode: any;
    sPRatingCode: any;
    demographicInfoGroup: any;
    address: any;
    companyRelationshipAsChild: any;
}
