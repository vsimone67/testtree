export interface RetroTxnSearchModel {
  cessionId: string;
  currentPage: number;
  pageSize: number;
  fromDate: string | null;
  toDate: string | null;
  indicator: string;
  splitType: string;
  activeRetro: boolean | null;
  reversed: boolean | null;
}
