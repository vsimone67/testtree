import { Component, OnInit, Input } from '@angular/core';
import { ProposalQuoteBandShareModel } from '@assumed/models/ProposalQuoteBandShareModel';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';

@Component({
  selector: 'proposal-quote-band-share-dialog',
  templateUrl: './proposal-quote-band-share-dialog.component.html',
  styleUrls: ['./proposal-quote-band-share-dialog.component.css']
})
export class ProposalQuoteBandShareDialogComponent extends DialogBase implements OnInit {
  @Input() proposalQuoteBandShareModel: ProposalQuoteBandShareModel;
  constructor() { super(); }

  ngOnInit(): void {
  }

}
