import { CodeDto } from './codeDto';

export interface RegionsCountryRelationshipDto {
    regionsCountryRelationshipId: string;
    regionId: string;
    countryId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string;
    country: CodeDto;
    region: CodeDto;
}