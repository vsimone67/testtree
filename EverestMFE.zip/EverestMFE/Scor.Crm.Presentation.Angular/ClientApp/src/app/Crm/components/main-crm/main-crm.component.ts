import { Component, OnInit } from '@angular/core';
import { CompanyDto } from '../../dto/companyDto';
import { CrmService } from '../../service/CrmService';
import { CompanyRelationshipDto } from '../../dto/companyRelationshipDto';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from '@scor/common';

@Component({
  selector: 'main-crm',
  templateUrl: './main-crm.component.html',
  styleUrls: ['./main-crm.component.css'],
})
export class MainCrmComponent implements OnInit {
  currentCompany: CompanyDto;
  companyId;
  relationships: Array<CompanyRelationshipDto>;
  documentUrl: string;
  codeUrl: string;
  searchField: string;
  region: string;
  codeCategory: string;
  documentGroupId: string;
  user: any;
  private apiNote: string;

  constructor(
    private crmService: CrmService,
    private _appSettingsService: AppSettingsService
  ) {
    this.documentUrl = `${this._appSettingsService.GetValue('apiDocumenturl')}`;
    this.codeUrl = `${this._appSettingsService.GetValue('apiCodeUrl')}`;
  }

  ngOnInit(): void {
    this.codeCategory = '06B4FA78-9C49-479C-891B-767BED622ECF';
    this.region = 'ECRM';
    this.searchField = '12345';
    this.user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
  }

  async open(companyId: any) {
    this.companyId = companyId;
    this.getCompanyDetail();
  }

  async getCompanyDetail() {
    this.currentCompany = await this.crmService.GetCompany(this.companyId);
    let parentid = this.currentCompany.companyRelationshipChildCompany[0]
      ? this.currentCompany.companyRelationshipChildCompany[0].parentCompanyId
      : null;
    if (parentid)
      this.relationships = await this.crmService.GetCompanyRelationships(
        parentid
      );
    else this.relationships = [];
    this.documentGroupId = this.currentCompany.documentGroupId;
    console.log(this.documentGroupId);
    this.currentCompany.userRelationship.forEach((user) => {
      user.employee.fullName = user.employee.lastName
        .concat(' ')
        .concat(user.employee.firstName);
      user.extnumber =
        user.employee.demographicInfoGroup.phoneNumber[0]?.localNumber;
      console.log(user.extnumber);
    });
  }

  closeAll() {}
}
