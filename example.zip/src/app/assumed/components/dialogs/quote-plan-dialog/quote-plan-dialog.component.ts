import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { QuotePlanModel } from '@assumed/models/QuotePlanModel';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';

@Component({
  selector: 'quote-plan-dialog',
  templateUrl: './quote-plan-dialog.component.html',
  styleUrls: ['./quote-plan-dialog.component.css']
})
export class QuotePlanDialogComponent extends DialogBase implements OnInit {
  @Input() quotePlan: QuotePlanModel

  constructor() { super(); }


  ngOnInit(): void {
  }



}
