import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadCrumbModel } from '../common/components/breadcrumb/breadcrumb.model';
import { events } from 'src/assets/constants/events.model';
import { LoaderService } from '../common/services/loader.service';
import { MicroFrontEnd } from '../common/models/microFrontEnd';
import { AppSettingsService, EventService } from '@scor/common';
import { ShellService } from '../shell/shell.service';

@Component({
  selector: 'main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.css'],
})
export class MainMenuComponent implements OnInit {
  public items: MenuItem[];
  constructor(
    private eventService: EventService,
    private loaderService: LoaderService,
    private appSettings: AppSettingsService,
    private shellService: ShellService
  ) {
    this.items = [];
  }

  ngOnInit(): void {
    // get all available mfe's from appsettings
    // var microFontEnds = <Array<MicroFrontEnd>>(
    //   this.appSettings.GetValue('microFrontEnds')
    // );
    // // fill the menu array with all the mfe's
    // microFontEnds.forEach((mfe) =>
    //   this.items.push({
    //     label: mfe.label,
    //     url: mfe.url,
    //     command: (event) => {
    //       this.loadMfe(mfe.name, mfe.url, mfe.label);
    //     },
    //   })
    // );
  }

  navigate(url: string) {
    this.shellService.navigate(url);
  }

  loadMfe(name: string, url: string, label: string) {
    this.loaderService.loadMicroFrontEnd(name); // load the mfe into the shell2

    // send breadcrumb event to update the control
    this.eventService.sendEvent(events.breadcrumbEvent, <BreadCrumbModel>{
      url: url,
      label: label,
    });
  }
}
