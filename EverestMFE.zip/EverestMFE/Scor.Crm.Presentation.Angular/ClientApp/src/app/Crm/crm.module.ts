import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { SearchCompanyComponent } from './components/search-company/search-company.component';
import { MainCrmComponent } from './components/main-crm/main-crm.component';
import { SharedModule } from '@shared/shared.module';
import { RippleModule } from 'primeng/ripple';
import { TreeModule } from 'primeng/tree';
import { CrmInfoComponent } from './components/company/crm-info/crm-info.component';
import { FieldsetModule } from 'primeng/fieldset';
import { MoreInfoComponent } from './components/company/more-info/more-info.component';
import { AkaGridComponent } from './components/company/aka-grid/aka-grid.component';
import { GeneralCompanyComponent } from './components/company/general-company/general-company.component';
import { StrategyCompanyComponent } from './components/company/strategy-company/strategy-company.component';
import { ObjectiveStrategyComponent } from './components/company/objective-strategy/objective-strategy.component';
import { ObstaclesStrategyComponent } from './components/company/obstacles-strategy/obstacles-strategy.component';
import { OpportunityStrategyComponent } from './components/company/opportunity-strategy/opportunity-strategy.component';
import { ActionPlanStrategyComponent } from './components/company/action-plan-strategy/action-plan-strategy.component';
import { EditCompanyComponent } from './components/company/dialog/edit-company/edit-company.component';
import { PhoneComponent } from './components/company/phone/phone.component';
import { AddressComponent } from './components/company/address/address.component';
import { TeamsComponent } from './components/company/teams/teams.component';
import { CompanyRelationshipComponent } from './components/company/company-relationship/company-relationship.component';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { NotesComponents } from './components/company/notes-list/notes-components.component';
import { AkaDialogComponent } from './components/company/dialog/aka-dialog/aka-dialog.component';
import { ObjectiveDialogComponent } from './components/company/dialog/objective-dialog/objective-dialog.component';
import { ObstacleDialogComponent } from './components/company/dialog/obstacle-dialog/obstacle-dialog.component';
import { OpportunityDialogComponent } from './components/company/dialog/opportunity-dialog/opportunity-dialog.component';
import { ActionPlanDialogComponent } from './components/company/dialog/action-plan-dialog/action-plan-dialog.component';
import { ThresholdDialogComponent } from './components/company/dialog/threshold-dialog/threshold-dialog.component';
import { PhoneDialogComponent } from './components/company/dialog/phone-dialog/phone-dialog.component';
import { AddressDialogComponent } from './components/company/dialog/address-dialog/address-dialog.component';
import { StrategyDialogComponent } from './components/company/dialog/strategy-dialog/strategy-dialog.component';
import { EditStrategyDialogComponent } from './components/company/dialog/edit-strategy-dialog/edit-strategy-dialog.component';
import { CompanyRelationshipDialogComponent } from './components/company/dialog/company-relationship-dialog/company-relationship-dialog.component';
import { TargetDialogComponent } from './components/company/dialog/target-dialog/target-dialog.component';
import { TeamsDialogComponent } from './components/company/dialog/teams-dialog/teams-dialog.component';
import { NoteDialogComponent } from './components/company/dialog/note-dialog/note-dialog.component';
import { CrmService } from './service/CrmService';

@NgModule({
  declarations: [
    SearchCompanyComponent,
    MainCrmComponent,
    CrmInfoComponent,
    MoreInfoComponent,
    AkaGridComponent,
    GeneralCompanyComponent,
    StrategyCompanyComponent,
    ObjectiveStrategyComponent,
    ObstaclesStrategyComponent,
    OpportunityStrategyComponent,
    ActionPlanStrategyComponent,
    EditCompanyComponent,
    PhoneComponent,
    AddressComponent,
    TeamsComponent,
    CompanyRelationshipComponent,
    NotesComponents,
    AkaDialogComponent,
    ObjectiveDialogComponent,
    ObstacleDialogComponent,
    OpportunityDialogComponent,
    ActionPlanDialogComponent,
    ThresholdDialogComponent,
    PhoneDialogComponent,
    AddressDialogComponent,
    StrategyDialogComponent,
    EditStrategyDialogComponent,
    CompanyRelationshipDialogComponent,
    TargetDialogComponent,
    TeamsDialogComponent,
    NoteDialogComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    RippleModule,
    TreeModule,
    FieldsetModule,
    InputTextareaModule,
  ],
  providers: [DatePipe, CrmService],
})
export class CrmModule {}
