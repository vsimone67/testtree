import { EmployeeDto } from './employeeDto';
import { NoteGroupMemberDto } from './noteGroupMemberDto';

export interface NoteDto {
    noteId: string;
    noteDate: string | null;
    noteText: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    createdByNavigation: EmployeeDto;
    noteGroupMember: NoteGroupMemberDto[];
}