export interface SplitsModel {
  cessionId: string;

  retroQuoteBandId: string | null;

  retroProposalShareId: string | null;

  retroPoolId: string | null;

  poolName: string;

  effectiveDate: Date | string;

  cancelDate: Date | string;

  retroCompanyId: string;

  retroCompanyName: string;

  treatyId: string | null;

  treatyNumber: string;

  splitTypeId: string;

  splitType: string;

  splitCategoryId: string;

  splitCategory: string;

  splitAmount: number | null;

  cededAmount: number | null;

}
