import { MarketingListActionDto } from './marketingListActionDto';
import { MarketingListContactDto } from './marketingListContactDto';

export interface MarketingListDto {
    marketingListId: string;
    marketingListName: string;
    marketingListDescription: string;
    marketingListType: string;
    marketingListNote: string;
    eventDate: string | null;
    documentGroupId: string | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string;
    marketingListAction: MarketingListActionDto[];
    marketingListContact: MarketingListContactDto[];
}