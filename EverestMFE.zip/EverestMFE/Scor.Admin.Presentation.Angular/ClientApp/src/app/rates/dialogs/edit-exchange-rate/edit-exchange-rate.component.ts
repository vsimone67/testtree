import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { RateModel } from '../../models/rate-model';
import { ExchangeRatesService } from '../../services/exchange-rates.service';

@Component({
  selector: 'app-edit-exchange-rate',
  templateUrl: './edit-exchange-rate.component.html',
  styleUrls: ['./edit-exchange-rate.component.css'],
})
export class EditExchangeRateComponent
  extends EditDialogBase<RateModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() currency;
  @Input() showAll: boolean;
  selectedCompany;
  currencyName;
  exchangeRate;
  effectiveDate;

  constructor(private ratesService: ExchangeRatesService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.currencyName = this.currency.countryCode;
    this.exchangeRate = this.currency.exchangeRate;

    var d = new Date(this.currency.startDate);

    this.effectiveDate = d;
  }

  async saveEditTeamMember() {
    await this.ratesService.editExchangeRate(
      this.currency.exchangeCountryId,
      this.exchangeRate,
      this.currency.startDate,
      this.effectiveDate
    );
    //this.showDialog = false;
    this.submitDialog();
    this.hideDialog();
  }
}
