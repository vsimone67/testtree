import {CompanyDto} from './companyDto';
import {CodeDto} from "./codeDto";

export interface CompanyRelationshipDto {
  companyRelationshipId: string;
  childCompanyId: string;
  companyRelationshipNote: string;
  companyRelationshipTypeId: string;
  parentCompanyId: string;
  recursionLevel: number | null;
  createDate: string;
  createdBy: string | null;
  modifiedDate: string | null;
  modifiedBy: string | null;
  moduleReference: string | null;
  rowStatusId: string | null;
  childCompany: CompanyDto;
  parentCompany: CompanyDto;
  companyRelationshipType: CodeDto;
}
