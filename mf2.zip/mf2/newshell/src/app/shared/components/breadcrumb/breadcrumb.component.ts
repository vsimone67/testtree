import { Component, OnInit } from "@angular/core";
import { MenuItem } from "primeng/api";
import { EventService } from "../../services/event.service";
import { events } from "src/assets/constants/events.model";
import { BreadCrumbModel } from "./breadcrumb.model";

@Component({
  selector: "breadcrumb",
  templateUrl: "./breadcrumb.component.html",
  styleUrls: ["./breadcrumb.component.css"],
})
export class BreadcrumbComponent implements OnInit {
  static readonly ROUTE_DATA_BREADCRUMB = "breadcrumb";
  static readonly ROUTE_DATA_BREADCRUMB_PARENT_NAME = "parentName";
  static readonly ROUTE_DATA_BREADCRUMB_PARENT_URL = "parentUrl";
  readonly home = { icon: "pi pi-home", url: '/#' };
  menuItems: MenuItem[];
  items: MenuItem[];
  allItems: MenuItem[]
  isHomePage: boolean = false;

  constructor(private eventService: EventService) {
  }

  ngOnInit(): void {
    this.eventService.getEvent(events.breadcrumbEvent).subscribe(breadcrumb => this.menuItems = this.createBreadcrumb(breadcrumb));
  }

  private createBreadcrumb(breadcrumb: BreadCrumbModel) {
    var breadcrumbs: MenuItem[] = [];

    if (breadcrumb.parentLabel !== undefined)
        breadcrumbs.push({ label: breadcrumb.parentLabel, url: breadcrumb.parentUrl });

    breadcrumbs.push({ label: breadcrumb.label, url: breadcrumb.url });

    return breadcrumbs;
  }

}
