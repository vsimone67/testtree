import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {CompanyDto} from "../../../../dto/companyDto";
import {CrmService} from "../../../../service/CrmService";
import {CompanyRelationshipDto} from "../../../../dto/companyRelationshipDto";

@Component({
  selector: 'edit-company',
  templateUrl: './edit-company.component.html',
  styleUrls: ['./edit-company.component.css']
})
export class EditCompanyComponent implements OnInit, OnChanges {
  @Input() company: CompanyDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  companies: any;
  selectedParent: any;
  organizations: any;
  divisions;
  countries
  provinces
  states;
  types;
  amrating;
  sprating;
  status

  constructor(private _crmService: CrmService) {
  }

  async ngOnInit() {
    this.populateDropdown();
  }

  populateDropdown() {
    this._crmService.GetAllCompanies().then(companies => {
      console.log(companies)
      this.companies = [];
      companies.forEach((company: CompanyDto) => {
        this.companies.push({
          label: company.companyName,
          value: company.companyId
        })
      })
    });
    this._crmService.GetOrganizationTypes().then(organizations => {
      this.organizations = [];
      organizations.forEach(org => {
        this.organizations.push({
          label: org.codeName,
          value: org.codeId
        })
      })
    })
    this._crmService.GetDivisions().then(divisions => {
      this.divisions = [];
      divisions.forEach(div => {
        this.divisions.push({
          label: div.codeName,
          value: div.codeId
        })
      })
    })
    this._crmService.GetCountries().then(countries => {
      this.countries = [];
      countries.forEach(country => {
        this.countries.push({
          label: country.codeName,
          value: country.codeId
        })
      })
    });
    this._crmService.GetProvinceCodes().then(provinces => {
      this.provinces = [];
      provinces.forEach(pro => {
        this.provinces.push({
          label: pro.codeName,
          value: pro.codeId
        })
      })
    });
    this._crmService.GetStates().then(states => {
      this.states = [];
      states.forEach(state => {
        this.states.push({
          label: state.codeName,
          value: state.codeId
        })
      })
    })
    this._crmService.GetIndividualOrSelfTypes().then(types => {
      this.types = [];
      types.forEach(ty => {
        this.types.push({
          label: ty.codeName,
          value: ty.codeId
        })
      })
    });
    this._crmService.GetAMBestRating().then(rating => {
      this.amrating = [];
      rating.forEach(amr => {
        this.amrating.push({
          label: amr.codeName,
          value: amr.codeId
        })
      })
    })
    this._crmService.GetSPBestRating().then(rating => {
      this.sprating = [];
      rating.forEach(sp => {
        this.sprating.push({
          label: sp.codeName,
          value: sp.codeId
        })
      })
    });
    this._crmService.GetCompanyStatus().then(status => {
      this.status = [];
      status.forEach(st => {
        this.status.push({
          label: st.codeName,
          value: st.codeId
        })
      })
    })
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.company) {
      if (!this.company.companyRelationshipChildCompany ){
        this.company.companyRelationshipChildCompany=[]
      }
        if (changes.company.currentValue.companyRelationshipChildCompany && changes.company.currentValue.companyRelationshipChildCompany.length == 0)
          this.company.companyRelationshipChildCompany.push(<CompanyRelationshipDto>{});

    }
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    if(Object.keys(this.company.companyRelationshipChildCompany[0]).length==0){
      delete this.company.companyRelationshipChildCompany
    }
    this.onSubmitDialog.emit(this.company);
    this.onDialogHide.emit()

  }
}
