export interface GetNotesByParentAndGroupCriteria {
    ParentId: string;
    NoteGroup: string;
}