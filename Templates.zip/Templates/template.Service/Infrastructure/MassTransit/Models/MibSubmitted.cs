using System;

namespace Fac.Service.Infrastructure.MassTransit.Models
{
    public class MibSubmitted
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Dob { get; set; }
    }
}
