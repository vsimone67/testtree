export interface RetroPoolModel
{
    RetroPoolId: string;
    IsForeign: boolean;
    IsJoint: boolean;
    IsSingle: boolean;
    OverCapacityRetroPoolId: string | null;
    PoolDescription: string;
    PoolEndDate: Date | string | null;
    PoolName: string;
    PoolStartDate: Date | string | null;
    PoolTypeId: string | null;
    CreateDate: Date | string;
    CreatedBy: string | null;
    ModifiedDate: Date | string | null;
    ModifiedBy: string | null;
    ModuleReference: string | null;
    RowStatusId: string | null;
    IsFacOnly: boolean | null;
    OmegaPoolTypeId: string | null;
    PayorLegalEntityId: string | null;
    StackPassThruTypeId: string | null;
}
