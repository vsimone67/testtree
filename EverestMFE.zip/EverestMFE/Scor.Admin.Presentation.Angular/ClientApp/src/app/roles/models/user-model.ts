export interface UserModel {
    codeId: string;
    codeName: string;
}