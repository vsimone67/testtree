using MediatR;
using System;
using System.Collections.Generic;
namespace MyNamespace.Application.Queries
{
    public class MyQuery : IRequest<List<string>>
    {

    }
}