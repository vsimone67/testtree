import { DatePipe } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { OperationalTeamModel } from '../../models/operational-team.model';
import { TeamMemberModel } from '../../models/team-member.model';
import { OpsteamService } from '../../services/ops-team.service';

@Component({
  selector: 'app-opsteam-search',
  templateUrl: './opsteam-search.component.html',
  styleUrls: ['./opsteam-search.component.css'],
})
export class OpsteamSearchComponent implements OnInit {
  formRuns;
  teams: any[];
  @Output() searchData: EventEmitter<any> = new EventEmitter<any>();
  paginator;
  teamId;
  loadingField: boolean = false;
  showDialog: boolean = false;
  newTeamMember: TeamMemberModel;
  allowAdd: boolean = false;
  showAll: boolean = false;
  selectedTeamId: string;

  constructor(
    private fb: FormBuilder,
    private pipe: DatePipe,
    private opsTeamService: OpsteamService
  ) {
    this.formRuns = this.fb.group({
      teamName: [null, Validators.required],
    });
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    const newTeams = await this.opsTeamService.getOperationalTeams();

    this.teams = [];
    newTeams.forEach((line: OperationalTeamModel) => {
      if (line)
        this.teams.push({
          label: line.codeName,
          value: line.codeId,
        });
    });
  }

  reset() {
    this.formRuns.reset();
    this.searchData.emit(null);
  }

  search() {
    this.loadingField = true;
    if (this.formRuns.valid) {
      this.searchData.emit(this.formRuns.value);
      this.allowAdd = true;
    }
    this.loadingField = false;
  }

  updateDrops(data) {
    this.allowAdd = !(data.value == null);

    this.selectedTeamId = this.formRuns.value;
  }

  addTeamMember() {
    this.showDialog = true;
    this.newTeamMember = <TeamMemberModel>{};
  }

  closeAddDialog() {
    this.showDialog = false;
  }

  saveSplit(data) {
    this.search();
  }
}
