import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app1-app',
  template: '<router-outlet></router-outlet>',
  encapsulation: ViewEncapsulation.Emulated,
})
export class AppComponent {
  constructor(private router: Router) {}

  ngOnInit(): void {
    this.router.initialNavigation(); // Manually triggering initial navigation for @angular/elements

    // Standalone mode
    if (environment.standalone) {
      this.router.navigate(['/app1/home']);
    }
  }
}
