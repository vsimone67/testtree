export const events = {
  loadingEvent: 'loadingEvent',
  tnxTypeFilter: 'tnxTypeFilter',
  txnDateFilter: 'txnDateFilter',
  historyEffectiveDateFilter: 'historyEffectiveDateFilter',
  SCORSequenceFilter: 'SCORSequenceFilter',
  showHistoryNaarDifferences: 'showHistoryNaarDifferences',
  showSplitsNaarDifferences: 'showSplitsNaarDifferences'
};
