// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
import * as vscode from 'vscode';
import path = require("path");
// this method is called when your extension is activated
// your extension is activated the very first time the command is executed
export function activate(context: vscode.ExtensionContext) {
		
	// The command has been defined in the package.json file
	// Now provide the implementation of the command with registerCommand
	// The commandId parameter must match the command field in package.json
	let disposable = vscode.commands.registerCommand('scorgen.genFiles', () => {
		// The code you place here will be executed every time your command is executed
		// Display a message box to the user
	const editor = vscode.window.activeTextEditor;

    if (!editor) {
        vscode.window.showInformationMessage("editor does not exist");
    return;
    }

    const text = editor.document.getText(editor.selection);
    vscode.window.showInformationMessage(`selected text: ${text}`);

	var sourceFileName = editor.document.fileName;
    var dbServiceName = path.basename(sourceFileName);
	var sourceFilePath = path.dirname(sourceFileName);

	var command = `boobat --sourceFile ${sourceFileName} --dbServiceName ${dbServiceName} --projectPath ${sourceFilePath}`;


	var terminal = vscode.window.createTerminal();
	terminal.sendText(command);
	//terminal.hide();

	});

	context.subscriptions.push(disposable);
}


// this method is called when your extension is deactivated
export function deactivate() {}
