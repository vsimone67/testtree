import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {SalesObjectiveDto} from "../../../dto/salesObjectiveDto";
import {CrmService} from "../../../service/CrmService";
import {SiteConstants} from "@constants/siteConstants";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'objective-strategy',
  templateUrl: './objective-strategy.component.html',
  styleUrls: ['./objective-strategy.component.css']
})
export class ObjectiveStrategyComponent implements OnInit {
  @Input() strategy
  @Input() objectives;
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;
  showDialog: any;
  selectedObjective: SalesObjectiveDto;
  private mode: string;

  constructor(private crmService: CrmService, private confirm:ConfirmationService,
              private _messageService:MessageService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 200px;";
    this.columnDefs = this.createColumns();
  }

  addObjective() {
    this.mode = 'add';
    this.showDialog = true;
    this.selectedObjective = <SalesObjectiveDto>{}
  }

  EditStrategyObjective(data) {
    this.mode = 'edit';
    this.showDialog = true;
    this.selectedObjective = data.rowData
  }

  deleteObjective(data) {
    this.confirm.confirm({
      message: "Do you want to delete this Objective ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        let id=data.rowData.salesObjectiveId
        this.crmService.DeleteObjective(id).then(liste=>{
          this.refreshData.emit()
          this._messageService.add({severity: "success", detail: "Objective Has been Deleted"});
        })
      },
      reject: () => {},
    });
  }

  submitDialog(objective: SalesObjectiveDto) {
    if (this.mode == 'add') {
      objective.strategyId=this.strategy;
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      objective.createdBy=user.userId;
      objective.modifiedBy=user.userId;
      objective.moduleReference=null;
      objective.salesObjectiveId=null;

      this.crmService.AddObjective(objective).then(aka => this.refreshData.emit())
    } else {
      this.crmService.EditObjective(objective).then(aka => this.refreshData.emit())

    }
  }

  hideDialog() {
    this.showDialog = false;

  }

  private createColumns() {
    return <ColDef[]>[
      {
        field: "salesObjectiveType.codeName",
        headerName: "Type",
        width: 250
      },
      {
        field: "salesObjectiveNote",
        headerName: "Note",
        width: 350
      },
      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.EditStrategyObjective.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteObjective.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }
}
