export interface RoleMemberModel
{
    roleId: string;
    userId: string;
    userName: string;
    fullName: string;
}