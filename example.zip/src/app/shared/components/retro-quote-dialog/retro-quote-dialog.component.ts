import { Component, OnInit, Input } from "@angular/core";
import { DialogBase } from "@assumed/components/dialogs/dialog-base";
import { RetroQuoteModel } from "@retro/models/retroQuoteModel";
import { ColDef, GridOptions } from "ag-grid-community";

@Component({
  selector: "retro-quote-dialog",
  templateUrl: "./retro-quote-dialog.component.html",
  styleUrls: ["./retro-quote-dialog.component.css"],
})
export class RetroQuoteComponent extends DialogBase implements OnInit {
  @Input() RetroQuoteList: Array<RetroQuoteModel>;
  columnDefs: Array<ColDef>;
  GridCssStyle: string;
  gridOption: GridOptions;

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 65vh;";
    this.gridOption = <GridOptions>{};
    // this.gridOption.defaultColDef = {
    //   cellClass: "cell-wrap-text",
    //   flex: 1,
    //   resizable: true,
    //   sortable: true,
    //   autoHeight: true,
    // };
  }

  createColumnDefs() {
    return [
      {
        headerName: "Quote Name",
        field: "retroQuoteName",
      },
      {
        headerName: "uw Class",
        field: "uwClassName",
        width: 200,
      },
      {
        headerName: "Insurace Plan",
        field: "insurancePlan",
      },
      {
        headerName: "Plan Name",
        field: "planName",
      },
      {
        headerName: "Marketing Name",
        field: "proposalMarketingName",
      },
      {
        headerName: "Proposal #",
        field: "proposalNumber",
      },
      {
        headerName: "Recapture Years",
        field: "recaptureYears",
      },
      {
        headerName: "Retro Expense",
        field: "retroExpense",
      },
      {
        headerName: "Joint Type",
        field: "jointType",
      },
      {
        headerName: "FY Premium",
        field: "retroQuoteFirstYearPremiumTypeCodeName",
      },
      {
        headerName: "Status",
        field: "retroQuoteRowStatusCodeName",
      },
      {
        headerName: "Min Cession Size",
        field: "minimumCessionSize",
      },
      {
        headerName: "Ceding Type",
        field: "retroQuoteHowCededTypeCodeName",
      },
    ];
  }
}
