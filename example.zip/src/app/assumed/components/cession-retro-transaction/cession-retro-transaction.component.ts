import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { RetroService } from "@retro/service/retro.service";
import {
  retroByCompanies,
  retroByDate,
  RetroTransactionHistoryModel,
} from "@retro/models/RetroTransactionHistoryModel";
import { RetroTransactionHistoryUpdateModel } from "@retro/models/RetroTransactionHistoryUpdateModel";
import { SiteConstants } from "@constants/siteConstants";
import { User } from "@auth/models/user";
import { ConfirmationService, MessageService, TreeTable } from "primeng";
import { DatePipe } from "@angular/common";
import { formatDate } from "@shared/functions/formatDate";
import { RetroAggregatorService } from "@shared/services/retroAggregator.service";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { RollbackService } from "@shared/service/rollback.service";
import { RetroRollbackAggregatorService } from "@retro/service/retro-rollback-aggregator.service";
import { PagedTreetableComponent } from "@shared/componentsgrid/paged-treetable/paged-treetable.component";
import { txnformatNumberToCurrency } from "@shared/functions/formatNumberToCurrency";
import { AppSettingsService } from "@shared/service/app-settings.service";
import { RetroTxnSearchModel } from "@assumed/models/RetroTxnSearchModel";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";

@Component({
  selector: "cession-retro-transaction",
  templateUrl: "./cession-retro-transaction.component.html",
  styleUrls: ["./cession-retro-transaction.component.css"],
  providers: [DatePipe],
})
export class CessionRetroTransactionComponent implements OnInit {
  @ViewChild("mytable") retroTable: PagedTreetableComponent;
  _cessionId: string;
  retrotrxFromService: Array<RetroTransactionHistoryModel>; // retroxtrx from service
  columns: Array<any>;
  retrotrx: Array<retroByDate>; // retrox trx displayed in table
  tableData: any[];

  //filters
  fromDate: Date;
  toDate: Date;
  indicator: string;
  reversed: boolean;
  splitType: string;
  activeretro: boolean;
  currentPage: number;
  pageSize: number;

  //for dialog
  retroEdited: RetroTransactionHistoryUpdateModel;

  showDialog: boolean = false;
  // ref data for filters
  indicatorsList: { label: string; value: string }[];
  reversedList: { label: string; value: any }[];
  activeretros: { label: string; value: boolean }[];
  isAdmin: boolean = false;
  RecordCount: number;
  messages: any[];
  showNotes: boolean = false;
  private _reportUrl: string;
  private searchModel: RetroTxnSearchModel = <RetroTxnSearchModel>{};

  constructor(
    private _route: ActivatedRoute,
    private _messageService: MessageService,
    private date: DatePipe,
    private rollback: RollbackService,
    private _RetroAggregatorService: RetroAggregatorService,
    private retrorollback: RetroRollbackAggregatorService,
    private _retroservice: RetroService,
    private _confirmService: ConfirmationService,
    private _appSettingsService: AppSettingsService
  ) {
    this.currentPage = 1;
    this.pageSize = SiteConstants.defaultPageSize;
    this._reportUrl = `${this._appSettingsService.GetValue(
      SiteConstants.reportUrl
    )}`;
  }

  filter(update?, split?) {
    if (update) {
      this.splitType = split;
    }
    //transactionIndicator
    let indicatorfilter = null;
    if (this.indicator !== null && this.indicator !== undefined) {
      if (this.indicator === "null") indicatorfilter = null;
      else indicatorfilter = this.indicator;
    }
    this.searchModel.indicator = indicatorfilter;
    if (this.fromDate !== null && this.fromDate !== undefined) {
      this.searchModel.fromDate = this.date.transform(
        this.fromDate,
        "yyyy-MM-dd"
      );
    } else {
      this.searchModel.fromDate = null;
    }
    if (this.toDate !== null && this.toDate !== undefined) {
      this.searchModel.toDate = this.date.transform(this.toDate, "MM/dd/yyyy");
    } else {
      this.searchModel.toDate = null;
    }
    this.searchModel.splitType = this.splitType;
    this.searchModel.activeRetro = this.activeretro;
    this.searchModel.reversed = this.reversed;
  }
  applyFilter() {
    this.currentPage = 1;
    this.retroData();
  }
  ngOnInit(): void {
    this.indicatorsList = [
      { value: "+", label: "+" },
      { value: "-", label: "-" },
      { value: " ", label: "SPACE" },
      { value: null, label: "" },
    ];
    this.reversedList = [
      { value: false, label: "Not Reversed" },
      { value: true, label: "Reversed" },
      { value: null, label: "ALL" },
    ];
    this.activeretros = [
      { value: true, label: "Active Retro" },
      { value: false, label: "In-Active Retro" },
      { value: null, label: "Show All" },
    ];
    this._cessionId = this._route.snapshot.paramMap.get("id");
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.isAdmin = LifeLineRoleCheck.isCessionDetailWrite();
    this.columns = this.createColumns();
    this.retroData();
  }

  async retroData() {
    this.searchModel.cessionId = this._cessionId;
    this.searchModel.currentPage = this.currentPage;
    this.searchModel.pageSize = this.pageSize;
    let liste = await this._retroservice.getRetroTransactionHistoryCriteria(
      this.searchModel
    );

    // there are two paged lists returned from the service call, add each
    this.retrotrxFromService = liste[0].payload;
    this.retrotrxFromService = this.retrotrxFromService.concat(
      liste[1].payload
    );
    for (const trx of this.retrotrxFromService) {
      let roll: any = await this.rollback.hasRollback(
        trx.retroTransactionId,
        "RetroTxn"
      );
      trx.hasRollback = roll.hasRollback;
    }
    this.RecordCount = Math.max(liste[0].totalCount, liste[1].totalCount);
    this.messages = ["Report to Date", "Company"];
    this.formatData();
    this.updateRtx();
  }

  async formatData() {
    this.retrotrxFromService = this.retrotrxFromService.map((line) => {
      return <RetroTransactionHistoryModel>{
        ...line,
        hasRollback: line.hasRollback,
        transactionFromDateFormatted: formatDate(line.transactionFromDate),
        reportToDateFormatted: formatDate(line.reportToDate),
        transactionToDateFormatted: formatDate(line.transactionToDate),
        runDateFormatted: formatDate(line.runDate),
        tempFlatExtraAllowanceFormatted: txnformatNumberToCurrency(
          line.tempFlatExtraAllowance
        ),
        splitAmountFormatted: txnformatNumberToCurrency(line.splitAmount),
        retroExpenseFormatted: txnformatNumberToCurrency(line.retroExpense),
        premiumTaxFormatted: txnformatNumberToCurrency(line.premiumTax),
        policyFeeAllowanceFormatted: txnformatNumberToCurrency(
          line.policyFeeAllowance
        ),
        permFlatExtraAllowanceFormatted: txnformatNumberToCurrency(
          line.permFlatExtraAllowance
        ),
        grossTempFlatExtraPremiumFormatted: txnformatNumberToCurrency(
          line.grossTempFlatExtraPremium
        ),
        baseAllowanceFormatted: txnformatNumberToCurrency(line.baseAllowance),
        cashSurrenderValueFormatted: txnformatNumberToCurrency(
          line.cashSurrenderValue
        ),
        exciseTaxFormatted: txnformatNumberToCurrency(line.exciseTax),
        grossBasePremiumFormatted: txnformatNumberToCurrency(
          line.grossBasePremium
        ),
        grossPermFlatExtraPremiumFormatted: txnformatNumberToCurrency(
          line.grossPermFlatExtraPremium
        ),
        grossPolicyFeePremiumFormatted: txnformatNumberToCurrency(
          line.grossPolicyFeePremium
        ),
        unknownFlatExtraAllowanceFormatted: txnformatNumberToCurrency(
          line.unknownFlatExtraAllowance
        ),
        unknownFlatExtraPremiumFormatted: txnformatNumberToCurrency(
          line.unknownFlatExtraPremium
        ),
      };
    });
  }

  updateRtx() {
    this.retrotrx = [];
    this.retrotrxFromService.forEach((trx) => {
      let date = trx.reportToDateFormatted;
      if (
        this.retrotrx.length === 0 ||
        this.retrotrx.filter((retro) => retro.reportToDate === date).length ===
          0
      ) {
        let data = new retroByDate();
        data.reportToDate = date;
        data.children = [];
        let child = new retroByCompanies();
        child.companyName = trx.companyName;
        child.children = [];
        child.children.push(trx);
        data.children.push(child);
        this.retrotrx.push(data);
      } else {
        let found = false;
        this.retrotrx.forEach((retro) => {
          if (retro.reportToDate === date) {
            retro.children.forEach((comp) => {
              if (comp.companyName === trx.companyName) {
                found = true;
                comp.children.push(trx);
              }
            });
            if (!found) {
              let compchild = new retroByCompanies();
              compchild.companyName = trx.companyName;
              compchild.children = [];
              compchild.children.push(trx);
              retro.children.push(compchild);
            }
          }
        });
      }
    });

    this.tableData = [];
    this.retrotrx.forEach((retro) => {
      let data: any = {};
      data.data = {};
      data.data.group = this.date.transform(retro.reportToDate, "MMM d, yyyy");
      data.expanded = true;
      data.children = [];
      retro.children.forEach((trx) => {
        let childn: any = {};
        childn.data = {};
        childn.data.group = trx.companyName;
        childn.expanded = true;
        childn.children = [];
        trx.children.forEach((com) => {
          childn.children.push({ data: com });
        });
        data.children.push(childn);
      });
      this.tableData.push(data);
    });
  }

  createColumns() {
    let cols = [
      {
        headerName: "",
        field: "group",
        width: 70,
      },
      {
        headerName: "Split Type",
        field: "splitType",
        width: 70,
      },
      {
        headerName: "Transaction Type",
        field: "transactionTypeIdCodeName",
        width: 70,
      },
      {
        headerName: "Indicator",
        field: "transactionIndicator",
        width: 70,
      },
      {
        headerName: "Reversed",
        field: "isReversed",
        width: 70,
      },
      {
        headerName: "Sequence",
        field: "transactionSequence",
        width: 70,
      },
      {
        headerName: "From Date ",
        field: "transactionFromDateFormatted",
        width: 70,
      },
      {
        headerName: "To Date ",
        field: "transactionToDateFormatted",
        width: 70,
      },
      {
        headerName: "NAAR",
        field: "splitAmountFormatted",
        width: 70,
      },
      {
        headerName: "Premium",
        field: "grossBasePremiumFormatted",
        width: 70,
      },
      {
        headerName: "Allowance",
        field: "baseAllowanceFormatted",
        width: 70,
      },
      {
        headerName: "Excise Tax",
        field: "exciseTaxFormatted",
        width: 70,
      },
      {
        headerName: "Premium Tax",
        field: "premiumTaxFormatted",
        width: 70,
      },
      {
        headerName: "Temp Extra",
        field: "grossTempFlatExtraPremiumFormatted",
        width: 70,
      },
      {
        headerName: "Temp Allowance",
        field: "tempFlatExtraAllowanceFormatted",
        width: 70,
      },
      {
        headerName: "Perm Extra",
        field: "grossPermFlatExtraPremiumFormatted",
        width: 70,
      },
      {
        headerName: "Perm Allowance",
        field: "permFlatExtraAllowanceFormatted",
        width: 70,
      },
      {
        headerName: "Policy Fee",
        field: "grossPolicyFeePremiumFormatted",
        width: 70,
      },
      {
        headerName: "Fee Allowance",
        field: "policyFeeAllowanceFormatted",
        width: 70,
      },
      {
        headerName: "Surrender",
        field: "cashSurrenderValueFormatted",
        width: 70,
      },
      {
        headerName: "Retro Expense",
        field: "retroExpenseFormatted",
        width: 70,
      },
      {
        headerName: "",
        field: "hasRollback",
        width: 20,
      },
    ];
    if (this.isAdmin) {
      cols.push({
        headerName: "",
        field: "edit",
        width: 20,
      });
    }
    return cols;
  }

  updateRetro(rowNode) {
    this.createUpdateModel(rowNode);
    this.showDialog = true;
  }

  createUpdateModel(rowNode: RetroTransactionHistoryModel) {
    let currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.retroEdited = <RetroTransactionHistoryUpdateModel>{
      BaseAllowance: rowNode.baseAllowance,
      CashSurrenderValue: rowNode.cashSurrenderValue,
      CompanyName: rowNode.companyName,
      ExciseTax: rowNode.exciseTax,
      GrossBasePremium: rowNode.grossBasePremium,
      GrossPermFlatExtraPremium: rowNode.grossPermFlatExtraPremium,
      GrossPolicyFeePremium: rowNode.grossPolicyFeePremium,
      GrossTempFlatExtraPremium: rowNode.grossTempFlatExtraPremium,
      IsActiveRetro: rowNode.isActiveRetro,
      IsReversed: rowNode.isReversed,
      Note: "",
      PermFlatExtraAllowance: rowNode.permFlatExtraAllowance,
      PolicyFeeAllowance: rowNode.policyFeeAllowance,
      PremiumTax: rowNode.premiumTax,
      ReportToDate: new Date(),
      RetroExpense: rowNode.retroExpense,
      RetroTransactionId: rowNode.retroTransactionId,
      SplitAmount: rowNode.splitAmount,
      SplitType: rowNode.splitType,
      TempFlatExtraAllowance: rowNode.tempFlatExtraAllowance,
      TransactionFromDate: new Date(),
      TransactionIndicator: rowNode.transactionIndicator,
      TransactionSequence: rowNode.transactionSequence,
      TransactionToDate: new Date(),
      TransactionTypeId: rowNode.transactionTypeId,
      UserName: currentUser.userName,
      UpdateUserId: currentUser.userId,
      CessionId: this._cessionId,
    };
  }

  hideRetroDialog() {
    this.showDialog = false;
  }

  RetroDialogSubmit(data: RetroTransactionHistoryUpdateModel) {
    this.showDialog = false;
    this._RetroAggregatorService
      .updateRetroTransactionHistory(data)
      .finally(() => {
        this._messageService.add({
          severity: "success",
          detail: "Retro Transaction History  Has been Updated",
        });
        this.retroData();
      });
  }

  resetFilters() {
    this.fromDate = null;
    this.toDate = null;
    this.splitType = null;
    this.indicator = null;
    this.activeretro = null;
    this.reversed = null;
    this.searchModel = <RetroTxnSearchModel>{};
    this.currentPage = 1;

    this.retroData();
  }

  onPageChanged(data) {
    this.pageSize = data.rows;
    this.currentPage = data.page + 1;
    this.retroData();
  }

  rollbackData(data: any) {
    this._confirmService.confirm({
      message: "Are you sure you want to rollback this Retro transaction?",
      header: "Rollback",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      accept: () => {
        this.retrorollback
          .retroTxnRollback(data.retroTransactionId)
          .then((data) => {
            this._messageService.add({
              severity: "success",
              detail: "Rollback done successfully",
            });
            this.retroData();
          });
      },
    });
  }

  updateNotesVisibility() {
    this.showNotes = !this.showNotes;
  }
  hideNotesDialog() {
    this.showNotes = false;
  }

  goToInfos() {
    let url = this._reportUrl
      .concat(
        "RetroTransactionHistoryReport&rs:Command=Render&rc:Parameters=false&CessionId="
      )
      .concat(this._cessionId);
    window.open(url, "_blank");
  }
}
