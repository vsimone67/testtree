export interface PriorsViewModel {
    retainedNAAR: number;
    retainedCeded: number;
    affiliateNAARRecapture: number;
    affiliateCededRecapture: number;
    affiliateNAARNonRecapture: number;
    affiliateCededNonRecapture: number;
}