import { NgModule } from '@angular/core';
import { ClearLocalStorageComponent } from './components/clear-local-storage/clear-local-storage.component';



@NgModule({
  declarations: [ClearLocalStorageComponent],
  imports: [],
  exports: [ClearLocalStorageComponent]
})
export class AdminModule { }
