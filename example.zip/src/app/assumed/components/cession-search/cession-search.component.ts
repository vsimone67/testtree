import {
  Component,
  ElementRef,
  NgZone,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { CessionSearchModel } from "@assumed/models/CessionSearchmodel";
import { AssumedService } from "@assumed/services/assumed.service";
import { CessionSearchResult } from "@assumed/models/CessionSearchResult";
import { ColDef, GridOptions } from "ag-grid-community";
import { formatCurrency } from "@shared/components/grid/formatters/formatCurrency";
import { formatDate } from "@shared/components/grid/formatters/formatDate";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { Router } from "@angular/router";
import { CompanyModel } from "@assumed/models/companyModel";
import { CrmService } from "@shared/services/crm.service";
import { SiteConstants } from "@constants/siteConstants";
import { CompanyMinimalModel } from "@assumed/models/companyMinimalModel";
import { AuthenticationService } from "@auth/services/authentication.service";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";
import { AppSettingsService } from "@shared/service/app-settings.service";

@Component({
  selector: "app-cession-search",
  templateUrl: "./cession-search.component.html",
  encapsulation: ViewEncapsulation.None,
  styleUrls: ["./cession-search.component.css"],
})
export class CessionSearchComponent implements OnInit {
  @ViewChild("f") myForm: ElementRef; // used to get the from control and set the pristine property

  _searchModel: CessionSearchModel;
  cessionSearchResults: Array<CessionSearchResult>;

  GridCssStyle: string;
  columnDefs: Array<ColDef>;
  showGrid: boolean;

  companyList: Array<CompanyMinimalModel>;
  selectedCompany: CompanyModel;

  legalEntityList: Array<CompanyModel>;
  selectedLegalEntity: CompanyModel;
  gridOption: GridOptions;
  _reportUrl: string;
  constructor(
    private _appSettingsService: AppSettingsService,
    private _assumedService: AssumedService,
    private _crmService: CrmService,
    private zone: NgZone,
    private _router: Router,
    private _authenticationService: AuthenticationService
  ) {
    this.clearForm();
    this.gridOption = <GridOptions>{};
    this.gridOption.tooltipShowDelay = 500;
    // this.gridOption.defaultColDef = {
    //   cellClass:'cell-wrap-text',

    // };
    // this.gridOption.rowHeight=120
    this._reportUrl = `${this._appSettingsService.GetValue(
      SiteConstants.reportUrl
    )}`;
  }

  ngOnInit(): void {
    this._searchModel = <CessionSearchModel>{};
    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 550px;";
    this.showGrid = false;
    this.legalEntityList = new Array<CompanyModel>();
    this.companyList = new Array<CompanyMinimalModel>();
    // Add naviation columns for cession analysis and logging if the user is a retro user
    if (LifeLineRoleCheck.isUser()) {
      this.columnDefs.push({
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onNavigateToCessionAnalysis.bind(this),
          icon: "pi-chart-bar",
        },
        width: 5,

        tooltipValueGetter: (params) => "Cession Analysis",
      });

      this.columnDefs.push({
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onNavigateToLogging.bind(this),
          icon: "pi-list",
        },
        width: 5,
        tooltipValueGetter: (params) => "Naar Split Logging",
      });
    }

    // Add naviation column for cession maintentance if the user is an retro admin
    if (LifeLineRoleCheck.isUser()) {
      this.columnDefs.push({
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,

        cellRendererParams: {
          onClick: this.onNavigateToCessionUpdate.bind(this),
          icon: "pi-pencil ",
        },
        width: 5,
        tooltipValueGetter: (params) => "Edit Cession Information",
      });
    }
  }

  async fillDropDowns() {
    this.companyList = await this._crmService.GetRetroCompanies();
    this.legalEntityList = await this._crmService.GetAllLegalEntities();
  }

  async loadCompany() {
    if (this.companyList.length === 0) {
      this.companyList = await this._crmService.GetRetroCompanies();
    }
  }

  async loadLegalEntity() {
    if (this.legalEntityList.length === 0) {
      this.legalEntityList = await this._crmService.GetAllLegalEntities();
    }
  }
  onNavigateToCessionAnalysis(data) {
    this.updateStorageWithCurrentCession(data.rowData);

    this.zone.run(() =>
      this._router.navigate([
        `${SiteConstants.cessionAnalysisRoute}/${data.rowData.cessionId}`,
      ])
    );
  }

  onNavigateToLogging(data) {
    this.updateStorageWithCurrentCession(data.rowData);

    this.zone.run(() =>
      this._router.navigate([
        `${SiteConstants.logRoute}/${data.rowData.cessionId}`,
      ])
    );
  }
  onNavigateToInfos(data) {
    let url = this._reportUrl
      .concat(
        "Cession Details&rs:Command=Render&rc:Parameters=false&CessionId="
      )
      .concat(data.rowData.cessionId);
    window.open(url, "_blank");
  }

  onNavigateToCessionUpdate(data) {
    this.updateStorageWithCurrentCession(data.rowData);

    this.zone.run(() =>
      this._router.navigate([
        `${SiteConstants.editCessionRoute}/${data.rowData.cessionId}`,
      ])
    );
  }

  updateStorageWithCurrentCession(cession) {
    // set the current cession info to local storage so the logging screen can use some of the info
    localStorage.removeItem(SiteConstants.cessionLocalStorage);
    localStorage.setItem(
      SiteConstants.cessionLocalStorage,
      JSON.stringify(cession)
    );
  }

  async onSearch() {
    // add some of the dropdown items if applicable to the search critera
    if (this.selectedCompany !== null)
      this._searchModel.CedingCompanyId = this.selectedCompany.companyId;

    if (this.selectedLegalEntity != null)
      this._searchModel.LeaglEntityId = this.selectedLegalEntity.companyId;

    this.cessionSearchResults = await this._assumedService.searchCession(
      this._searchModel
    );
    this.showGrid = true;
  }

  clearForm() {
    this._searchModel = <CessionSearchModel>{};
    this.selectedLegalEntity = null;
    this.selectedCompany = null;

    if (this.myForm != null) this.myForm["form"].pristine = true;
  }

  createColumnDefs() {
    return [
      {
        headerName: "Company Name",
        field: "companyName",
        sortable: true,
        width: 125,
      },
      {
        headerName: "Legal Entity",
        field: "legalEntityName",
        sortable: true,
        width: 130,
      },
      {
        headerName: "Name",
        field: "insuredFullName",
        sortable: true,
        width: 75,
      },
      {
        headerName: "DOB",
        field: "insuredDateOfBirth",
        valueFormatter: formatDate,
        sortable: true,
        width: 75,
      },
      {
        headerName: "Policy No",
        field: "completePolicyNumber",
        sortable: true,
        width: 105,
        tooltipValueGetter: (params) => params.value,
      },
      {
        headerName: "Base NAAR",
        field: "baseNaramount",
        valueFormatter: formatCurrency,
        sortable: true,
        width: 120,
      },
      {
        headerName: "Policy Date",
        field: "policyDate",
        valueFormatter: formatDate,
        sortable: true,
        width: 125,
      },
      {
        headerName: "Category",
        field: "cessionCategory",
        sortable: true,
        width: 95,
      },
      {
        headerName: "Status",
        field: "cessionStatus",
        sortable: true,
        width: 75,
      },
      {
        headerName: "Treaty",
        field: "treatyNumber",
        sortable: true,
        width: 90,
      },
      {
        headerName: "Quote",
        field: "quoteNumber",
        sortable: true,
        width: 75,
      },
      {
        headerName: "Plan",
        field: "planDescription",
        tooltipField: "planDescription",
        sortable: true,
        tooltipValueGetter: (params) => params.value,
        width: 125,
      },
      {
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onNavigateToInfos.bind(this),
          icon: "pi-info-circle",
        },
        width: 5,
        tooltipValueGetter: (params) => "View More Information",
      },
    ];
  }
}
