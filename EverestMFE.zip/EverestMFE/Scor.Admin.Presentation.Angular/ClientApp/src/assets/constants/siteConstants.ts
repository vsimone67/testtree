export enum SiteConstants {
  UserToken = 'UserToken',
  authorizationApiUrl = 'authorizationApiUrl',
  authorizationApiController = 'Authorize',
  codeController = 'code',
  apiGatewayController = 'apiGateway',
}
