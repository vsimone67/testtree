export const defaultsCols = [
    {
      headerName: 'Operational Team',
      field: 'operationalTeamName', width: 150, resizable: true, sortable: true,
    }, {
      headerName: 'Company',
      field: 'companyName',
      minWidth: 150,
      resizable: true,
      sortable: true
    }, {
      headerName: 'Status', field: 'companyStatus', width: 50,
      resizable: true, sortable: true,  
    },
    {
      headerName: 'Actions', field: 'companyOperationalTeamRelId',
      width: 200, resizable: true, sortable: true,
    }, 
  ]
  
  export const defaultcols = ['operationalTeamName', 'companyName', 'companyStatus', 'companyOperationalTeamRelId'];
  export const pinned = []
  