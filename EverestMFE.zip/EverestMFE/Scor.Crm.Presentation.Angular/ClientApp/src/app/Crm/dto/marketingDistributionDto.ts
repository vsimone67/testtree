import { CompanyDto } from './companyDto';

export interface MarketingDistributionDto {
    marketingDistributionId: string;
    companyId: string;
    marketingDistributionNotes: string;
    marketingDistributionPercentAmount: number;
    marketingDistributionTypeId: string | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
}