import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionPlanStrategyComponent } from './action-plan-strategy.component';

describe('ActionPlanStrategyComponent', () => {
  let component: ActionPlanStrategyComponent;
  let fixture: ComponentFixture<ActionPlanStrategyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActionPlanStrategyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionPlanStrategyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
