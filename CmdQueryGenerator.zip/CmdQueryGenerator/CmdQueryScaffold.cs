using System.Reflection;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace CmdQueryGenerator
{
    public class CmdQueryScaffold
    {
        public string SourceFileName { get; set; }
        public string MethodToGenerate { get; set; }
        public string DBService { get; set; }
        public string ProjectPath { get; set; }
        public string ControllerName { get; set; }
        public string CodeNamespace { get; set; }
        public CompilationUnitSyntax _root;
        public CmdQueryScaffold(string sourceFileName, string methodToGenerate)
        {
            SourceFileName = sourceFileName;
            MethodToGenerate = methodToGenerate;
        }

        public void GenerateFiles()
        {
            LoadSourceFile();
            DefaultNames();
            ScaffoldFiles();
            // var query = File.OpenText("templates/myquery.txt").ReadToEnd();
            // var queryHandler = File.OpenText("templates/myqueryhandler.txt").ReadToEnd();

            // var command = File.OpenText("templates/mycommandcommand.txt").ReadToEnd();
            // var commandHandler = File.OpenText("templates/mycommandcommandHandler.txt").ReadToEnd();

            // var httpGet = File.OpenText("templates/httpget.txt").ReadToEnd();
            // var httpPost = File.OpenText("templates/httppost.txt").ReadToEnd();

        }

        private void LoadSourceFile()
        {
            using (StreamReader sr = File.OpenText(SourceFileName))
            {
                var sourceCode = sr.ReadToEnd();

                var tree = CSharpSyntaxTree.ParseText(sourceCode);
                _root = (CompilationUnitSyntax)tree.GetRoot();
            }
        }

        private void DefaultNames()
        {
            var nameSpace = _root.DescendantNodes().OfType<NamespaceDeclarationSyntax>().First().Name.ToFullString();
            var nameSpaceParse = nameSpace.Split(".");
            CodeNamespace = $"{nameSpaceParse[0]}.{nameSpaceParse[1]}.{nameSpaceParse[2]}";
            DBService = Path.GetFileName(SourceFileName).Replace(".cs", "");
            ProjectPath = Path.GetFullPath(SourceFileName);
            // remove two layers of the path
            int pos = ProjectPath.IndexOf("Persistance");
            ProjectPath = ProjectPath.Substring(0, pos - 1);
            ControllerName = nameSpaceParse[1] + "Controller";
        }

        private void ScaffoldFiles()
        {
            // get all properties in class
            var methods = _root.DescendantNodes().OfType<MethodDeclarationSyntax>().ToList();

            foreach (var method in methods)
            {
                List<MethodSignature> methodSignature = new List<MethodSignature>();
                var methodName = method.Identifier.ToString();
                var returnType = method.ReturnType.ToString().Replace("Task<", "").Replace(">>", ">");

                returnType = returnType.Contains("List") ? returnType : returnType.Replace(">", "");
                var parameterList = method.ParameterList.Parameters.ToList();
                var dtoType = "";

                if (string.IsNullOrEmpty(returnType))
                {
                    returnType = "Unit";
                    dtoType = "";
                }
                else
                {
                    var className = returnType.Replace("List<", "").Replace(">", "");
                    dtoType = className + "Dto";
                    returnType = returnType.Replace(className, dtoType);
                }

                foreach (var parameter in parameterList)
                {
                    var lines = parameter.ToFullString().TrimStart().Split(" ");

                    if (lines.Count() > 1)
                    {
                        var parameterLine = lines[1].First().ToString().ToUpper() + lines[1].Substring(1);

                        var parameterInfo = new MethodSignature()
                        {
                            ReturnValue = returnType,
                            ParameterUpper = parameterLine,
                            ParameterLower = lines[1],
                            MethodName = methodName,
                            Dto = dtoType,
                            ParameterType = lines[0]
                        };
                        methodSignature.Add(parameterInfo);
                    }

                    if (methodName.Substring(0, 3) == "Get")
                    {
                    }
                    if (methodName.Substring(0, 3) == "Add" || methodName.Substring(0, 4) == "Edit" || methodName.Substring(0, 6) == "Delete")
                    {

                    }
                }


            }
        }
    }

    public class MethodSignature
    {
        public string MethodName { get; set; }
        public string ReturnValue { get; set; }
        public string ParameterUpper { get; set; }
        public string ParameterLower { get; set; }
        public string ParameterType { get; set; }
        public string Dto { get; set; }

    }

}
