using System.Collections.Generic;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace CmdQueryGenerator
{
    public class MethodSignature
    {
        public string MethodName { get; set; }
        public string ReturnValue { get; set; }
        public string Dto { get; set; }
        public List<ParameterSyntax> ParameterList { get; set; }
        public List<ParameterInfo> ParameterInfoList { get; set; }
        public string Parms { get; set; }

        public MethodSignature()
        {
            ParameterInfoList = new List<ParameterInfo>();
        }

    }

}
