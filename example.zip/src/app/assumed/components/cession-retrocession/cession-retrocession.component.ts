import { Component, OnInit } from "@angular/core";
import { ColDef, GridOptions } from "ag-grid-community";
import { formatDate } from "@shared/components/grid/formatters/formatDate";
import { formatCurrency } from "@shared/components/grid/formatters/formatCurrency";
import { ActivatedRoute } from "@angular/router";
import { RetroService } from "@retro/services/retro.service";
import { vwRetroCessionDetail } from "@retro/models/VwRetroCessionDetail";
import { ImageButtonCellComponent } from "@shared/components/grid";
import { CessionSearchResult } from "@assumed/models/CessionSearchResult";
import { SiteConstants } from "@constants/siteConstants";
import { User } from "@auth/models/user";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { RollbackService } from "@shared/service/rollback.service";
import { formatNumber } from "@shared/components/grid/formatters/formatNumber";
import { formatBooleanToWord } from "@shared/components/grid/formatters/formatBooleanToWord";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";

@Component({
  selector: "cession-retrocession",
  templateUrl: "./cession-retrocession.component.html",
  styleUrls: ["./cession-retrocession.component.css"],
})
export class CessionRetrocessionComponent implements OnInit {
  RetroCessionData: Array<vwRetroCessionDetail>;
  columnDefs: Array<ColDef>;
  rowToEdit: vwRetroCessionDetail;
  _cessionId: string;
  showDialog: boolean;
  cessionInfo: string;
  isAdmin: boolean;
  gridOption: GridOptions;
  GridCssStyle: string;

  constructor(
    private _route: ActivatedRoute,
    private _retroService: RetroService,
    private _rollbackService: RollbackService
  ) {
    this.showDialog = false;
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.isAdmin = LifeLineRoleCheck.isRetroEventsWrite();

    this.gridOption = <GridOptions>{};
    this.gridOption.tooltipShowDelay = 500;
    this.GridCssStyle = "width: 100%; height: 500px;";
    this.createColumns();
  }

  async ngOnInit() {
    this._cessionId = this._route.snapshot.paramMap.get("id");
    var storedCession = JSON.parse(
      localStorage.getItem(SiteConstants.cessionLocalStorage)
    ) as CessionSearchResult;

    this._retroService.getRetroDeatails(this._cessionId).then((data) => {
      this.RetroCessionData = data;

      // sort by retro EffectiveDate desc
      this.RetroCessionData.sort(function (a, b): any {
        return (
          new Date(b.retroEffectiveDate).getTime() -
          new Date(a.retroEffectiveDate).getTime()
        );
      });
    });
    this.cessionInfo = `${storedCession.insuredFullName} ${storedCession.completePolicyNumber}`;
  }
  createColumns() {
    this.columnDefs = this.getColumns();
  }

  onEditRetroCession(retroCession) {
    this.rowToEdit = retroCession.rowData;
    this.showDialog = true;
  }
  onRollbackRetroCession(retroCession) {
    this.refreshGrid();
  }

  hideRetroDialog() {
    this.showDialog = false;
  }

  getColumns() {
    let cols: ColDef[] = [
      {
        headerName: "Company Name",
        field: "companyName",
        cellClass: "text-left",
      },
      {
        headerName: "Treaty Number",
        field: "treatyNumber",
        cellClass: "text-left",
      },
      {
        headerName: "Category Name",
        field: "categoryName",
        cellClass: "text-left",
      },
      {
        headerName: "Retro Effective ",
        field: "retroEffectiveDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "Retro Cancel",
        field: "retroCancelDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "NAAR Amount",
        field: "narAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Active",
        field: "isActive",
        valueFormatter: formatBooleanToWord,
        width: 70,
      },
      {
        headerName: "",
        field: "hasRollback",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onRollbackRetroCession.bind(this),
          icon: "pi-undo",
          rollback: true,
        },
        width: 25,
        tooltipValueGetter: (params) => "Rollback Retrocession",
      },
    ];
    if (this.isAdmin) {
      cols.push({
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onEditRetroCession.bind(this),
          icon: "pi-pencil",
        },
        width: 25,
        tooltipValueGetter: (params) => "Edit Retrocession",
      });
    }

    return cols;
  }
  refreshGrid() {
    this._retroService.getRetroDeatails(this._cessionId).then((data) => {
      this.RetroCessionData = data;
      this.RetroCessionData.forEach((row) => {
        this._rollbackService
          .hasRollback(row.retroCessionId, "RetroCessionOverride")
          .then((rollback: any) => {
            row.hasRollback = rollback.hasRollback;
          });
      });
    });
  }
}
