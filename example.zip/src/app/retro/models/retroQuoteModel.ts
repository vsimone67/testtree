export interface RetroQuoteModel {
  retroQuoteId: string;

  autoRateCapacityAmount: number | null;

  isBroker: boolean | null;

  brokerageFee: number | null;

  dueDate: Date | string | null;

  firstYearPremiumTypeId: string | null;

  isNonStandardTableRating: boolean | null;

  isSameCompanyExclusion: boolean | null;

  isSpecialRetention: boolean | null;
  isTableShavingUsed: boolean | null;

  maxMortalityRating: number | null;

  minimumCessionSize: number | null;

  retroQuoteDescription: string;

  retroQuoteName: string;

  retroQuoteNumber: string;

  retroQuoteSequence: number;

  retroQuoteVersion: number;

  retroQuoteYear: number;

  retroQuoteCreateDate: Date | string | null;
  retroQuoteCreatedBy: string | null;

  retroQuoteModifiedDate: Date | string | null;
  retroQuoteModifiedBy: string | null;

  retroQuoteBrokerageFeeTypeCodeName: string;

  retroQuoteFirstYearPremiumTypeCodeName: string;

  retroQuoteHowCededTypeCodeName: string;

  retroQuoteJuvenileRateBasisTypeCodeName: string;

  retroQuotePremiumModeTypeCodeName: string;

  retroQuoteReinsuranceTypeCodeName: string;

  retroQuoteTaxRefundTypeCodeName: string;
  retroQuoteCreatedByFirstName: string;

  retroQuoteCreatedByLastName: string;
  retroQuoteRowStatusCodeName: string;

  retroQuoteCompanyContactGroupId: string | null;

  retroQuoteNoteGroupId: string | null;

  retroQuoteTeamAssignmentGroupId: string | null;

  retroRfpId: string;

  retroRfpTeamAssignmentGroupId: string | null;

  retroRfpCompanyContactGroupId: string | null;

  retroProposalId: string;
  parentProposalId: string | null;

  proposalNumber: string;
  proposalMarketingName: string;

  planName: string;

  guaranteedYears: number | null;

  recaptureYears: number | null;

  retroQuotePlanBaseRiderCodeName: string;

  retroQuoteUWClassGroupId: string | null;

  uwClassName: string;

  retroQuotePlanId: string;
  uWClassTobaccoTypeIdSequenceNumber: number | null;

  retroRfpDocumentGroupId: string | null;
  retroQuoteDocumentGroupId: string | null;

  percentAfterLevelTerm: number | null;

  insurancePlan: string;

  exciseTax: number | null;

  premiumTaxRate: number | null;

  isExperienceRating: boolean | null;

  modalFactorAnnual: number | null;

  modalFactorMonthly: number | null;
  modalFactorQuarterly: number | null;

  modalFactorSemiAnnual: number | null;
  retroExpense: number | null;
  jointType: string;
}
