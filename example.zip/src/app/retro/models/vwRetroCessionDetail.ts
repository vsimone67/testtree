export interface vwRetroCessionDetail {
  retroCessionId: string;
  cessionId: string;
  companyName: string;
  treatyNumber: string;
  categoryName: string;
  retroEffectiveDate: Date | null;
  retroCancelDate: Date | null;
  narAmount: number;
  isActive: boolean;
  policyDate: Date | string;
  hasRollback:boolean;
}
