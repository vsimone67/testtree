import { Component, EventEmitter, Input, OnInit, Output, ViewChild, SimpleChange, OnChanges } from "@angular/core";
import { ColDef } from "ag-grid-community";
import { TreatyCompleteModel } from '@assumed/models/TreatyCompleteModel';
import { TreatyService } from '@shared/services/treaty.service';
import { formatNumber } from '@shared/components/grid/formatters/formatNumber';
import { formatDate } from '@shared/components/grid/formatters/formatDate';
import { formatCurrency } from '@shared/components/grid/formatters/formatCurrency';
import { LinkCellComponent } from '@shared/components/grid/link-cell/link-cell.component';
import { PricingService } from '@pricing/services/pricing.service';
import { RetroQuoteModel } from '@retro/models/retroQuoteModel';
import { RetroQuotePlanModel } from '@retro/models/retroQuotePlanModel';
import { RetroQuoteBandRateModel } from '@retro/models/retroQuoteBandRateModel';
import { SplitModel } from '@retro/models/SplitModel';
import { EventService } from '@shared/services/event.service';
import { events } from '@constants/events.model';
import { GraphEventModel } from '@assumed/models/GraphEventModel';
import { SplitsService } from '@retro/services/splits.service';
import { ConfigurableGridComponent } from '@shared/components/grid/configurable-grid/configurable-grid.component';

@Component({
  selector: "splits-grid",
  templateUrl: "./splits-grid.component.html",
  styleUrls: ["./splits-grid.component.css"],
})
export class SplitsGridComponent implements OnInit, OnChanges {
  @Input() EventData: GraphEventModel;
  @ViewChild(ConfigurableGridComponent, { static: false }) grid;
  @Output() hidetable: EventEmitter<Boolean> = new EventEmitter<Boolean>()

  SplitsData: Array<SplitModel>;
  loading: boolean;
  currentCessionNumber: string;
  columnDefs: Array<ColDef>;
  defaultColsSplit: Array<String>
  rowClassRules: any;
  showTreaty: boolean = false;
  showRetroQuote = false;
  showRetroQuotePlan = false;
  showRetroQuoteBandRate = false;
  treatyId: string;
  currentTreaty: TreatyCompleteModel;
  currentRetroQuoteList: Array<RetroQuoteModel>;
  currentRetroQuotePlanList: Array<RetroQuotePlanModel>;
  currentRetroQuoteBandRate: Array<RetroQuoteBandRateModel>;
  constructor(private _treatySerivce: TreatyService, private _splitsService: SplitsService, private _pricingService: PricingService, private _eventService: EventService) {
    this.createSplitsColumns();
    this.currentCessionNumber = "";
    this.rowClassRules = {
      "row-difference": function (params) {
        var retval: boolean = false;

        if (params.data.hasDifferences !== undefined) {
          retval = params.data.hasDifferences;
        }
        return retval;
      },
    };
    // clear any prior split events
    _eventService.clearEvent(events.showSplitsNaarDifferences);
    // listen for NaarSplit Differences event
    _eventService.getEvent(events.showSplitsNaarDifferences).subscribe(
      showDifferences => {
        if (showDifferences) {
          this.checkSplitDifferences();
         //this.turnOnRowColorRules();
        } else {
          //this.turnOffRowColorRules();
          this.turnOffDifferences();
        }

        this.grid.refresh();
      });

    this.loading = true;
  }

  async ngOnInit() {

    this.loading = true;
      await this._splitsService.getSplitsForCession(this.EventData.data.payload.cessionId).then(data=>{
        this.SplitsData = data ;
        this.grid.updateRowData(this.SplitsData)
      })
    this.currentCessionNumber = this.EventData.data.everestCessionNumber.toString();
    this.loading = false;

  }

  checkSplitDifferences() {
    var splitAmount = this.SplitsData[0].splitAmount;

    this.SplitsData.forEach((exp) => {
      if (exp.splitAmount !== splitAmount) exp.hasDifferences = true;
    });
  }

  turnOffDifferences() {
    this.SplitsData.forEach((exp) => (exp.hasDifferences = false));
  }

  turnOnRowColorRules() {
    this.rowClassRules = {
      "row-difference": function (params) {
        var retval: boolean = false;

        if (params.data.hasDifferences !== undefined) {
          retval = params.data.hasDifferences;
        }
        return retval;
      },
    };
  }

  turnOffRowColorRules() {
    this.rowClassRules = {};
  }
  createSplitsColumns() {
    this.columnDefs = this.getColumns();
    this.defaultColsSplit = this.getDefaultColumns();
  }

  refresh() {
    this.grid.refresh();
  }

  hide(visible) {
    this.hidetable.emit(visible)
  }

  async onShowTreatyInfo(gridRow) {
    var splitRecord = <SplitModel>gridRow.rowData;
    this.treatyId = splitRecord.retroTreatyId;

    this.currentTreaty = await this._treatySerivce.getTreatyInfo(this.treatyId);
    this.showTreaty = true;
  }

  async onShowRetroQuote(gridRow) {
       var splitRecord = <SplitModel>gridRow.rowData;
    this.currentRetroQuoteList = await this._pricingService.getRetroQuote(splitRecord.retroQuoteId);
    this.showRetroQuote = true;

  }

  async onShowRetroQuotePlan(gridRow) {

    var splitRecord = <SplitModel>gridRow.rowData;

    this.currentRetroQuotePlanList = await this._pricingService.getRetroQuotePlan(splitRecord.retroQuotePlanId);
    this.showRetroQuotePlan = true;

  }

  async onShowRetroQuoteBandRate(gridRow) {
    var splitRecord = <SplitModel>gridRow.rowData;

    this.currentRetroQuoteBandRate = await this._pricingService.getRetroQuoteBandRates(splitRecord.retroQuoteBandId);
    this.showRetroQuoteBandRate = true;

  }

  hideTreatyDialog() {
    this.showTreaty = false;
  }

  hideRetroQuoteDialog() {
    this.showRetroQuote = false;
  }

  hideRetroQuotePlan() {
    this.showRetroQuotePlan = false;
  }

  hideRetroQuoteBandRate() {
    this.showRetroQuoteBandRate = false;
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    // if options are passed, override default
    if (changes.SplitsData != undefined && this.SplitsData !== undefined) {
      if (this.SplitsData.length > 0)
        this.currentCessionNumber = this.SplitsData[0].everstCessionNumber.toString();
    }
  }

  getColumns() {
    return [
      {
        headerName: "Company Name",
        field: "companyName",
        cellClass: "text-left"
      },
      {
        headerName: "Payor Legal Entity Name",
        field: "payorLegalEntityName",
        cellClass: "text-left"
      }, {
        headerName: "Block Location",
        field: "blockLocation",
        cellClass: "text-left"
      }, {
        headerName: "Duration",
        field: "duration",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Effective Date",
        field: "effectiveDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Cancel Date",
        field: "cancelDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Active",
        field: "isActive",
        cellClass: "text-left"
      }, {
        headerName: "Is Converted",
        field: "isConverted",
        cellClass: "text-left"
      }, {
        headerName: "Is Processed",
        field: "isProcessed",
        cellClass: "text-left"
      }, {
        headerName: "Is Reversed",
        field: "isReversed",
        cellClass: "text-left"
      }, {
        headerName: "Is Billed",
        field: "isBilled",
        cellClass: "text-left"
      }, {
        headerName: "Split Amount",
        field: "splitAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "Ceded Split Amount",
        field: "cededSplitAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency
      }, {
        headerName: "NAAR Ratio",
        field: "naarRatio",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Split Category",
        field: "splitCategory",
        cellClass: "text-left"
      }, {
        headerName: "Split Type",
        field: "splitType",
        cellClass: "text-left"
      },
      {
        headerName: "Transaction Type",
        field: "transactionType",
        cellClass: "text-left"
      },
      {
        headerName: "Retention Stack Name",
        field: "retentionStackName",
        cellClass: "text-left"
      }, {
        headerName: "Retro Pool Name",
        field: "retroPoolName",
        cellClass: "text-left"
      }, {
        headerName: "Retro Proposal Share Percent",
        field: "retroProposalSharePercent",
        cellClass: "text-left",
        valueFormatter: formatNumber
      }, {
        headerName: "Retro Proposal Share Type",
        field: "retroProposalShareType",
        cellClass: "text-left"
      }, {
        headerName: "Retro Quote Band Name",
        field: "retroQuoteBandName",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowRetroQuoteBandRate.bind(this)
        },
        cellClass: "text-left"
      }, {
        headerName: "Retro Quote Number",
        field: "retroQuoteNumber",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowRetroQuote.bind(this)
        },
        cellClass: "text-left"
      }, {
        headerName: "Retro Quote Plan Name",
        field: "retroQuotePlanName",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowRetroQuotePlan.bind(this)
        },
        cellClass: "text-left"
      }, {
        headerName: "Retro Treaty Number",
        field: "retroTreatyNumber",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowTreatyInfo.bind(this),
        },
        cellClass: "text-left"
      }, {
        headerName: "Retro Treaty Plan Coverage Effective Date",
        field: "retroTreatyPlanCoverageEffectiveDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Production Cancel Date",
        field: "productionCancelDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }, {
        headerName: "Production Effective Date",
        field: "productionEffectiveDate",
        cellClass: "text-left",
        valueFormatter: formatDate
      }
    ];
  }

  getDefaultColumns() {
    return ["companyName", "payorLegalEntityName", "splitAmount", "cededSplitAmount", "retroTreatyNumber", "retroQuoteBandName", "retroQuotePlanName", "retroQuoteNumber"];

  }
}
