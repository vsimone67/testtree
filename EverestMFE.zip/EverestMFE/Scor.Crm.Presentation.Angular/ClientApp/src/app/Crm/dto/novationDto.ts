import { CompanyDto } from './companyDto';

export interface NovationDto {
    novationId: string;
    companyId: string;
    isRowActive: boolean | null;
    parentRowId: string | null;
    treatyPlanId: string;
    rowCancelDate: string | null;
    rowEffectiveDate: string | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    parentRow: NovationDto;
    inverseParentRow: NovationDto[];
}