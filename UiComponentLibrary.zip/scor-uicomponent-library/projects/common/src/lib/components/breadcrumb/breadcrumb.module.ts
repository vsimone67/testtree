import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BreadcrumbComponent } from './breadcrumb.component';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MenuModule } from 'primeng/menu';
import { MenubarModule } from 'primeng/menubar';
@NgModule({
  declarations: [BreadcrumbComponent],
  imports: [CommonModule, BreadcrumbModule, MenuModule, MenubarModule],
  exports: [BreadcrumbComponent],
})
export class BreadCrumbModule {}
