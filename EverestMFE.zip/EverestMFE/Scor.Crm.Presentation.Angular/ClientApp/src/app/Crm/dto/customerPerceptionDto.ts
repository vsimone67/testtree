import { CompanyDto } from './companyDto';
import { GeneraliProductAllocationDto } from './generaliProductAllocationDto';

export interface CustomerPerceptionDto {
    customerPerceptionId: string;
    customerId: string;
    generaliDivisionId: string | null;
    actuarialServicesTypeId: string | null;
    capacityTypeId: string | null;
    clientOrientationTypeId: string | null;
    companyHistory: string;
    financialSecurityTypeId: string | null;
    financialValueTypeId: string | null;
    innovationCreativityTypeId: string | null;
    isRelationshipInDanger: boolean | null;
    marketingKnowledgeTypeId: string | null;
    reinsuranceUse: string;
    relationshipCompetition: string;
    relationshipDangerReason: string;
    relationshipProblems: string;
    relationshipWorking: string;
    technologyTypeId: string | null;
    tierTypeId: string | null;
    timelyServiceTypeId: string | null;
    uwcapabilitesTypeId: string | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    customer: CompanyDto;
    generaliProductAllocation: GeneraliProductAllocationDto[];
}