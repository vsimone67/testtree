import { Component, OnInit, Input } from '@angular/core';
import { InsurancePlanModel } from '@assumed/models/InsurancePlanModel';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';

@Component({
  selector: 'insurance-plan-dialog',
  templateUrl: './insurance-plan-dialog.component.html',
  styleUrls: ['./insurance-plan-dialog.component.css']
})
export class InsurancePlanComponent extends DialogBase implements OnInit {

  @Input() insurancePlanModel: InsurancePlanModel;
  constructor() { super(); }

  ngOnInit(): void {
  }

}
