import { ContactDto } from './contactDto';
import { MarketingListDto } from './marketingListDto';

export interface MarketingListContactDto {
    marketingListId: string;
    contactId: string;
    isAcceptedEvent: boolean | null;
    isAttendedEvent: boolean | null;
    guestNames: string;
    guestAcceptedCount: number | null;
    guestAttendedCount: number | null;
    marketingContactNote: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string;
    contact: ContactDto;
    marketingList: MarketingListDto;
}