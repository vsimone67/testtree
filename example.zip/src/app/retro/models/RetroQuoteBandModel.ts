export interface RetroQuoteBandModel
{
    retroQuoteBandId: string;
    bandName: string;
    documentGroupId: string | null;
    isIdenticalAllowances: boolean | null;
    isIdenticalPremiums: boolean | null;
    maxBandValue: number | null;
    minBandValue: number | null;
    noteGroupId: string | null;
    overallMortalityAdjustmentFactorTypeId: string | null;
    premiumOtherType: string;
    tetroQuotePlanId: string;
    tateTableId: string | null;
    uwclassGroupId: string | null;
    vreateDate: Date | string | null;
    vreatedBy: string | null;
    modifiedDate: Date | string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
}
