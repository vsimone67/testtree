namespace CmdQueryGenerator
{
    public class ParameterInfo
    {
        public string ParameterUpper { get; set; }
        public string ParameterLower { get; set; }
        public string ParameterType { get; set; }

    }

}
