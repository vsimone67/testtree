export class BreadCrumbModel {
  parentLabel: string;
  parentUrl: string;
  label: string;
  url: string;
}
