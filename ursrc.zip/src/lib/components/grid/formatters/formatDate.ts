export function formatDate(data: any) {
  return data.value ? new Date(data.value).toLocaleDateString() : '';
}
