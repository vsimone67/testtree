import { CodeDto } from './codeDto';
import { StrategyDto } from './strategyDto';

export interface SalesObjectiveDto {
    salesObjectiveId: string;
    strategyId: string;
    salesObjectiveNote: string;
    salesObjectiveTypeId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    salesObjectiveType: CodeDto;
    strategy: StrategyDto;
}