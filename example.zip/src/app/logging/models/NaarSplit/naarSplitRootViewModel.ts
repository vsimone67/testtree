import { CessionViewModel } from "./cessionViewModel";

export interface NaarSplitRootViewModel {
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  gender: string;
  residence: string;
  numberOfCessions: number;
  cessions: CessionViewModel[];
}
