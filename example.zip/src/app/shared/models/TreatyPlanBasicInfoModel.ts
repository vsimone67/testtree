export interface TreatyPlanBasicInfoModel {
  responsibleCompanyName: string;
  companyId: string;
  insurancePlanShortName: string;
  insurancePlanLongName: string;
  responsibleCompanyId: string;
  treatyPlanCoverageEffectiveDate: Date;
  treatyPlanTerminatedDate: Date | null;
  treatyPlanTerminatedForNewBusinessDate: Date | null;
  responsibleTransferTypeId: string | null;
  responsibleTransferTypeIdCodeName: string;
  quotePlanPlanName: string;
  treatyPlanRowStatusIdCodeName: string;
  treatyPlanTreatyId: string;
  quotePlanId: string;
  proposalId: string;
  pricingInsurancePlanId: string;
  bandName: string;
  minBandValue: number | null;
  maxBandValue: number | null;
  treatyPlanId: string;
}
