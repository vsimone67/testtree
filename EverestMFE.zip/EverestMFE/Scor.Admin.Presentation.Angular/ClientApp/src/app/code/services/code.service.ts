import { Injectable } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService, HttpService } from '@scor/common';
import { CodeCategoryModel } from '../models/CodeCategoryModel';
import { CodeModel } from '../models/CodeModel';

@Injectable({
  providedIn: 'root',
})
export class CodeService {
  private _codeUrl: string;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this._codeUrl = `${this._appSettingsService.GetValue('apiGatewayUrl')}/${
      SiteConstants.codeController
    }`;
  }

  async getCodeCategories() {
    return await this._httpService.getData<Array<CodeCategoryModel>>(
      `${this._codeUrl}/GetCodeCategories`
    );
  }

  async getCodeValueByCategory(codeCategoryId: string) {
    return await this._httpService.getData<Array<CodeModel>>(
      `${this._codeUrl}/GetAllCodeByCategory/` + codeCategoryId
    );
  }

  async updateCode(codeModel: CodeModel) {
    console.log(codeModel);
    return await this._httpService.postData(
      `${this._codeUrl}/EditCode`,
      codeModel
    );
  }

  async insertCode(codeModel: CodeModel) {
    return await this._httpService.postData(
      `${this._codeUrl}/AddCode`,
      codeModel
    );
  }
}
