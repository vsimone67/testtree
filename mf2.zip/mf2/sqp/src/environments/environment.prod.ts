export const environment = {
  production: true,
  standalone: false,
};
