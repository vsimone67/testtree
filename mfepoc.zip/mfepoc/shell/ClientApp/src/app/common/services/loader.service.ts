import { VariableAst } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { events } from '@constants/events.model';
import { AppSettingsService, EventService } from '@scor/common';
import { MicroFrontEnd } from '../models/microFrontEnd';

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  public _microFontEnds: Array<MicroFrontEnd>;
  public moo: Array<string> = [];
  constructor(
    private appsettings: AppSettingsService,
    private _eventService: EventService,
    private router: Router
  ) {
    this._microFontEnds = <Array<MicroFrontEnd>>(
      this.appsettings.GetValue('microFrontEnds')
    );


  }

  loadMicroFrontEnd(name: string): void {
    var microFrontEnd = this._microFontEnds.find((exp) => exp.name === name);

    if (this.moo.find(mox => mox === name) === undefined) {
      this.moo.push(name);
      microFrontEnd.loaded = false;
    }
    else {
      microFrontEnd.loaded = true;
    }


    // only load the MFE once
    if (!microFrontEnd.loaded) {
      this._eventService.sendEvent(events.loadingEvent, true);

      microFrontEnd.loaded = true;

      const content = document.getElementById('content');
      const script = document.createElement('script');
      script.src = microFrontEnd.path;
      content.appendChild(script);

      const element: HTMLElement = document.createElement(
        microFrontEnd.element
      );

      element['hidden'] = !location.hash.startsWith('#' + microFrontEnd.url);
      content.appendChild(element);

      script.onerror = () =>
        console.error(`error loading ${microFrontEnd.path}`);

      this._eventService.sendEvent(events.loadingEvent, false);
    }

  }

  showClient(clientName: string) {
    this.setClientVisibility(clientName, true);
  }

  hideClient(clientName: string) {
    this.setClientVisibility(clientName, false);
  }

  hideAllClients() {

    this._microFontEnds.forEach(mfe => {
      mfe.loaded = false;
      this.setClientVisibility(mfe.name,false);
    });

  }

   setClientVisibility(clientName: string, show: boolean) {
    var microFrontEnd = this._microFontEnds.find((exp) => exp.name === clientName);

    if (!microFrontEnd) {
      throw new Error(`Client ${clientName} is not configured.`);
    }

    const elms = document.getElementsByTagName(microFrontEnd.element);

    if (elms.length === 0) {
      //throw new Error(`Client ${clientName} is not loaded.`);
      return;
    }

    if (elms.length > 1) {
      throw new Error(`Client ${clientName} is loaded several times.`);
    }

    const elm = elms[0];
    elm['hidden'] = !show;
  }

  navigate(name: string, url: string) {
    this.loadMicroFrontEnd(name);
    this.hideAllClients();
    this.showClient(name);
    this.router.navigateByUrl(url);

  }


}
