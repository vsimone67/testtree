import {Component, Input, OnInit} from '@angular/core';
import {SplitAnalysisViewModel} from "../../models/NaarSplit/SplitAnalysisViewModel";
import {formatDate} from "@shared/componentsgrid/formatters/formatDate";
import {formatCurrency} from "@shared/componentsgrid/formatters/formatCurrency";
import {TreatyService} from "@shared/service/treaty.service";
import {TreatyCompleteModel} from "@assumed/models/TreatyCompleteModel";

@Component({
  selector: 'splits-analysis',
  templateUrl: './splits-analysis.component.html',
  styleUrls: ['./splits-analysis.component.css']
})
export class SplitsAnalysisComponent implements OnInit {

  splitsData: any[];
  @Input() loading: boolean
  columnDefs: Array<{
    headerName: string,
    field: string,
    valueFormatter?: any,
    entry?: boolean
  }>;
  showtreaty: boolean = false;
  treatyId: string;
  currentTreaty: TreatyCompleteModel

  constructor(private _treatySerivce: TreatyService) {
    this.columnDefs = this.createColumnDefs();
  }

  @Input('splitsData') set setSplitsData(splits) {
    this.updateSplits(splits)

  }

  updateSplits(liste: SplitAnalysisViewModel[]) {
    this.splitsData = [];
    liste.forEach(analysis => {
      let data: any = {};
      data.data = {}
      data.data.cessionNumber = analysis.cessionNumber;
      data.children = [];
      analysis.children.forEach((split: any) => {
        this.columnDefs.forEach(col => {
          switch (col.field) {
            case 'effectiveDate':
              split[col.field] = formatDate({value: split[col.field]});
              break;
            case 'splitAmount':
            case 'cededAmount':
              split[col.field] = formatCurrency({value: split[col.field]});
              break;
            default :
              break;
          }
        })
        data.children.push({data: split})
      })
      this.splitsData.push(data)
    })
  }

  ngOnInit(): void {

  }

  createColumnDefs() {
    return [
      {
        headerName: "cession Number",
        field: "cessionNumber"
      },
      {
        headerName: "Pool Name",
        field: "poolName"

      },
      {
        headerName: "Effective Date",
        field: "effectiveDate",
        valueFormatter: formatDate
      },
      {
        headerName: "Comapny Name",
        field: "retroCompanyName"
      },
      {
        headerName: "Treaty Number",
        field: "treatyNumber",
        entry: true
      },
      {
        headerName: "Split Type",
        field: "splitType"
      },
      {
        headerName: "Split Category",
        field: "splitCategory"
      },
      {
        headerName: "Split Amount",
        field: "splitAmount",
        valueFormatter: formatCurrency
      },
      {
        headerName: "Ceeded Amount",
        field: "cededAmount",
        valueFormatter: formatCurrency
      },
    ];
  }

  hideTreatyDialog() {
    this.showtreaty = false
  }

  async show(type, row) {
    switch (type) {
      case 'treatyNumber':
        this.treatyId = row.treatyId;
        if (this.treatyId) {
          this.currentTreaty = await this._treatySerivce.getTreatyInfo(this.treatyId);
          this.showtreaty = true;
        }


    }
  }
}
