export interface RetroQuotePlanModel {
  retroQuotePlanId: string;

  retroQuoteId: string;

  allowRecapture: boolean | null;

  baseRiderTypeId: string | null;

  retroQuotePlanDocumentGroupId: string | null;

  expiryAge: number | null;

  ruaranteedYears: number | null;

  isFrasierized: boolean | null;

  maxBenefitPeriod: number | null;

  maxBenefitPeriodType: string | null;

  retroQuotePlanNoteGroupId: string | null;

  planDescription: string;

  planName: string;

  pricingInsurancePlanId: string;

  recaptureYears: number | null;

  singleJointTypeId: string | null;

  retroQuotePlanCreateDate: Date | string;

  retroQuotePlanCreatedBy: string | null;

  retroQuotePlanModifiedDate: Date | string | null;

  retroQuotePlanModifiedBy: string | null;

  retroQuotePlanBaseRiderCodeName: string;
  retroQuotePlanMaxBenefitCodeName: string;
  retroQuotePlanSingleJointCodeName: string;
  retroQuotePlanRowStatusCodeName: string;
  retroQuoteName: string;
  retroQuoteNumber: string;
  cedingCompanyBenefitName: string;
  isBenefitOptionEmbedded: boolean | null;
  isChargeForRetro: boolean | null;
  isPricingAllowanceSameAsBase: boolean | null;
  rateYear1: number | null;
  rateYear2: number | null;
  insuranceBenefitId: string;
  issueType: string;
  insuranceBenefitShortName: string;
  isJLSZeroYearOne: boolean | null;
  jLSMinPremium: number | null;
  benefitName: string;
  retroExpense: number | null;
}
