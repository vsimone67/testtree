export interface RateTableModel{
    RateTableId: string;
    RateBasisTableTypeId: string | null;
    RateTableName: string;
    RateTableDescription: string;
    RateTableNumber: string;
    RateTableTypeId: string | null;
    CreateDate : Date | string | null;
    CreatedBy: string | null;
    ModifiedDate : Date | string | null;
    ModifiedBy: string | null;
    IsTemplate : boolean | null;
    RateTableTemplateId: string | null;
    LevelTermRenewalYears: number | null;
    LevelTermDurationYears : number | null;
    SelectPeriodYears: number | null;
    RateTableAgeTypeId: string | null;
}