export class GridStyleModel {
  public width: string;
  public height: string;
}
