import { DatePipe } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { GroupModel } from '../../models/group-model';
import { SecurityGroupsService } from '../../services/security-groups.service';

@Component({
  selector: 'app-groups-search',
  templateUrl: './groups-search.component.html',
  styleUrls: ['./groups-search.component.css'],
})
export class GroupsSearchComponent implements OnInit {
  formRuns;
  groups: any[];
  fullGroups: any[];
  @Output() searchData: EventEmitter<any> = new EventEmitter<any>();
  @Output() dataSelection: EventEmitter<any> = new EventEmitter<any>();
  paginator;
  teamId;
  loadingField: boolean = false;
  showDialog: boolean = false;
  showAddRoleDialog: boolean = false;
  showEditDialog: boolean = false;
  newGroup: GroupModel;
  allowAdd: boolean = false;
  showAll: boolean = false;
  selectedGroup;
  groupId;

  constructor(
    private fb: FormBuilder,
    private pipe: DatePipe,
    private groupService: SecurityGroupsService
  ) {
    this.formRuns = this.fb.group({
      groupId: [null, Validators.required],
    });
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    const newGroups = await this.groupService.getGroups();

    this.fullGroups = newGroups;

    this.groups = [];
    newGroups.forEach((line: GroupModel) => {
      if (line)
        this.groups.push({
          label: line.groupName,
          value: line.groupId,
        });
    });
  }

  reset() {
    this.formRuns.reset();
    this.searchData.emit(null);
  }

  search() {
    this.loadingField = true;
    if (this.formRuns.valid) {
      this.searchData.emit(this.formRuns.value);
      this.allowAdd = true;
    }

    this.loadingField = false;
  }

  updateDrops(data) {
    this.allowAdd = !(data.value == null);

    for (var i = 0; i < this.groups.length; ++i) {
      if (this.fullGroups[i].groupId == this.formRuns.value.groupId) {
        this.selectedGroup = this.fullGroups[i];
        this.dataSelection.emit(this.selectedGroup);
        this.search();
      }
    }
  }

  addGroup() {
    this.showDialog = true;
    this.newGroup = <GroupModel>{};
  }

  addRoleToGroup() {
    if (!this.allowAdd) {
      return;
    }
    this.showAddRoleDialog = true;
  }

  editGroup() {
    if (!this.allowAdd) {
      return;
    }
    this.showEditDialog = true;
  }

  closeAddDialog() {
    this.showDialog = false;
  }

  closeEditDialog() {
    this.showEditDialog = false;
  }

  closeAddRoleDialog() {
    this.showAddRoleDialog = false;
  }

  saveRecord(data) {
    this.getInitialData();
  }

  saveEditRecord(data) {
    this.reset();
    this.getInitialData();
  }

  saveAddRoleRecord(data) {
    this.search();
  }
}
