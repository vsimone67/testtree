export interface RetroQuoteBandRateModel {

  retroQuoteBandId: string;

  uwClassName: string;

  bandName: string;
  retroPremiumRateId: string;
  parentId: string;

  minDuration: number;
  maxDuration: number;
  minIssueAge: number;

  maxIssueAge: number;
  uWClassId: string | null;
  pricingRate: number;

  sequenceNumber: number | null;
  retroPremiumRateTypeIdCodeName: string;
  retroPremiumRateMalePricingRate: number;

  retroPremiumRateFemalePricingRate: number;
  retroPremiumRateBothGenderPricingRate: number;
  retroPremiumRateGenderTypeIdCodeName: string;
  rateTableName: string;

  isIdenticalAllowances: boolean | null;

  isIdenticalPremiums: boolean | null;



}
