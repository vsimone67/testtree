import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotesComponents } from './notes-components.component';

describe('NotesListComponent', () => {
  let component: NotesComponents;
  let fixture: ComponentFixture<NotesComponents>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotesComponents ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesComponents);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
