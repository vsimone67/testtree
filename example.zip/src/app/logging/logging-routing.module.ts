import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { SiteConstants } from "@constants/siteConstants";
import { LogViewerComponent } from "./components/log-viewer/log-viewer.component";
import { UserAuthGuard } from "@auth/services/user-auth-guard";

const routes: Routes = [
  {
    path: `${SiteConstants.logRoute}/:id`,
    data: {
      breadcrumb: "Naar Split Logging",
    },
    component: LogViewerComponent,
    pathMatch: "full",
    canActivate: [UserAuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoggingRoutingModule {}
