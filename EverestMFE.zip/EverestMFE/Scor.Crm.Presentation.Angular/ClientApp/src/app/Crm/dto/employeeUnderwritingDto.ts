import { EmployeeDto } from './employeeDto';
import { EmployeeUnderwritingCountryDto } from './employeeUnderwritingCountryDto';
import { EmployeeUnderwritingExcludedCompaniesDto } from './employeeUnderwritingExcludedCompaniesDto';
import { EmployeeUnderwritingLanguageDto } from './employeeUnderwritingLanguageDto';
import { EmployeeUnderwritingSeriesDto } from './employeeUnderwritingSeriesDto';

export interface EmployeeUnderwritingDto {
    employeeId: string;
    dailyFacCaseAssignments: number;
    dailyFacCaseCount: number;
    maximumFacCaseCount: number;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    lastTaskAssignedDate: string | null;
    employee: EmployeeDto;
    employeeUnderwritingCountry: EmployeeUnderwritingCountryDto[];
    employeeUnderwritingExcludedCompanies: EmployeeUnderwritingExcludedCompaniesDto[];
    employeeUnderwritingLanguage: EmployeeUnderwritingLanguageDto[];
    employeeUnderwritingSeries: EmployeeUnderwritingSeriesDto[];
}