import { Component, Input, SimpleChange } from "@angular/core";
import { ColDef, GridOptions, GridApi } from "ag-grid-community";

@Component({
  template: "",
})
export class GridBase {
  @Input() options!: GridOptions;
  @Input() ColumnDefs!: Array<ColDef>;
  @Input() RowData!: Array<any>;
  @Input() GridCssClass!: string;
  @Input() GridCssStyle!: string;
  @Input() SizeColsToFit!: boolean;

  gridApi!: GridApi;
  currentGridOptons!: GridOptions;
  resizeColumns: boolean;

  constructor() {
    this.defaultGridOptions();
    this.resizeColumns = false;
  }

  defaultGridOptions() {
    this.currentGridOptons = {
      defaultColDef: {
        sortable: true,
        resizable: true,
      },
      pagination: false,
      paginationAutoPageSize: true,
    };

    this.GridCssClass = "ag-theme-alpine"; // default to alpine theme
    this.GridCssStyle = "width: 100%; height: 250px;"; // default width and height
  }

  onGridReady(params: any) {
    this.gridApi = params.api;

    if (this.resizeColumns) {
      this.gridApi.sizeColumnsToFit(); // size grid to take up all availibe realestate
    }
  }

  resizeGrid() {
    this.gridApi.sizeColumnsToFit();
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {

    // if options are passed, override default
    if (changes.options != undefined) {
      this.currentGridOptons = changes.options.currentValue;
    }

    if (changes.GridCssClass !== undefined) {
      this.GridCssClass = changes.GridCssClass.currentValue;
    }

    if (changes.GridCssStyle !== undefined) {
      this.GridCssStyle = changes.GridCssStyle.currentValue;
    }

    if (this.SizeColsToFit !== undefined) {
      this.resizeColumns = changes.SizeColsToFit.currentValue;
    }

  }

}
