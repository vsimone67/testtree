import {Component, Input, OnInit} from '@angular/core';
import {CessionHistoryModel} from '@assumed/models/CessionHistoryModel';
import {EditDialogBase} from '../EditDialogBase';
import {formatDate} from "@shared/functions/formatDate";

@Component({
  selector: 'cession-history-dialog',
  templateUrl: './cession-history-dialog.component.html',
  styleUrls: ['./cession-history-dialog.component.css']
})
export class CessionHistoryDialogComponent extends EditDialogBase<CessionHistoryModel> implements OnInit {
  cessionId: string;
  @Input() cessionHistoryList: Array<CessionHistoryModel>;
  policyDate:string
  ;
  errors: { key: string, value: string }[];
   originalIssueDate: string;
  reinsuranceEffectiveDate:string
  constructor() {
    super();
  }

  ngOnInit(): void {
    this.cessionId = this.dialogData.cessionId;
    this.policyDate = formatDate(this.dialogData.policyDate);
    this.originalIssueDate = formatDate(this.dialogData.originalIssueDate)
    this.reinsuranceEffectiveDate = formatDate(this.dialogData.reinsuranceEffectiveDate)
  }

  hasGaps() {
    let previousCessionHistory: CessionHistoryModel = null;
    this.cessionHistoryList.forEach(history => {
      let effectiveDate: Date = new Date(history.effectiveDate)
      if (previousCessionHistory != null &&
        effectiveDate.setDate(effectiveDate.getDate() - 1).toString() !== previousCessionHistory.cancelDate
        && history.effectiveDate > previousCessionHistory.cancelDate
      ) {
        return history.effectiveDate;
      }
      previousCessionHistory = history
    })
    return null;
  }

  validateData() {
    this.errors = [];

    let validated: boolean = true;
    this.cessionHistoryList.forEach(history => {
      if (new Date(this.dialogData.effectiveDate) > new Date(history.effectiveDate)
        && new Date(this.dialogData.effectiveDate) < new Date(history.cancelDate) && this.dialogData.cessionHistoryId !== history.cessionHistoryId) {
        if (this.errors.filter(err => err.key === 'EffectiveDate').length === 0) {
          this.errors.push({
            key: 'EffectiveDate',
            value: 'Effective Date cannot fall between Effective and Cancel Dates of another History on this Cession.'
          })
          validated = false;
        }

      }
      if (new Date(this.dialogData.cancelDate) > new Date(history.effectiveDate) && new Date(this.dialogData.cancelDate) < new Date(history.cancelDate)
        && this.dialogData.cessionHistoryId !== history.cessionHistoryId) {
        if (this.errors.filter(err => err.key === 'CancelDate').length === 0) {
          this.errors.push({
            key: 'CancelDate',
            value: 'Cancel Date cannot fall between Effective and Cancel Dates of another History on this Cession.'
          })
          validated = false;
        }
      }
    })

    if (this.hasGaps() != null) {
      if (this.errors.filter(err => err.key === 'EffectiveDateGaps').length === 0) {
        this.errors.push({
          key: "EffectiveDateGaps"
          , value: "Please ensure there are no gaps between histories."
        });
        validated = false;
      }
    }
    /*) Effective Date and Cancel Date cannot be more than one year apart
            b) Cancel Date must be after Effective Date
    */
    if (this.dialogData.effectiveDate > this.dialogData.cancelDate) {
      this.errors.push({
        key: 'CancelDateBeforeEffective',
        value: 'Cancel Date must be after Effective Date.'
      })
      validated = false;
    }
    if (new Date(this.dialogData.cancelDate).getFullYear() - new Date(this.dialogData.effectiveDate).getFullYear() > 1) {
      this.errors.push({
        key: 'differencebetweendates',
        value: 'Effective Date and Cancel Date cannot be more than one year apart'
      })
      validated = false;
    }

    let policyyears;
    let date =  new Date('0001-01-01');
    var difference_In_Time = new Date(this.dialogData.effectiveDate).getTime() - new Date(this.dialogData.policyDate).getTime();
    var difference_In_Days = difference_In_Time / (1000 * 3600 * 24);
    if(difference_In_Days>0){
      policyyears = new Date(difference_In_Time+date.getTime()).getFullYear();
    }
    else  {
      date.setDate(date.getDate()+1)
      policyyears = date.getFullYear();
    }
    if(this.dialogData.reinsuranceDuration>policyyears+1){
      this.errors.push({
        key: 'reinsurancedurationRange',
        value: 'Reinsurance Duration must be within range'
      })
      validated = false;
    }
    if (validated) {
      this.submitDialog()
    }
  }


}
