import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleSortGridComponent } from './multiple-sort-grid.component';

describe('MultipleSortGridComponent', () => {
  let component: MultipleSortGridComponent;
  let fixture: ComponentFixture<MultipleSortGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultipleSortGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleSortGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
