import { DatePipe } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { RegionModel } from '../../models/region-model';
import { RegionService } from '../../services/region.service';

@Component({
  selector: 'app-regions-search',
  templateUrl: './regions-search.component.html',
  styleUrls: ['./regions-search.component.css'],
})
export class RegionsSearchComponent implements OnInit {
  formRuns;
  regions: any[];
  @Output() searchData: EventEmitter<any> = new EventEmitter<any>();
  @Output() searchDataNoFilters: EventEmitter<any> = new EventEmitter<any>();
  paginator;
  teamId;
  loadingField: boolean = false;
  showEditDialog: boolean = false;
  showAddDialog: boolean = false;
  newRegion: RegionModel;
  allowAdd: boolean = false;
  showAll: boolean = false;
  selectedRegion;
  regionId: string;

  constructor(
    private fb: FormBuilder,
    private pipe: DatePipe,
    private regionService: RegionService
  ) {
    this.formRuns = this.fb.group({
      regionId: [null, Validators.required],
    });
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    const newRegions = await this.regionService.getRegions();

    this.regions = [];
    newRegions.forEach((line: RegionModel) => {
      if (line)
        this.regions.push({
          label: line.codeName,
          value: line.codeId,
        });
    });

    for (var i = 0; i < this.regions.length; ++i) {
      if (this.regions[i].value == this.formRuns.value.regionId) {
        this.selectedRegion = this.regions[i];
      }
    }
  }

  reset() {
    this.formRuns.reset();
    this.searchData.emit(null);
  }

  search() {
    this.loadingField = true;
    if (this.formRuns.valid) {
      this.searchData.emit(this.formRuns.value);
      this.allowAdd = true;
    }
    this.loadingField = false;
  }

  updateDrops(data) {
    this.allowAdd = !(data.value == null);

    for (var i = 0; i < this.regions.length; ++i) {
      if (this.regions[i].value == this.formRuns.value.regionId) {
        this.selectedRegion = this.regions[i];
        this.search();
      }
    }
  }

  editRegion() {
    this.showEditDialog = true;
  }

  hideEditDialog() {
    this.showEditDialog = false;
  }

  saveEdit(data) {
    this.getInitialData();
    this.searchDataNoFilters.emit();
  }

  addCountry() {
    this.showAddDialog = true;
  }

  hideAddDialog() {
    this.showAddDialog = false;
  }

  saveAdd(data) {
    this.searchDataNoFilters.emit();
  }
}
