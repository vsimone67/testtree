export function formatRowStatusToWord(param) {
  return param.value.toUpperCase() == "04D3195C-C00A-4D22-AB3A-4526E4C5BDC5"
    ? "InActive"
    : "Active";
}
