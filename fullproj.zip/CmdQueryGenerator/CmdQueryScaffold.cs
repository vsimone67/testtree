using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace CmdQueryGenerator
{
    public class CmdQueryScaffold
    {
        public string SourceFileName { get; set; }
        public string MethodToGenerate { get; set; }
        public string DBService { get; set; }
        public string ProjectPath { get; set; }
        public string ControllerName { get; set; }
        public string CodeNamespace { get; set; }
        private CompilationUnitSyntax _root;
        private string QueryText;
        private string QueryHandlerText;
        private string HttpGetText;
        private string CommandText;
        private string CommandHandlerText;
        private string HttpPostText;

        public CmdQueryScaffold(string sourceFileName, string methodToGenerate)
        {
            SourceFileName = sourceFileName;
            MethodToGenerate = methodToGenerate;
        }

        public void GenerateFiles()
        {
            LoadSourceFile();
            LoadTemplates();
            DefaultNames();
            ScaffoldFiles();
        }

        private void LoadSourceFile()
        {
            using (StreamReader sr = File.OpenText(SourceFileName))
            {
                var sourceCode = sr.ReadToEnd();

                var tree = CSharpSyntaxTree.ParseText(sourceCode);
                _root = (CompilationUnitSyntax)tree.GetRoot();
            }
        }

        private void LoadTemplates()
        {
            var rootDir = System.IO.Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            QueryText = File.OpenText($"{rootDir}/templates/myquery.txt").ReadToEnd();
            QueryHandlerText = File.OpenText($"{rootDir}/templates/myqueryhandler.txt").ReadToEnd();

            CommandText = File.OpenText($"{rootDir}/templates/mycommandcommand.txt").ReadToEnd();
            CommandHandlerText = File.OpenText($"{rootDir}/templates/mycommandcommandHandler.txt").ReadToEnd();

            HttpGetText = File.OpenText($"{rootDir}/templates/httpget.txt").ReadToEnd();
            HttpPostText = File.OpenText($"{rootDir}/templates/httppost.txt").ReadToEnd();
        }

        private void DefaultNames()
        {
            var nameSpace = _root.DescendantNodes().OfType<NamespaceDeclarationSyntax>().First().Name.ToFullString();
            var nameSpaceParse = nameSpace.Split(".");
            CodeNamespace = $"{nameSpaceParse[0]}.{nameSpaceParse[1]}.{nameSpaceParse[2]}";
            DBService = Path.GetFileName(SourceFileName).Replace(".cs", "");
            ProjectPath = Path.GetFullPath(SourceFileName);
            // remove two layers of the path
            int pos = ProjectPath.IndexOf("Persistence");
            ProjectPath = ProjectPath.Substring(0, pos - 1);
            ControllerName = nameSpaceParse[1] + "Controller";
        }

        private void ScaffoldFiles()
        {
            // get all properties in class
            List<MethodDeclarationSyntax> methods = null;

            if (string.IsNullOrEmpty(MethodToGenerate))
                methods = _root.DescendantNodes().OfType<MethodDeclarationSyntax>().ToList();
            else
                methods = _root.DescendantNodes().OfType<MethodDeclarationSyntax>().Where(exp => exp.Identifier.ToFullString().ToUpper() == MethodToGenerate.ToUpper()).ToList();

            foreach (var method in methods)
            {
                var methodName = method.Identifier.ToString();
                var returnType = method.ReturnType.ToString().Replace("Task<", "").Replace(">>", ">");
                returnType = returnType.Contains("List") ? returnType : returnType.Replace(">", "");

                var parameterList = method.ParameterList.Parameters.ToList();
                var dtoType = "";

                if (string.IsNullOrEmpty(returnType))
                {
                    returnType = "Unit";
                    dtoType = "";
                }
                else
                {
                    var className = returnType.Replace("List<", "").Replace(">", "");
                    dtoType = className + "Dto";
                    returnType = returnType.Replace(className, dtoType);
                }

                var parameterInfo = new MethodSignature()
                {
                    ReturnValue = returnType,
                    MethodName = methodName,
                    Dto = dtoType,
                    ParameterList = method.ParameterList.Parameters.ToList(),
                    Parms = method.ParameterList.ToString()
                };

                parameterInfo.Parms.Replace("(", "").Replace(")", "");

                CreateParameterList(parameterInfo);

                if (methodName.Substring(0, 3) == "Get" || methodName.Substring(0, 6) == "Delete")
                {
                    ProcessQuery(parameterInfo);
                    ProcessControllerGet(parameterInfo);
                }
                if (methodName.Substring(0, 3) == "Add" || methodName.Substring(0, 4) == "Edit")
                {
                    ProcessCommand(parameterInfo);
                    ProcessControllerPost(parameterInfo);
                }
            }
        }
        private MethodSignature CreateParameterList(MethodSignature methodSignature)
        {
            foreach (var parameter in methodSignature.ParameterList)
            {
                var lines = parameter.ToFullString().TrimStart().Split(" ");

                if (lines.Count() > 1)
                {
                    var parameterLine = lines[1].First().ToString().ToUpper() + lines[1].Substring(1);

                    methodSignature.ParameterInfoList.Add(new ParameterInfo()
                    {
                        ParameterLower = lines[1],
                        ParameterUpper = parameterLine,
                        ParameterType = lines[0]
                    });
                }
            }

            return methodSignature;
        }

        private void ProcessQuery(MethodSignature methodSignature)
        {
            // query
            var queryFile = (string)QueryText.Clone();
            queryFile = queryFile.Replace("MyNamespace", CodeNamespace);
            queryFile = queryFile.Replace("MyQuery", $"{methodSignature.MethodName}Query");
            queryFile = queryFile.Replace("MyType", $"{methodSignature.ReturnValue}");
            var parameterProperty = "";

            foreach (var property in methodSignature.ParameterInfoList)
            {
                parameterProperty += "public ";
                parameterProperty += $"{property.ParameterType} {property.ParameterUpper}";
                parameterProperty += " {get; set;}\n";
            }

            queryFile = queryFile.Replace("PassedParameter", parameterProperty);
            queryFile = queryFile.Replace("DtoNamespace", $"using {CodeNamespace}.Application.Dto;");

            var queryPath = ProjectPath + "\\Application\\Queries\\";
            Directory.CreateDirectory($"{queryPath}{methodSignature.MethodName}");
            File.WriteAllText($"{queryPath}{methodSignature.MethodName}/{methodSignature.MethodName}Query.cs", queryFile);

            // query handler                    
            var queryHandlerFile = (string)QueryHandlerText.Clone();
            queryHandlerFile = queryHandlerFile.Replace("MyNamespace", CodeNamespace);
            queryHandlerFile = queryHandlerFile.Replace("MyQuery", $"{methodSignature.MethodName}Query");
            queryHandlerFile = queryHandlerFile.Replace("MyHandler", $"{methodSignature.MethodName}QueryHandler");

            queryHandlerFile = queryHandlerFile.Replace("MyDBService", $"{DBService}");
            queryHandlerFile = queryHandlerFile.Replace("DbServiceNamespace", $"using {CodeNamespace}.Persistence;");

            var methodParameters = "";
            int currentMethod = 1;

            foreach (var line in methodSignature.ParameterInfoList)
            {
                methodParameters += $"request.{line.ParameterUpper}";

                if (currentMethod < methodSignature.ParameterInfoList.Count())
                    methodParameters += ", ";
                currentMethod++;
            }
            if (methodSignature.ReturnValue != "Unit")
            {
                queryHandlerFile = queryHandlerFile.Replace("CODEBLOCK", $"var retval = await _dbService.{methodSignature.MethodName}({methodParameters});");
                queryHandlerFile = queryHandlerFile.Replace("RETURNVALUE", $"return _mapper.Map<{methodSignature.ReturnValue}>(retval);");
                queryHandlerFile = queryHandlerFile.Replace("MyType", $"{methodSignature.ReturnValue}");
            }
            else
            {
                queryHandlerFile = queryHandlerFile.Replace("CODEBLOCK", $"await _dbService.{methodSignature.MethodName}({methodParameters});");
                queryHandlerFile = queryHandlerFile.Replace("RETURNVALUE", "return new Unit();");
                queryHandlerFile = queryHandlerFile.Replace("MyType", $"{methodSignature.ReturnValue}");
            }
            queryHandlerFile = queryHandlerFile.Replace("DtoNamespace", $"using {CodeNamespace}.Application.Dto;");

            File.WriteAllText($"{queryPath}{methodSignature.MethodName}/{methodSignature.MethodName}QueryHandler.cs", queryHandlerFile);


        }

        private void ProcessControllerGet(MethodSignature methodSignature)
        {
            // controller get
            var controllerGet = (string)HttpGetText.Clone();

            var controllerParameterProperty = "";
            var parmProperty = "";
            var controllerSignature = $"{methodSignature.MethodName}";
            int currentMethod = 1;

            foreach (var property in methodSignature.ParameterInfoList)
            {
                controllerParameterProperty += $"{property.ParameterType} {property.ParameterLower}";
                parmProperty += $"{property.ParameterUpper} = {property.ParameterLower}";
                controllerSignature += "/{" + property.ParameterLower + "}";
                if (currentMethod < methodSignature.ParameterInfoList.Count())
                {
                    controllerParameterProperty += ", ";
                    parmProperty += ", ";
                }
                currentMethod++;
            }
            controllerGet = controllerGet.Replace("MethodName", $"{methodSignature.MethodName}");
            controllerGet = controllerGet.Replace("ControllerSignature", $"{controllerSignature}");
            controllerGet = controllerGet.Replace("CommandLine", $"{parmProperty}");
            controllerGet = controllerGet.Replace("CommandHandler", $"{methodSignature.MethodName}Command");
            controllerGet = controllerGet.Replace("CommandParam", $"{controllerParameterProperty}");
            controllerGet = controllerGet.Replace("QueryHandler", $"{methodSignature.MethodName}Query");

            File.AppendAllText($"{ProjectPath}\\Application\\Controllers\\Controller.cs", controllerGet);

        }

        private void ProcessCommand(MethodSignature methodSignature)
        {
            // command
            var commandFile = (string)CommandText.Clone();
            commandFile = commandFile.Replace("MyNamespace", CodeNamespace);
            commandFile = commandFile.Replace("MyCommandCommand", $"{methodSignature.MethodName}Command");
            commandFile = commandFile.Replace("MyType", $"{methodSignature.ReturnValue}");

            var parameterProperty = "";

            foreach (var property in methodSignature.ParameterInfoList)
            {
                parameterProperty += "public ";
                parameterProperty += $"{property.ParameterType} {property.ParameterUpper}";
                parameterProperty += " {get; set;}\n";
            }

            commandFile = commandFile.Replace("PassedParameter", $"{parameterProperty}");
            commandFile = commandFile.Replace("DtoNamespace", $"using {CodeNamespace}.Application.Dto;");

            var commandPath = ProjectPath + "\\Application\\Commands\\";
            Directory.CreateDirectory($"{commandPath}{methodSignature.MethodName}");
            File.WriteAllText($"{commandPath}{methodSignature.MethodName}/{methodSignature.MethodName}Command.cs", commandFile);

            // command handler                    
            var commandHandlerFile = (string)CommandHandlerText.Clone();
            commandHandlerFile = commandHandlerFile.Replace("MyNamespace", CodeNamespace);
            commandHandlerFile = commandHandlerFile.Replace("MyCommandHandler", $"{methodSignature.MethodName}CommandHandler");
            commandHandlerFile = commandHandlerFile.Replace("MyHandler", $"{methodSignature.MethodName}Command");
            commandHandlerFile = commandHandlerFile.Replace("MyDBService", $"{DBService}");
            commandHandlerFile = commandHandlerFile.Replace("DbServiceNamespace", $"using {CodeNamespace}.Persistence;");

            if (methodSignature.ReturnValue != "Unit")
            {
                commandHandlerFile = commandHandlerFile.Replace("CODEBLOCK", $"var retval = await _dbService.{methodSignature.MethodName}(request.{methodSignature.ParameterInfoList[0].ParameterUpper});");
                commandHandlerFile = commandHandlerFile.Replace("RETURNVALUE", $"return _mapper.Map<{methodSignature.ReturnValue}Dto>(retval);");
                commandHandlerFile = commandHandlerFile.Replace("MyType", $"{methodSignature.ReturnValue}Dto");
            }
            else
            {
                commandHandlerFile = commandHandlerFile.Replace("CODEBLOCK", $"await _dbService.{methodSignature.MethodName}(request.{methodSignature.ParameterInfoList[0].ParameterUpper});");
                commandHandlerFile = commandHandlerFile.Replace("RETURNVALUE", $"return new Unit();");
                commandHandlerFile = commandHandlerFile.Replace("MyType", $"{methodSignature.ReturnValue}");
            }

            commandHandlerFile = commandHandlerFile.Replace("DtoNamespace", $"using {CodeNamespace}.Application.Dto;");

            File.WriteAllText($"{commandPath}{methodSignature.MethodName}/{methodSignature.MethodName}CommnadHandler.cs", commandHandlerFile);


        }

        private void ProcessControllerPost(MethodSignature methodSignature)
        {
            // controller post
            var currentMethod = 1;
            var commandLine = "";
            foreach (var property in methodSignature.ParameterInfoList)
            {
                commandLine += $"{property.ParameterUpper} = {property.ParameterLower}";

                if (currentMethod < methodSignature.ParameterInfoList.Count())
                {
                    commandLine += ", ";
                }
                currentMethod++;
            }
            var controllerPost = (string)HttpPostText.Clone();
            controllerPost = controllerPost.Replace("MethodName", $"{methodSignature.MethodName}");
            controllerPost = controllerPost.Replace("CommandLine", $"{commandLine}");
            controllerPost = controllerPost.Replace("methodSignature", $"{methodSignature.Parms}");

            controllerPost = controllerPost.Replace("CommandHandler", $"{methodSignature.MethodName}Command");
            controllerPost = controllerPost.Replace("CommandParam", $"{methodSignature.ParameterInfoList[0].ParameterUpper}");

            File.AppendAllText($"{ProjectPath}\\Application\\Controllers\\Controller.cs", controllerPost);
        }
    }

}
