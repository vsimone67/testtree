import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadCrumbModel } from '../shared/components/breadcrumb/breadcrumb.model';
import { EventService } from '../shared/services/event.service';
import { events } from "src/assets/constants/events.model";

@Component({
  selector: 'main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.css']
})
export class MainMenuComponent implements OnInit {
public items: MenuItem[];
  constructor(private eventService: EventService) { }

  ngOnInit(): void {
    this.items =[
      {
        label: "SQP",
        url: "#/sqp/page1",
        command: (event) => {
          this.eventService.sendEvent(events.breadcrumbEvent, <BreadCrumbModel> { url: "#/sqp/page1", label: "SQP"});
        }

      },
      {
        label: "Template",
        url: "#/mfetemplate/page1",
        command: (event) => {
          this.eventService.sendEvent(events.breadcrumbEvent, <BreadCrumbModel> { url: "#/mfetemplate/page1", label: "Template"});
        }
      }

    ]
  }

}
