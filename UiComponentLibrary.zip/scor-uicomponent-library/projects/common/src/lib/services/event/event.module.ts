import { NgModule } from "@angular/core";
import { EventService } from "./event.service";

@NgModule({
  declarations: [],
  imports: [],
  exports: [],
  providers: [EventService],
})
export class EventModule {}
