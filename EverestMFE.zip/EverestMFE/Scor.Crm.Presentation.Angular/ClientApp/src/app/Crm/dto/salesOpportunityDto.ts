import { CodeDto } from './codeDto';
import { StrategyDto } from './strategyDto';

export interface SalesOpportunityDto {
    salesOpportunityId: string;
    salesOpportunityNote: string;
    salesOpportunityTypeId: string;
    strategyId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    salesOpportunityType: CodeDto;
    strategy: StrategyDto;
}