import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'admin-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  constructor(private router: Router) {}

  ngOnInit(): void {
    this.router.initialNavigation(); // Manually triggering initial navigation for @angular/elements

    // Standalone mode
    if (environment.standalone) {
      this.router.navigate(['/admin/codeAdmin']);
    }
  }
}
