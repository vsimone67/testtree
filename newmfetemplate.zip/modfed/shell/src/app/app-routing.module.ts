import { loadRemoteModule } from '@angular-architects/module-federation';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
      path: 'flights',
      loadChildren: () => import('mfe1/Module').then(m => m.FlightsModule)
      // loadChildren: () =>
      //   loadRemoteModule({
      //     // remoteEntry: 'http://localhost:3000/remoteEntry.js',
      //     remoteName: 'app1',
      //     exposedModule: './Module'
      //   })
      //   .then(m => m.AppModule)

    },
    {
      path: 'app1',
      //loadChildren: () => import('app1/Module').then(m => m.AppModule)
      loadChildren: () =>
        loadRemoteModule({
          remoteEntry: 'http://localhost:4600/remoteEntry.js',
          remoteName: 'app1',
          exposedModule: './Module'
        })
        .then(m => m.AppModule)

    }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
