export interface RetentionStackModel{
    RetentionStackId: string;
    ChildId: string| null;
    ParentId: string| null;    
    CancelDate: Date | string | null;    
    EffectiveDate: Date | string | null;
    FamilyId: string;
    IsIncreaseWithoutRecapture: boolean | null; 
    StackName: string;
    CreateDate: Date | string;
    CreatedBy: string| null;
    ModifiedBy: string| null;
    ModifiedDate: Date | string | null;
    ModuleReference: string| null;
    RowStatusId: string| null;
    StackDescription: string;
    AlternateRetentionSchedule: boolean;
    LineageId: number | null;
    IsRoot : number | null;
    PayorLegalEntityId: string| null;
}