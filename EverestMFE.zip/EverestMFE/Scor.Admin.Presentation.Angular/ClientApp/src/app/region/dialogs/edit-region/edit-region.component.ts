import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { RegionModel } from '../../models/region-model';
import { RegionService } from '../../services/region.service';

@Component({
  selector: 'app-edit-region',
  templateUrl: './edit-region.component.html',
  styleUrls: ['./edit-region.component.css'],
})
export class EditRegionComponent
  extends EditDialogBase<RegionModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() selectedData;
  selectedCompany;
  regionName;

  constructor(private regionService: RegionService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.regionName = this.selectedData.label;
  }

  async saveEditTeamMember() {
    await this.regionService.editRegion(
      this.selectedData.value,
      this.regionName
    );
    this.submitDialog();
    this.hideDialog();
  }
}
