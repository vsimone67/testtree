import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { RateModel } from '../../models/rate-model';
import { ExchangeRatesService } from '../../services/exchange-rates.service';

@Component({
  selector: 'app-delete-exchange-rate',
  templateUrl: './delete-exchange-rate.component.html',
  styleUrls: ['./delete-exchange-rate.component.css'],
})
export class DeleteExchangeRateComponent
  extends EditDialogBase<RateModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() currency;
  teamName: string;
  currencyName;

  constructor(private ratesService: ExchangeRatesService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.currencyName = this.currency.countryCode;
  }

  async confirm() {
    await this.ratesService.deleteExchangeRate(
      this.currency.exchangeCountryId,
      this.currency.startDate,
      '04D3195C-C00A-4D22-AB3A-4526E4C5BDC5'
    );
    this.submitDialog();
    this.hideDialog();
  }

  deny() {
    this.hideDialog();
  }
}
