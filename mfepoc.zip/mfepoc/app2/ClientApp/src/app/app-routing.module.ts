import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CoreComponent } from './core/core.component';
import { EmptyComponent } from './empty/empty.component';
import { HomeComponent } from './home/home.component';
import { Page2Component } from './page2/page2.component';

const routes: Routes = [
  {
    path: 'app2',
    component: CoreComponent,
    children: [{ path: 'home', component: HomeComponent }, {path: 'page2', component: Page2Component}
  ],
  },
  { path: '**', component: EmptyComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
