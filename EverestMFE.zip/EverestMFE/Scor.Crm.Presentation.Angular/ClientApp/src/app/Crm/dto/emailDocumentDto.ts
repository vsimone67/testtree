import { EmailDocumentEmailAddressDto } from './emailDocumentEmailAddressDto';

export interface EmailDocumentDto {
    emailDocumentId: string;
    documentId: string | null;
    emailAddressId: string;
    dateSent: string | null;
    filename: string;
    subject: string;
    isSent: boolean | null;
    isReceived: boolean | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    emailDocumentEmailAddress: EmailDocumentEmailAddressDto[];
}