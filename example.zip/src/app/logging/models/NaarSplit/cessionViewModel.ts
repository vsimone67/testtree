import { CessionHistoryViewModel } from "./cessionHistoryViewModel";

export interface CessionViewModel {
  cessionId: string;
  cessionNumber: number;
  cessionSequence: string;
  cedingCompany: string;
  legalEntity: string;
  isOverride: boolean;
  coverageNumber: string;
  uniquePlanNumber: string;
  policyNumber: string;
  overrideSCORRetentionAmount: number;
  scorRetentionSequenceNumber: number;
  reinsuranceType: string;
  jointEqualAge: number | null;
  overrideSCORRetentionScheduleName: string;
  overrideAllowRecapture: boolean;
  retroType: string;
  cessionHistories: CessionHistoryViewModel[];
}
