import { Injectable } from '@angular/core';
import { CessionHistoryAggregate } from '@assumed/models/CessionHistoryAggregate';
import { CessionHistoryModel } from '@assumed/models/CessionHistoryModel';
import { CessionOverrideAggregate } from '@assumed/models/cessionOverrideAggregate';
import { SiteConstants } from '@constants/siteConstants';
import { CessionUpdateInfoAggregate } from '@retro/models/CessionUpdateInfoAggregate';
import { RetroCessionOverrideModel } from '@retro/models/RetroCessionOverrideModel';
import { RetroRecaptureProgramOverrideModel } from '@retro/models/RetroRecaptureProgramOverrideModel';
import { RetroTransactionHistoryModel } from '@retro/models/RetroTransactionHistoryModel';
import { RetroTransactionHistoryUpdateModel } from '@retro/models/RetroTransactionHistoryUpdateModel';
import { AppSettingsService } from './app-settings.service';

import { HttpService } from './http-service.service';

@Injectable({
  providedIn: 'root'
})
export class RetroAggregatorService {

  private _aggregatorUrl: string;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    //this._aggregatorUrl = `${environment.apiGatewayUrl}/${SiteConstants.aggregatorController}`;
    this._aggregatorUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.retroAggregatroController}`;
  }

  async AddCessionHistory(cessionHistory: CessionHistoryModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateAddCessionHistory`, cessionHistory);
  }

  async EditCessionHistory(cessionHistory: CessionHistoryAggregate) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateEditCessionHistory`, cessionHistory);
  }

  async UpdateRetroTransactionHistory(retroTransactionHistory: RetroTransactionHistoryModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateUpdateRetroTransactionHistory`, retroTransactionHistory);
  }

  async SaveCessionOverride(cessionGeneral: CessionOverrideAggregate) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateCessionOverride`, cessionGeneral);
  }

  async updateRetroTransactionHistory(retroTxn: RetroTransactionHistoryUpdateModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateUpdateRetroTransactionHistory`, retroTxn);
  }

  async saveCessionInsuredInfo(cessionUpdateInfo: CessionUpdateInfoAggregate) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateCessionUpdateInfo`, cessionUpdateInfo);
  }

  async addRetroCessionOverride(cessionOverride: RetroCessionOverrideModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateAddRetroOverride`, cessionOverride);
  }
  async editRetroCessionOverride(cessionOverride: RetroCessionOverrideModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateEditRetroOverride`, cessionOverride);
  }

  async addRetroRecaptureOverride(retroRecaptureOverride: RetroRecaptureProgramOverrideModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateAddRetroRecaptureProgramOverride`, retroRecaptureOverride);
  }

  async editRetroRecaptureOverride(retroRecaptureOverride: RetroRecaptureProgramOverrideModel) {
    return await this._httpService.postData(`${this._aggregatorUrl}/AggregateEditRetroRecaptureProgramOverride`, retroRecaptureOverride);
  }

}
