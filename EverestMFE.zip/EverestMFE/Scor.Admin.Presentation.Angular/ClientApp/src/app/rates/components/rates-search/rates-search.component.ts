import { DatePipe } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CurrencyModel } from '../../models/currency-model';
import { ExchangeRatesService } from '../../services/exchange-rates.service';

@Component({
  selector: 'app-rates-search',
  templateUrl: './rates-search.component.html',
  styleUrls: ['./rates-search.component.css'],
})
export class RatesSearchComponent implements OnInit {
  formRuns;
  currencies: any[];
  @Output() searchData: EventEmitter<any> = new EventEmitter<any>();
  @Output() currencySelection: EventEmitter<any> = new EventEmitter<any>();
  paginator;
  teamId;
  loadingField: boolean = false;
  showDialog: boolean = false;
  newCurrency: CurrencyModel;
  allowAdd: boolean = false;
  showAll: boolean = false;
  selectedCurrency;

  constructor(
    private fb: FormBuilder,
    private pipe: DatePipe,
    private ratesService: ExchangeRatesService
  ) {
    this.formRuns = this.fb.group({
      currencyId: [null, Validators.required],
    });
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    const newTeams = await this.ratesService.getCurrencies();

    this.currencies = [];
    newTeams.forEach((line: CurrencyModel) => {
      if (line)
        this.currencies.push({
          label: line.codeName,
          value: line.codeId,
        });
    });
  }

  reset() {
    this.formRuns.reset();
    this.searchData.emit(null);
  }

  search() {
    this.loadingField = true;
    if (this.formRuns.valid) {
      this.searchData.emit(this.formRuns.value);
      this.allowAdd = true;
    }
    this.loadingField = false;
  }

  updateDrops(data) {
    this.allowAdd = !(data.value == null);

    for (var i = 0; i < this.currencies.length; ++i) {
      if (this.currencies[i].value == this.formRuns.value.currencyId) {
        this.selectedCurrency = this.currencies[i];
        this.currencySelection.emit(this.selectedCurrency);
      }
    }
  }

  addTeamMember() {
    this.showDialog = true;
    this.newCurrency = <CurrencyModel>{};
  }

  closeAddDialog() {
    this.showDialog = false;
  }

  saveSplit(data) {
    this.search();
  }
}
