﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace CommandQueryGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            string queryPath = @"C:\VS2019\Playground\GenCode\Queries\";
            string commandPath = @"C:\VS2019\Playground\GenCode\Commands\";
            string controllerPath = @"C:\VS2019\Playground\GenCode\Controller\";
            var sourceFileName = @"C:\VS2019\pdaaf\Scor.Pdaaf.Service\Persistence\DbService\IPdaafDatabaseService.cs";
            string codeNameSpace = "Scor.Pdaaf.Service";
            string dbService = "IPdaafDatabaseService";
            string dtoNamespace = "using Scor.Pdaaf.Service.Application.Dto;";
            string dbServiceNamespace = "using Scor.Pdaaf.Domain.Entities.Repository.Pdaaf;";

            string tsServiceName = "PdaafService";
            string controllerName = "PdaafController";
            string tsServicePath = @"C:\VS2019\Playground\GenCode\Service\";


            using (StreamReader sr = File.OpenText(sourceFileName))
            {
                var sourceCode = sr.ReadToEnd();

                var tree = CSharpSyntaxTree.ParseText(sourceCode);
                var root = (CompilationUnitSyntax)tree.GetRoot();

                // get all properties in class
                var methods = root.DescendantNodes().OfType<MethodDeclarationSyntax>().ToList();

                var query = File.OpenText("templates/myquery.txt").ReadToEnd();
                var queryHandler = File.OpenText("templates/myqueryhandler.txt").ReadToEnd();
                var command = File.OpenText("templates/mycommandcommand.txt").ReadToEnd();
                var commandHandler = File.OpenText("templates/mycommandcommandHandler.txt").ReadToEnd();
                var httpGet = File.OpenText("templates/httpget.txt").ReadToEnd();
                var httpPost = File.OpenText("templates/httppost.txt").ReadToEnd();
                var tsService = File.OpenText("templates/tsService.txt").ReadToEnd();
                var tsGet = File.OpenText("templates/tsGet.txt").ReadToEnd();
                var tsPost = File.OpenText("templates/tsPost.txt").ReadToEnd();

                Directory.CreateDirectory($"{controllerPath}");
                Directory.CreateDirectory($"{tsServicePath}");

                bool writeTsHeader = true;

                foreach (var method in methods)
                {
                    List<MethodSignature> methodSignature = new List<MethodSignature>();

                    var methodName = method.Identifier.ToString();
                    var parameterList = method.ParameterList.ToString();
                    var returnType = method.ReturnType.ToString();
                    var dtoType = "";
                    parameterList = parameterList.Replace("(", "");
                    parameterList = parameterList.Replace(")", "");
                    returnType = returnType.Replace("Task<", "");
                    returnType = returnType.Replace(">>", ">");

                    if (!returnType.Contains("List"))
                        returnType = returnType.Replace(">", "");

                    returnType = returnType.Replace("Task", "");

                    if (string.IsNullOrEmpty(returnType))
                    {
                        returnType = "Unit";
                        dtoType = "";
                    }
                    else
                    {
                        var className = returnType.Replace("List<", "");
                        className = className.Replace(">", "");
                        dtoType = className + "Dto";
                        returnType = returnType.Replace(className, dtoType);
                    }

                    var paramterNames = parameterList.Split(",");

                    var parameterLine = "";

                    foreach (var parameter in paramterNames)
                    {
                        var lines = parameter.TrimStart().Split(" ");

                        if (lines.Count() > 1)
                        {
                            parameterLine = lines[1].First().ToString().ToUpper() + lines[1].Substring(1);

                            var parameterInfo = new MethodSignature()
                            {
                                ReturnValue = returnType,
                                ParameterUpper = parameterLine,
                                ParameterLower = lines[1],
                                MethodName = methodName,
                                Dto = dtoType,
                                ParameterType = lines[0]
                            };
                            methodSignature.Add(parameterInfo);
                        }
                    }

                    if (writeTsHeader)
                    {

                        var tsServiceCode = (string)tsService.Clone();

                        tsServiceCode = tsServiceCode.Replace("ServiceName", $"{tsServiceName}");
                        tsServiceCode = tsServiceCode.Replace("ControllerName", $"{controllerName}");
                        File.WriteAllText($"{tsServicePath}/{tsServiceName}.ts", tsServiceCode);
                        writeTsHeader = false;
                    }

                    if (methodName.Substring(0, 3) == "Get")
                    {
                        // query
                        var queryFile = (string)query.Clone();
                        queryFile = queryFile.Replace("MyNamespace", codeNameSpace);
                        queryFile = queryFile.Replace("MyQuery", $"{methodName}Query");
                        queryFile = queryFile.Replace("MyType", $"{returnType}");
                        var parameterProperty = "";

                        foreach (var property in methodSignature)
                        {
                            parameterProperty += "public ";
                            parameterProperty += $"{property.ParameterType} {property.ParameterUpper}";
                            parameterProperty += " {get; set;}\n";
                        }

                        queryFile = queryFile.Replace("PassedParameter", parameterProperty);
                        queryFile = queryFile.Replace("DtoNamespace", $"{dtoNamespace}");

                        Directory.CreateDirectory($"{queryPath}{methodName}");
                        File.WriteAllText($"{queryPath}{methodName}/{methodName}Query.cs", queryFile);

                        // query handler                    
                        var queryHandlerFile = (string)queryHandler.Clone();
                        queryHandlerFile = queryHandlerFile.Replace("MyNamespace", codeNameSpace);
                        queryHandlerFile = queryHandlerFile.Replace("MyQuery", $"{methodName}Query");
                        queryHandlerFile = queryHandlerFile.Replace("MyHandler", $"{methodName}QueryHandler");

                        queryHandlerFile = queryHandlerFile.Replace("MyDBService", $"{dbService}");
                        queryHandlerFile = queryHandlerFile.Replace("DbServiceNamespace", $"{dbServiceNamespace}");

                        var methodParameters = "";
                        int currentMethod = 1;

                        foreach (var line in methodSignature)
                        {
                            methodParameters += $"request.{line.ParameterUpper}";

                            if (currentMethod < methodSignature.Count())
                                methodParameters += ", ";
                            currentMethod++;
                        }
                        if (returnType != "Unit")
                        {
                            queryHandlerFile = queryHandlerFile.Replace("CODEBLOCK", $"var retval = await _dbService.{methodName}({methodParameters});");
                            queryHandlerFile = queryHandlerFile.Replace("RETURNVALUE", $"return _mapper.Map<{returnType}>(retval);");
                            queryHandlerFile = queryHandlerFile.Replace("MyType", $"{returnType}");
                        }
                        else
                        {
                            queryHandlerFile = queryHandlerFile.Replace("CODEBLOCK", $"await _dbService.{methodName}({methodParameters});");
                            queryHandlerFile = queryHandlerFile.Replace("RETURNVALUE", "return new Unit();");
                            queryHandlerFile = queryHandlerFile.Replace("MyType", $"{returnType}");
                        }
                        queryHandlerFile = queryHandlerFile.Replace("DtoNamespace", $"{dtoNamespace}");

                        File.WriteAllText($"{queryPath}{methodName}/{methodName}QueryHandler.cs", queryHandlerFile);

                        // controller get
                        var controllerGet = (string)httpGet.Clone();

                        var controllerParameterProperty = "";
                        var parmProperty = "";
                        var controllerSignature = $"{methodName}";
                        currentMethod = 1;

                        foreach (var property in methodSignature)
                        {
                            controllerParameterProperty += $"{property.ReturnValue} {property.ParameterLower}";
                            parmProperty += $"{property.ParameterUpper} = {property.ParameterLower}";
                            controllerSignature += "/{" + property.ParameterLower + "}";
                            if (currentMethod < methodSignature.Count())
                            {
                                controllerParameterProperty += ", ";
                                parmProperty += ", ";
                            }
                            currentMethod++;
                        }
                        controllerGet = controllerGet.Replace("MethodName", $"{methodName}");
                        controllerGet = controllerGet.Replace("ControllerSignature", $"{controllerSignature}");
                        controllerGet = controllerGet.Replace("CommandLine", $"{parmProperty}");
                        controllerGet = controllerGet.Replace("CommandHandler", $"{methodName}Command");
                        controllerGet = controllerGet.Replace("CommandParam", $"{controllerParameterProperty}");
                        controllerGet = controllerGet.Replace("QueryHandler", $"{methodName}Query");

                        File.AppendAllText($"{controllerPath}/Controller.cs", controllerGet);

                        // tsService (get)                        
                        var tsGetCode = (string)tsGet.Clone();

                        currentMethod = 1;
                        var tsParameter = "";
                        controllerSignature = "";
                        foreach (var property in methodSignature)
                        {
                            tsParameter += $"{property.ParameterLower}";

                            controllerSignature += "/${" + property.ParameterLower + "}";
                            if (currentMethod < methodSignature.Count())
                            {
                                controllerParameterProperty += ", ";
                                parmProperty += ", ";
                            }
                            currentMethod++;
                        }

                        if (dtoType == "")
                            dtoType = "string";

                        dtoType = returnType.Replace("List<", "Array<");
                        dtoType = dtoType.Replace(">", "Dto>");

                        var apiRoute = methodName + controllerSignature;

                        tsGetCode = tsGetCode.Replace("MethodName", $"{methodName}");
                        tsGetCode = tsGetCode.Replace("Dto", $"{dtoType}");
                        tsGetCode = tsGetCode.Replace("ApiRoute", $"{apiRoute}");
                        tsGetCode = tsGetCode.Replace("Parameters", $"{tsParameter}");

                        File.AppendAllText($"{tsServicePath}/{tsServiceName}.ts", tsGetCode);
                    }


                    if (methodName.Substring(0, 3) == "Add" || methodName.Substring(0, 4) == "Edit" || methodName.Substring(0, 6) == "Delete")
                    {
                        // command
                        var commandFile = (string)command.Clone();
                        commandFile = commandFile.Replace("MyNamespace", codeNameSpace);
                        commandFile = commandFile.Replace("MyCommandCommand", $"{methodName}Command");
                        //if (returnType != "Unit")
                        //{
                        commandFile = commandFile.Replace("MyType", $"{returnType}");
                        //}
                        //else
                        //{
                        //commandFile = commandFile.Replace("MyType", $"{returnType}");
                        //}
                        var parameterProperty = "";

                        foreach (var property in methodSignature)
                        {
                            parameterProperty += "public ";
                            parameterProperty += $"{property.ParameterType} {property.ParameterUpper}";
                            parameterProperty += " {get; set;}\n";
                        }

                        commandFile = commandFile.Replace("PassedParameter", $"{parameterProperty}");
                        commandFile = commandFile.Replace("DtoNamespace", $"{dtoNamespace}");

                        Directory.CreateDirectory($"{commandPath}{methodName}");
                        File.WriteAllText($"{commandPath}{methodName}/{methodName}Command.cs", commandFile);

                        // command handler                    
                        var commandHandlerFile = (string)commandHandler.Clone();
                        commandHandlerFile = commandHandlerFile.Replace("MyNamespace", codeNameSpace);
                        commandHandlerFile = commandHandlerFile.Replace("MyCommandHandler", $"{methodName}CommandHandler");
                        commandHandlerFile = commandHandlerFile.Replace("MyHandler", $"{methodName}Command");
                        commandHandlerFile = commandHandlerFile.Replace("MyDBService", $"{dbService}");
                        commandHandlerFile = commandHandlerFile.Replace("DbServiceNamespace", $"{dbServiceNamespace}");

                        if (returnType != "Unit")
                        {
                            commandHandlerFile = commandHandlerFile.Replace("CODEBLOCK", $"var retval = await _dbService.{methodName}(request.{parameterLine});");
                            commandHandlerFile = commandHandlerFile.Replace("RETURNVALUE", $"return _mapper.Map<{returnType}Dto>(retval);");
                            commandHandlerFile = commandHandlerFile.Replace("MyType", $"{returnType}Dto");
                        }
                        else
                        {
                            commandHandlerFile = commandHandlerFile.Replace("CODEBLOCK", $"await _dbService.{methodName}(request.{parameterLine});");
                            commandHandlerFile = commandHandlerFile.Replace("RETURNVALUE", $"return new Unit();");
                            commandHandlerFile = commandHandlerFile.Replace("MyType", $"{returnType}");
                        }

                        commandHandlerFile = commandHandlerFile.Replace("DtoNamespace", $"{dtoNamespace}");

                        //Directory.CreateDirectory($"{commandPath}{name}");
                        File.WriteAllText($"{commandPath}{methodName}/{methodName}CommnadHandler.cs", commandHandlerFile);

                        // controller post
                        var currentMethod = 1;
                        var commandLine = "";
                        foreach (var property in methodSignature)
                        {
                            commandLine += $"{property.ParameterUpper} = {property.ParameterLower}";

                            if (currentMethod < methodSignature.Count())
                            {
                                commandLine += ", ";
                            }
                            currentMethod++;
                        }
                        var controllerPost = (string)httpPost.Clone();
                        controllerPost = controllerPost.Replace("MethodName", $"{methodName}");
                        controllerPost = controllerPost.Replace("CommandLine", $"{commandLine}");
                        controllerPost = controllerPost.Replace("methodSignature", $"{parameterList}");

                        controllerPost = controllerPost.Replace("CommandHandler", $"{methodName}Command");
                        controllerPost = controllerPost.Replace("CommandParam", $"{parameterLine}");

                        File.AppendAllText($"{controllerPath}/Controller.cs", controllerPost);

                        // tsService (post)

                        var tsPostCode = (string)tsPost.Clone();

                        tsPostCode = tsPostCode.Replace("MethodName", $"{methodName}");
                        tsPostCode = tsPostCode.Replace("DtoParameter", $"{dtoType}");
                        tsPostCode = tsPostCode.Replace("ApiRoute", $"{methodName}");

                        File.AppendAllText($"{tsServicePath}/{tsServiceName}.ts", tsPostCode);

                    }

                }
                File.AppendAllText($"{tsServicePath}/{tsServiceName}.ts", "}\n");


            }

            Console.WriteLine("Completed...");


        }
    }

    public class MethodSignature
    {
        public string MethodName { get; set; }
        public string ReturnValue { get; set; }
        public string ParameterUpper { get; set; }
        public string ParameterLower { get; set; }
        public string ParameterType { get; set; }
        public string Dto { get; set; }

    }
}
