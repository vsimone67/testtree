import { RetentionLimitViewModel } from "./retentionLimitViewModel";
import { PoolViewModel } from "./poolViewModel";
import { StackViewModel } from "./stackViewModel";
import { SplitsViewModel } from "./splitsViewModel";
import { PriorsPostsViewModel } from "./priorsPostsViewModel";
import { VerboseItem } from "./verboseItem";

export interface CessionHistoryViewModel {
  cessionId: string;
  cessionHistoryId: string;
  effectiveDate: Date;
  cancelDate: string;
  overrideRetroPoolName: string;
  overrideRetentionStackName: string;
  retentionLimit: RetentionLimitViewModel;
  pool: PoolViewModel;
  stack: StackViewModel;
  splits: SplitsViewModel;
  priorsPosts: PriorsPostsViewModel;
  verboseItems: Array<VerboseItem>;
}
