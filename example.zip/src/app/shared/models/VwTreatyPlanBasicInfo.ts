export interface VwTreatyPlanBasicInfo
{
    ResponsibleCompanyName: string;
    CompanyId: string;
    InsurancePlanShortName: string;
    InsurancePlanLongName: string;
    ResponsibleCompanyId: string;
    TreatyPlanCoverageEffectiveDate: Date | string;
    TreatyPlanTerminatedDate: Date | string | null;
    TreatyPlanTerminatedForNewBusinessDate: Date | string | null;
    ResponsibleTransferTypeId: string | null;
    ResponsibleTransferTypeIdCodeName: string;
    QuotePlanPlanName: string;
    TreatyPlanRowStatusIdCodeName: string;
    TreatyPlanTreatyId: string;
    QuotePlanId: string;
    ProposalId: string;
    PricingInsurancePlanId: string;
    BandName: string;
    MinBandValue: number | null;
    MaxBandValue: number | null;
    TreatyPlanId: string;
}
