export enum NodeConstants {
  split = "Split",
  history = "History",
  transaction = "Transaction",
  retro = "Retro",
  stack = "Stack",
  pool = "Pool",
  override = "Override",
  claim = "Claim",
  cession = "Cession"

}
