import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneralCompanyComponent } from './general-company.component';

describe('GeneralCompanyComponent', () => {
  let component: GeneralCompanyComponent;
  let fixture: ComponentFixture<GeneralCompanyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeneralCompanyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneralCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
