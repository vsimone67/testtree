import { EmployeeDto } from './employeeDto';
import { TeamAssignmentGroupDto } from './teamAssignmentGroupDto';

export interface TeamAssignmentGroupMemberDto {
    groupId: string;
    employeeId: string;
    roleTypeId: string;
    note: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    employee: EmployeeDto;
    group: TeamAssignmentGroupDto;
}