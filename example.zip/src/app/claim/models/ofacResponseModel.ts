export interface OfacResponseModel {
  ofacResponseId: string;
  attusEntityIdentifier: string;
  attusEntityNumber: string;
  entityMaxScore: number | null;
  entityTypeId: string;
  firstName: string;
  isAliasHit: boolean | null;
  lastName: string;
  ofacRequestId: string;
  ofacTextRemarks: string;
  ofacTextPrograms: string;
  otherName: string;
  responseDate: Date | string | null;
  responseType: string | null;
  score: number | null;
  wholeName: string;
  createDate: Date | string;
  createdBy: string;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;
}
