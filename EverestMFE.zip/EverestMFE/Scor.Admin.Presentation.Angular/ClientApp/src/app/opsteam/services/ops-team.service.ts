import { Injectable } from '@angular/core';
import { HttpService, AppSettingsService } from '@scor/common';
import { AssignedContactModel } from '../models/assigned-contact.model';
import { OperationalTeamModel } from '../models/operational-team.model';
import { TeamMemberModel } from '../models/team-member.model';

@Injectable({
  providedIn: 'root',
})
export class OpsteamService {
  baseApiUrl: string;
  teamUrl: string;
  membersUrl: string;
  addableUrl: string;
  newTeamMemberUrl: string;
  assignedUrl: string;
  deleteUrl: string;
  editUrl: string;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this.baseApiUrl = `${this._appSettingsService.GetValue(
      'apiGatewayUrl'
    )}/opteams/`;
    this.teamUrl = this.baseApiUrl + `GetListOfTeams`;
    this.membersUrl = this.baseApiUrl + `GetTeamsMembers?teamId=`;
    this.addableUrl = this.baseApiUrl + `GetAddableMembers?companyId=`;
    this.newTeamMemberUrl = this.baseApiUrl + `AddTeamMember`;
    this.assignedUrl = this.baseApiUrl + `GetAssignedContacts?companyId=`;
    this.deleteUrl = this.baseApiUrl + `DeleteTeamMember`;
    this.editUrl = this.baseApiUrl + `EditTeamMember`;
  }

  async getOperationalTeams() {
    return await this._httpService.getData<OperationalTeamModel[]>(
      `${this.teamUrl}`
    );
  }

  async getTeamMembers(teamMemberId: string) {
    return await this._httpService.getData<TeamMemberModel[]>(
      `${this.membersUrl}${teamMemberId}`
    );
  }

  async getAddableMembers(teamMemberId: string, showAll: boolean) {
    return await this._httpService.getData<TeamMemberModel[]>(
      `${this.addableUrl}${teamMemberId}&showAll=${showAll}`
    );
  }

  async getContacts(companyId: string) {
    return await this._httpService.getData<AssignedContactModel[]>(
      `${this.assignedUrl}${companyId}`
    );
  }

  async postNewTeamMember(
    teamMemberId: string,
    companyId: string,
    createdBy: string
  ) {
    const body = {
      OperationalTeamId: teamMemberId,
      CompanyId: companyId,
      CreatedBy: createdBy,
    };

    return await this._httpService.postData(this.newTeamMemberUrl, body);
  }

  async editTeamMember(
    companyOperationalTeamRelId: string,
    operationalTeamId: string,
    companyId: string,
    createdBy: string
  ) {
    const body = {
      CompanyOperationalTeamRelId: companyOperationalTeamRelId,
      TeamMemberId: operationalTeamId,
      CompanyId: companyId,
      CreatedBy: createdBy,
    };

    return await this._httpService.putData(this.editUrl, body);
  }

  async deleteTeamMember(teamMemberId: string) {
    const body = { TeamMemberId: teamMemberId };

    return await this._httpService.postData(this.deleteUrl, body);
  }
}
