import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { TeamMemberModel } from '../../models/team-member.model';
import { OpsteamService } from '../../services/ops-team.service';

@Component({
  selector: 'app-edit-team-member',
  templateUrl: './edit-team-member.component.html',
  styleUrls: ['./edit-team-member.component.css'],
})
export class EditTeamMemberComponent
  extends EditDialogBase<TeamMemberModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() team;
  @Input() showAll: boolean;
  selectedCompany;

  constructor(private opsTeamService: OpsteamService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    const newList = await this.opsTeamService.getAddableMembers(
      this.team.operationalTeamId,
      false
    );

    this.companyList = [];
    newList.forEach((line: TeamMemberModel) => {
      if (line)
        this.companyList.push({
          label: line.companyName,
          value: line.companyId,
        });
    });
  }

  async saveEditTeamMember() {
    await this.opsTeamService.editTeamMember(
      this.team.companyOperationalTeamRelId,
      this.team.operationalTeamId,
      this.selectedCompany,
      '00000000-0000-0000-0000-000000000000'
    );
    //this.showDialog = false;
    this.submitDialog();
    this.hideDialog();
  }
}
