import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SiteConstants } from "@constants/siteConstants";
import { LifeViewComponent } from "@assumed/components/life-view/life-view.component";
import { CessionSearchComponent } from "./components/cession-search/cession-search.component";
import { CessionEditComponent } from "@assumed/components/cession-edit/cession-edit.component";
import { UserAuthGuard } from "@auth/services/user-auth-guard";
import { AdminAuthGuard } from "@auth/services/admin-auth-guard";

const routes: Routes = [
  {
    path: "",
    component: CessionSearchComponent,
    data: {},
    pathMatch: "full",
    canActivate: [UserAuthGuard],
  },
  {
    path: `${SiteConstants.cessionAnalysisRoute}/:id`,
    data: {
      breadcrumb: "Cession Analysis",
    },
    component: LifeViewComponent,
    pathMatch: "full",
    canActivate: [UserAuthGuard],
  },
  {
    path: `${SiteConstants.editCessionRoute}/:id`,
    data: {
      breadcrumb: "Edit Cession Information",
    },
    component: CessionEditComponent,
    pathMatch: "full",
    canActivate: [AdminAuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssumedRoutingModule {}
