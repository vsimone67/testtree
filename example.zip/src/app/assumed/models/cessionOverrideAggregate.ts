import { CessionGeneralModel } from "./cessionGeneralModel";

export interface CessionOverrideAggregate {
  CurrentValue: CessionGeneralModel;
  NewValue: CessionGeneralModel;
}
