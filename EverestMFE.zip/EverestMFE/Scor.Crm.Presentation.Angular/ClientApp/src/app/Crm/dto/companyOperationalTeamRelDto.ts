import { CompanyDto } from './companyDto';
import { CodeDto } from './codeDto';

export interface CompanyOperationalTeamRelDto {
    companyOperationalTeamRelId: string;
    companyId: string;
    operationalTeamId: string;
    createDate: string;
    createdBy: string;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    operationalTeam: CodeDto;
}