import { NgModule } from '@angular/core';
import { ButtonCellComponent } from './button-cell/button-cell.component';
import { ImageButtonCellComponent } from './image-button-cell/image-button-cell.component';
import { LinkCellComponent } from './link-cell/link-cell.component';
import { GenericGridComponent } from './generic-grid/generic-grid.component';
import { AgGridModule } from 'ag-grid-angular';
import { BrowserModule } from '@angular/platform-browser';
import { PaginatorModule } from 'primeng/paginator';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PagedGridComponent } from './paged-grid/paged-grid.component';

@NgModule({
  declarations: [
    PagedGridComponent,
    ButtonCellComponent,
    ImageButtonCellComponent,
    LinkCellComponent,
    GenericGridComponent,
  ],
  imports: [
    BrowserModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
      LinkCellComponent,
    ]),
    PaginatorModule,
    BrowserAnimationsModule,
  ],
  exports: [
    PagedGridComponent,
    ButtonCellComponent,
    ImageButtonCellComponent,
    LinkCellComponent,
    GenericGridComponent,
    PaginatorModule,
    BrowserAnimationsModule,
  ],
})
export class GridModule {}
