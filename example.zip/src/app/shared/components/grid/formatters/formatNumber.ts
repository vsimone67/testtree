export function formatNumber(data) {
  var number = data.value;
  // this puts commas into the number eg 1000 goes to 1,000,
  return Math.round(Math.floor(number))
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}
export function formatNumberCent(data) {
  var number = data.value;
  // this puts commas into the number eg 1000 goes to 1,000,
   return (Math.round(number*100)/100).toFixed(2)
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}
export function formatNumberSplits(data) {
  var number = data.value;
  // this puts commas into the number eg 1000 goes to 1,000,
  return Math.round(Math.floor(number))
    .toString()
    .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
}
