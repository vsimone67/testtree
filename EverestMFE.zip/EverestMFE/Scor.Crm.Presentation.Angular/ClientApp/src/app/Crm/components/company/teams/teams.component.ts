import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {UserRelationshipDto} from "../../../dto/userRelationshipDto";
import {CompanyDto} from "../../../dto/companyDto";
import {SiteConstants} from "@constants/siteConstants";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.css']
})
export class TeamsComponent implements OnInit, OnChanges {
  @Input() company: CompanyDto
  @Input() team
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;
  isedit: boolean = false;
  selectedTeam: UserRelationshipDto;
  showDialog: boolean;

  constructor(private crmService: CrmService,private confirm:ConfirmationService,
              private _messageService:MessageService) {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.team && this.gridOptions) {
      this.gridOptions.api.refreshCells({force: true})
    }
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 200px;";
    this.columnDefs = this.createColumns();
    if (this.gridOptions) this.gridOptions.api.refreshCells({force: true})

  }

  EditTeam(data) {

    this.isedit = true;
    this.selectedTeam = data.rowData;
    this.showDialog = true
  }

  deleteTeam(data) {
    this.confirm.confirm({
      message: "Do you want to delete this Team ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        //TODO check the ID
        let id=data.rowData
        this.crmService.DeleteCompanyTeamMember(id).then(liste=>{
          this.refreshData.emit()
          this._messageService.add({severity: "success", detail: "Team Has been Deleted"});
        })
      },
      reject: () => {},
    });
  }

  addTeam() {
    this.isedit = false;
    this.selectedTeam = <UserRelationshipDto>{};
    this.showDialog = true
  }

  submitDialog(data: UserRelationshipDto) {
    if (!this.isedit) {
      data.companyId = this.company.companyId;
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      data.createdBy = user.userId;
      this.crmService.AddCompanyTeamMember(data).then(l => this.refreshData.emit())
    }else {
      this.crmService.EditCompanyTeamMember(data).then(l => this.refreshData.emit())

    }

  }

  hideDialog() {
    this.showDialog = false;
  }

  private createColumns() {
    return <ColDef[]>[

      {
        field: "employee.fullName",
        headerName: "Name",

      },
      {
        field: "employee.jobTitle",
        headerName: "Role",

      }, {
        field: "extnumber",
        headerName: "EXT",
        width: 80
      },

      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.EditTeam.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteTeam.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }
}
