import { Component, OnInit } from '@angular/core';
import { RetroRecaptureProgramOverrideModel } from '@retro/models/RetroRecaptureProgramOverrideModel';
import { EditDialogBase } from '../EditDialogBase';

@Component({
  selector: 'retro-capture-program-override-dialog',
  templateUrl: './retro-capture-program-override-dialog.component.html',
  styleUrls: ['./retro-capture-program-override-dialog.component.css']
})
export class RetroCaptureProgramOverrideDialogComponent extends EditDialogBase<RetroRecaptureProgramOverrideModel> implements OnInit {

  constructor() { super(); }

  ngOnInit(): void {

  }

  cancelDialog() {
    this.showDialog = false;
    this.hideDialog();
  }
}
