export interface TreatyPlanModel {
  treatyPlanId: string;
  isConverted: boolean | null;
  proposalQuoteBandShareId: string | null;
  responsibleCompanyId: string;
  responsibleTransferTypeId: string | null;
  retroProposalShareId: string | null;
  treatyId: string;
  treatyPlanCoverageEffectiveDate: Date | string;
  treatyPlanTerminatedDate: Date | string | null;
  treatyPlanTerminatedForNewBusinessDate: Date | string | null;
  createDate: Date | string;
  createdBy: string | null;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;

}
