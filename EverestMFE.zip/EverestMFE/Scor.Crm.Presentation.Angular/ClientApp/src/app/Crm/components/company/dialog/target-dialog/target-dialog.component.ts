import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CompanyTargetDto} from "../../../../dto/companyTargetDto";

@Component({
  selector: 'target-dialog',
  templateUrl: './target-dialog.component.html',
  styleUrls: ['./target-dialog.component.css']
})
export class TargetDialogComponent implements OnInit {
  @Input() target: CompanyTargetDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;

  years;

  constructor() {
  }

  ngOnInit(): void {
    this.years = []
    for (let i = 2005; i < new Date().getFullYear(); i++) {
      this.years.push({
        label: i.toString(),
        value: i,
      })
    }
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    this.onSubmitDialog.emit(this.target);
    this.onDialogHide.emit()
  }
}
