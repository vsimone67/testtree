import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagedTreetableComponent } from './paged-treetable.component';

describe('PagedTreetableComponent', () => {
  let component: PagedTreetableComponent;
  let fixture: ComponentFixture<PagedTreetableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagedTreetableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagedTreetableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
