import { Component, OnInit, Input } from '@angular/core';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';
import { CessionHistoryViewModel } from 'src/app/logging/models/NaarSplit/cessionHistoryViewModel';

@Component({
  selector: 'cession-history-dialog',
  templateUrl: './cession-history-dialog.component.html',
  styleUrls: ['./cession-history-dialog.component.css']
})
export class CessionHistoryDialogComponent extends DialogBase implements OnInit {

  @Input() historyViewModel: CessionHistoryViewModel
  constructor() { super() }

  ngOnInit(): void {
  }

}
