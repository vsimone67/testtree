import { TeamAssignmentGroupMemberDto } from './teamAssignmentGroupMemberDto';

export interface TeamAssignmentGroupDto {
    groupId: string;
    groupDescription: string;
    groupName: string;
    groupSubTypeId: string | null;
    groupTypeId: string;
    parentId: string | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    teamAssignmentGroupMember: TeamAssignmentGroupMemberDto[];
}