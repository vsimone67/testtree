import { CompanyDto } from './companyDto';
import { ContactDto } from './contactDto';

export interface CompanyContactDto {
    contactId: string;
    companyId: string;
    contactRoleTypeId: string;
    companyContactDescription: string;
    decisionLevelTypeId: string | null;
    isPrimary: boolean | null;
    relationshipStrengthTypeId: string | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    contact: ContactDto;
}