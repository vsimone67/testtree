export interface OperationalTeamModel {
    codeId: string;
    codeName: string;
}