import { NgModule } from '@angular/core';
import { ImageButtonCellComponent } from '../grid/image-button-cell/image-button-cell.component';
import { LinkCellComponent } from '../grid/link-cell/link-cell.component';
import { ButtonCellComponent } from '../grid/button-cell/button-cell.component';
import { AgGridModule } from 'ag-grid-angular';
import { NotesListComponent } from './notes-list/notes-list.component';
import { GridModule } from '../grid/grid.module';

@NgModule({
  declarations: [NotesListComponent],
  imports: [
    GridModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
      LinkCellComponent,
    ]),
  ],
  exports: [NotesListComponent],
})
export class NotesModule {}
