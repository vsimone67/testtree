import { ClaimModel } from './claimModel';
import { ClaimRequestReceiptModel } from './claimRequestReceiptModel';
import { ClaimBeneficiaryPersonModel } from './claimBeneficiaryPersonModel';
import { ClaimBeneficiaryEntityModel } from './claimBeneficiaryEntityModel';

export interface ClaimCompleteModel {
  claim: ClaimModel;
  claimRequestsReceipts: ClaimRequestReceiptModel[];
  claimBeneficiaryEntities: ClaimBeneficiaryEntityModel[];
  claimBeneficiaryPersons: ClaimBeneficiaryPersonModel[];
}
