import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { CountryModel } from '../../models/country-model';
import { RegionService } from '../../services/region.service';

@Component({
  selector: 'app-associate-country',
  templateUrl: './associate-country.component.html',
  styleUrls: ['./associate-country.component.css'],
})
export class AssociateCountryComponent
  extends EditDialogBase<CountryModel>
  implements OnInit
{
  countries: any[];
  @Input() selectedData;
  regionName;
  countryId;
  effectiveDate: Date;

  constructor(private regionService: RegionService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.regionName = this.selectedData.label;

    const newCountries = await this.regionService.getAssignableCountries(
      this.selectedData.value
    );

    this.countries = [];
    newCountries.forEach((line: CountryModel) => {
      if (line)
        this.countries.push({
          label: line.countryName,
          value: line.countryId,
        });
    });
  }

  updateDrops(data) {
    this.countryId = data.value;
  }

  async saveAddRegion() {
    await this.regionService.addCountryToRegion(
      this.selectedData.value,
      this.countryId
    );
    this.submitDialog();
    this.hideDialog();
  }
}
