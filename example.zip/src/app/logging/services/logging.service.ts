import { Injectable } from '@angular/core';
import { HttpService } from '@shared/services/http-service.service';
import { SiteConstants } from '@constants/siteConstants';
import { NaarSplitRootViewModel } from '../models/NaarSplit/naarSplitRootViewModel';
import { AppSettingsService } from '@shared/services/app-settings.service';

@Injectable({
  providedIn: 'root'
})
export class LoggingService {
  private _splitsUrl: string;

  constructor(
    private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    //this._splitsUrl = `${environment.apiGatewayUrl}/${SiteConstants.splitsController}`;
    this._splitsUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.splitsController}`;
  }

  async getNaarSplitsForView(cessionId: string, asOfDate: Date) {

    // chagne date format from / to - so we can call the api
    var dateString = `${asOfDate.getMonth()}-${asOfDate.getDate()}-${asOfDate.getFullYear()}`

    return await this._httpService.getData<NaarSplitRootViewModel>(
      `${this._splitsUrl}/GetNaarSplits/${cessionId}/${dateString}`
    );
  }
}
