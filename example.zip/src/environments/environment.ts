export const environment = {
  env: "prod",
  production: false,
};
