import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { TeamMemberModel } from '../../models/team-member.model';
import { OpsteamService } from '../../services/ops-team.service';

@Component({
  selector: 'app-delete-team-member',
  templateUrl: './delete-team-member.component.html',
  styleUrls: ['./delete-team-member.component.css'],
})
export class DeleteTeamMemberComponent
  extends EditDialogBase<TeamMemberModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() team;
  teamName: string;

  constructor(private opsTeamService: OpsteamService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.teamName = this.team.teamName;
  }

  async confirm() {
    await this.opsTeamService.deleteTeamMember(
      this.team.companyOperationalTeamRelId
    );
    this.submitDialog();
    this.hideDialog();
  }

  deny() {
    this.hideDialog();
  }
}
