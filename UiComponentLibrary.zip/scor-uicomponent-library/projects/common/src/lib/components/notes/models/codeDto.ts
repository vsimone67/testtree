export interface CodeDto {
    codeId: string;
    codeCategoryId: string;
    codeDescription: string;
    codeName: string;
    codeValue: string;
    isDefault: boolean;
    sequenceNumber: number;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
}