export class MicroFrontEnd {
  name: string;
  path: string;
  element: string;
  route: string;
}
