import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { SecurityRolesService } from 'src/app/roles/services/security-roles.service';
import { RoleModel } from '../../models/role-model';

@Component({
  selector: 'app-add-security-role',
  templateUrl: './add-security-role.component.html',
  styleUrls: ['./add-security-role.component.css'],
})
export class AddSecurityRoleComponent
  extends EditDialogBase<RoleModel>
  implements OnInit
{
  showDialog: boolean = true;
  @Input() currency;
  @Input() showAll: boolean;
  roleName;
  applicationId;
  loweredRoleName;
  description;

  constructor(private rolesService: SecurityRolesService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {}

  async saveAddTeamMember() {
    if (this.roleName != null) {
      this.loweredRoleName = this.roleName.toLowerCase();
    }

    await this.rolesService.addSecurityRole(
      this.roleName,
      '5FDCC982-6711-4EBC-92DF-D01F12474071',
      this.loweredRoleName,
      this.description
    );
    this.submitDialog();
    this.hideDialog();
  }
}
