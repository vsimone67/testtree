import {NgModule} from "@angular/core";
import {LifeViewComponent} from "./components/life-view/life-view.component";
import {SharedModule} from "@shared/shared.module";
import {AgGridModule} from "ag-grid-angular";
import {ButtonCellComponent, ImageButtonCellComponent,} from "@shared/components/grid";


import {RetroModule} from "../retro/retro.module";
import {PricingModule} from "../pricing/pricing.module";
import {FieldsetModule, InputNumberModule, InputTextareaModule, TooltipModule, TreeTableModule} from "primeng";
import {HistoryGridComponent} from './components/grids/history-grid/history-grid.component';
import {OverrideDialogComponent} from './components/dialogs/override-dialog/override-dialog.component';
import {TransactionGridComponent} from './components/grids/transaction-grid/transaction-grid.component';
import {QuoteDialogComponent} from './components/dialogs/quote-dialog/quote-dialog.component';
import {ProposalQuoteBandShareDialogComponent} from './components/dialogs/proposal-quote-band-share-dialog/proposal-quote-band-share-dialog.component';
import {QuotePlanBandComponent} from './components/dialogs/quote-plan-band-dialog/quote-plan-band-dialog.component';
import {PricingInsurancePlanComponent} from './components/dialogs/pricing-insurance-plan-dialog/pricing-insurance-plan-dialog.component';
import {InsurancePlanComponent} from './components/dialogs/insurance-plan-dialog/insurance-plan-dialog.component';
import {QuotePlanDialogComponent} from './components/dialogs/quote-plan-dialog/quote-plan-dialog.component';
import {ClaimModule} from '../claim/claim.module';
import {PersonGraphComponent} from './components/person-graph/person-graph.component';
import {CessionViewComponent} from './components/cession-view/cession-view.component';
import {CessionSearchComponent} from './components/cession-search/cession-search.component';
import {CessionEditComponent} from './components/cession-edit/cession-edit.component';
import {CessionOverrideComponent} from './components/cession-override/cession-override.component';
import {CessionRetrocessionComponent} from './components/cession-retrocession/cession-retrocession.component';
import {CessionNaarSplitsComponent} from './components/cession-naar-splits/cession-naar-splits.component';
import {CessionRetroTransactionComponent} from './components/cession-retro-transaction/cession-retro-transaction.component';
import {CessionUpdateComponent} from './components/cession-update/cession-update.component';
import {CessionHistoryComponent} from './components/cession-history/cession-history.component';
import {CessionPoolBindingOverridesComponent} from './components/cession-pool-binding-overrides/cession-pool-binding-overrides.component';
import {RetroCessionDetailDialogComponent} from './components/dialogs/retro-cession-detail-dialog/retro-cession-detail-dialog.component';
import {RetroCessionOverrideDialogComponent} from './components/dialogs/retro-cession-override-dialog/retro-cession-override-dialog.component';
import {RetroCaptureProgramOverrideDialogComponent} from './components/dialogs/retro-capture-program-override-dialog/retro-capture-program-override-dialog.component';
import {RetroTrxDialogComponent} from './components/dialogs/retro-trx-dialog/retro-trx-dialog.component';
import {CessionHistoryDialogComponent} from './components/dialogs/cession-history-dialog/cession-history-dialog.component';
import {NaarSplitDialogComponent} from './components/dialogs/naar-split-dialog/naar-split-dialog.component';

@NgModule({
  declarations: [
    LifeViewComponent,
    TransactionGridComponent,
    HistoryGridComponent,
    OverrideDialogComponent,
    PersonGraphComponent,
    QuoteDialogComponent,
    ProposalQuoteBandShareDialogComponent,
    QuotePlanBandComponent,
    PricingInsurancePlanComponent,
    InsurancePlanComponent,
    QuotePlanDialogComponent,
    CessionViewComponent,
    CessionSearchComponent,
    CessionEditComponent,
    CessionOverrideComponent,
    CessionRetrocessionComponent,
    CessionNaarSplitsComponent,
    CessionRetroTransactionComponent,
    CessionUpdateComponent,
    CessionHistoryComponent,
    CessionPoolBindingOverridesComponent,
    RetroCessionDetailDialogComponent,
    RetroCessionOverrideDialogComponent,
    RetroCaptureProgramOverrideDialogComponent,
    RetroTrxDialogComponent,
    CessionHistoryDialogComponent,
    NaarSplitDialogComponent
  ],
  imports: [
    SharedModule,
    RetroModule,
    PricingModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
    ]),
    TooltipModule,
    ClaimModule,
    FieldsetModule,
    TreeTableModule,
    InputTextareaModule,
    InputNumberModule
  ],
})
export class CessionModule {
}
