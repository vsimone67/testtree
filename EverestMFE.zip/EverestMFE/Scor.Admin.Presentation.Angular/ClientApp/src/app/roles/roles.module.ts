import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RolesContainerComponent } from './components/roles-container/roles-container.component';
import { SharedModule } from '@shared/shared.module';
import { RolesResultsComponent } from './components/roles-results/roles-results.component';
import { RolesSearchComponent } from './components/roles-search/roles-search.component';
import { AddMemberToRoleComponent } from './dialogs/add-member-to-role/add-member-to-role.component';
import { AddSecurityRoleComponent } from './dialogs/add-security-role/add-security-role.component';
import { EditSecurityRoleComponent } from './dialogs/edit-security-role/edit-security-role.component';
import { RemoveMemberComponent } from './dialogs/remove-member/remove-member.component';

@NgModule({
  declarations: [
    RolesContainerComponent,
    RolesResultsComponent,
    RolesSearchComponent,
    AddMemberToRoleComponent,
    AddSecurityRoleComponent,
    EditSecurityRoleComponent,
    RemoveMemberComponent,
  ],
  imports: [CommonModule, SharedModule],
})
export class RolesModule {}
