import { Component, Input, OnChanges, OnInit, SimpleChange } from '@angular/core';
import { GetNotesByParentAndGroupCriteria } from '@shared/models/GetNotesByParentAndGroupCriteria';
import { NoteModel } from '@shared/models/NoteModel';
import { CommonService } from '@shared/services/common.service';
import { ColDef } from 'ag-grid-community';
import { formatDate } from '../grid/formatters/formatDate';

@Component({
  selector: 'notes-list',
  templateUrl: './notes-list.component.html',
  styleUrls: ['./notes-list.component.css']
})
export class NotesListComponent implements OnInit, OnChanges {
  @Input() parentId: string;
  @Input() noteType: string;

  noteList: Array<NoteModel>;
  columnList: Array<ColDef>;

  constructor(private _commonService: CommonService) { }

  ngOnInit(): void {
    this.columnList = this.getColumns();
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {

    if (changes.parentId.currentValue != undefined) {
      this.getNotes();
    }

  }

  getNotes() {
    var criteria = <GetNotesByParentAndGroupCriteria>{ ParentId: this.parentId, NoteGroup: this.noteType };
        this._commonService.getNotes(criteria).then((data) => this.noteList = data);
  }

  getColumns() {
    return [
      {
        headerName: "Note",
        field: "noteText"
      },
      {
        headerName: "Note Date",
        field: "noteCreateDate",
        valueFormatter: formatDate

      },
      {
        headerName: "Created By",
        cellRenderer: (params) => `${params.data.noteCreatedByFirstName} ${params.data.noteCreatedByLastName}`

      }
    ];
  }

}
