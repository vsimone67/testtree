﻿import { CodeDto } from './codeModel';
import { EmployeeDto } from './employee.model';
import { MimeTypeDto } from './mimeType.model';

export interface DocumentDto {
  documentId: string;
  compressionTypeId: string | null;
  documentArchiveDate: Date | null;
  documentCategoryId: string;
  documentDescription: string;
  documentName: string;
  documentPassword: string;
  documentReceivedDate: Date;
  documentScanDate: Date | null;
  documentStatusId: string | null;
  documentUrl: string;
  encryptionFormatTypeId: string | null;
  fileName: string;
  isAdmin: boolean | null;
  isCompressed: boolean | null;
  isEncrypted: boolean | null;
  isPasswordProtected: boolean | null;
  mimesubTypeId: string | null;
  mimetypeId: string | null;
  receiveTypeId: string | null;
  sequenceNumber: number;
  sourceMediaTypeId: string | null;
  createDate: Date;
  createdBy: string | null;
  modifiedDate: Date | null;
  modifiedBy: string | null;
  moduleReference: string | null;
  rowStatusId: string | null;
  createdByNavigation: EmployeeDto;
  documentCategory: CodeDto;
  mimesubType: MimeTypeDto;
  mimetype: CodeDto;
  modifiedByNavigation: EmployeeDto;
}
