import { NgModule } from '@angular/core';
import { ClaimService } from './services/claim.service';
import { ClaimsDialogComponent } from './components/dialogs/claims-dialog/claims-dialog.component';
import { SharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { ButtonCellComponent, ImageButtonCellComponent } from '@shared/components/grid';


@NgModule({
  declarations: [ClaimsDialogComponent],
  imports: [
    SharedModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
    ]),
  ],
  exports: [ClaimsDialogComponent],
  providers: [ClaimService]
})
export class ClaimModule { }
