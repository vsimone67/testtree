import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { SecurityRolesService } from 'src/app/roles/services/security-roles.service';
import { filter } from 'rxjs/operators';
import { RolesResultsComponent } from '../roles-results/roles-results.component';

@Component({
  selector: 'app-roles-container',
  templateUrl: './roles-container.component.html',
  styleUrls: ['./roles-container.component.css'],
  providers: [DatePipe],
})
export class RolesContainerComponent implements OnInit {
  @ViewChild(RolesResultsComponent) table: RolesResultsComponent;
  page: any = {
    pageNumber: 1,
    pageSize: 10,
  };
  filters;
  rows;
  selectedRuns: any;
  loadingTable: boolean = false;
  selectedCurrency;

  constructor(private rolesService: SecurityRolesService) {}

  ngOnInit(): void {}

  async search(filters: any) {
    if (filters) {
      this.filters = filters;
    } else {
      this.table.updatetable({}, 0);
      return;
    }

    if (filters.roleId) {
      const users = await this.rolesService.getUsersInRole(filters.roleId);
      this.rows = users;

      this.table.updatetable(users, users.length);
    } else {
      this.table.updatetable({}, 0);
    }
  }

  async searchWithExistingFilters() {
    if (this.filters.currencyId) {
      const currencies = await this.rolesService.getUsersInRole(
        this.filters.roleId
      );
      this.rows = currencies;

      this.table.updatetable(currencies, currencies.length);
    } else {
      this.table.updatetable({}, 0);
    }
  }

  async selectUser(data: any) {}

  async changePage(page) {
    this.selectedRuns = null;
    this.page = page;

    const first = (page - 1) * page.pageSize;
    const last = page * page.pageSize;

    if (this.rows && this.rows.length > 0) {
      this.table.updatetable(this.rows.slice(first, last), page.pageSize);
    } else {
      this.getInitialData();
    }
  }

  async getInitialData() {
    this.loadingTable = false;
    this.rows = [];
    this.table.updatetable(this.rows, 0);
  }
}
