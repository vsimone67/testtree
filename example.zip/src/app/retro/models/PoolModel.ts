export interface PoolModel{
      RetroPoolId: string;
      PoolName: string;
      PoolStartDate: Date;
      PoolEndDate:Date;
      PoolType: string;
      IsEligibleForRecapture: boolean;
}