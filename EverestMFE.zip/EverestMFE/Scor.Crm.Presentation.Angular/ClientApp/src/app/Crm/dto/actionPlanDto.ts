import { StrategyDto } from './strategyDto';

export interface ActionPlanDto {
    actionPlanId: string;
    actionPlanDueDate: Date| string | null;
    actionPlanName: string;
    actionResult: string;
    strategyId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    strategy: StrategyDto;
}
