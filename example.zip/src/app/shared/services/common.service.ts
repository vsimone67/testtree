import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { SiteConstants } from "@constants/siteConstants";
import { NoteModel } from "@shared/models/NoteModel";
import { GetNotesByParentAndGroupCriteria } from "@shared/models/GetNotesByParentAndGroupCriteria";
import { CodeModel } from "@shared/models/CodeModel";
import { AppSettingsService } from "./app-settings.service";
import { ConfigurationSettingModel } from "@shared/models/ConfigurationSettingsModel";

@Injectable({
  providedIn: "root",
})
export class CommonService {
  private _commonUrl: string;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    //this._commonUrl = `${environment.apiGatewayUrl}/${SiteConstants.commonController}`;
    this._commonUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${
      SiteConstants.commonController
    }`;
  }

  async getNotes(criteria: GetNotesByParentAndGroupCriteria) {
    return await this._httpService.postData<Array<NoteModel>>(
      `${this._commonUrl}/GetNotesByParentAndGroup`,
      criteria
    );
  }

  async addNote(note: NoteModel) {
    return await this._httpService.postData(
      `${this._commonUrl}/CreateNote`,
      note
    );
  }

  async getRetroTransactionTypes() {
    return await this._httpService.getData<Array<CodeModel>>(
      `${this._commonUrl}/GetRetroTransactionTypes`
    );
  }

  async getNaarSplitTypes() {
    return await this._httpService.getData<Array<CodeModel>>(
      `${this._commonUrl}/GetNaarSplitTypes`
    );
  }

  async getConfiguationSettings(id: string) {
    return await this._httpService.getData<ConfigurationSettingModel>(
      `${this._commonUrl}/GetConfigurationSetting/${id}`
    );
  }
}
