export const environment = {
  production: true,
  env: "prod",
};
