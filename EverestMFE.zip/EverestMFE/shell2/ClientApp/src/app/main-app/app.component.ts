import { Component } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from '@scor/common';
import { ShellService } from '../shell/shell.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  date: number;
  version: string;
  environment: string;
  constructor(
    private appsettings: AppSettingsService,
    private shellService: ShellService
  ) {}

  ngOnInit() {
    // gather data for footer
    this.date = new Date().getFullYear();
    this.version = SiteConstants.version;
    this.environment = this.appsettings.GetValue('environment');

    this.shellService.init({
      initialRoute: '/home',
      outletId: 'content',
      preload: true,
      clients: {
        crm: {
          loaded: false,
          src: 'http://localhost:4600/main.js',
          element: 'crm-app',
          route: '/crm',
        },
        admin: {
          loaded: false,
          src: 'http://localhost:4601/main.js',
          element: 'admin-app',
          route: '/admin',
        },
      },
    });
  }
}
