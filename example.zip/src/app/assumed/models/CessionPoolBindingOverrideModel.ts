import {DropPair} from "@shared/models/dropPair";

export interface CessionPoolBindingOverrideModel {
  cessionPoolBindingOverrideId: string;
  cessionId: string;
  effectiveDate: Date | string;
  cancelDate: Date | string | null;
  retroPoolId: string;
  retroTreatyId: string;
  poolMemberCompanyId: string;
  narsplitTypeId: string;
  maxBindingAmount: number;
  comment: string;
  createDate: Date | string;
  createdBy: string | null;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;
  rowStatus: boolean | null;
  hasRollback:boolean;
  treatiesForapool?: Array<DropPair>
  companies ? : Array<DropPair>
}
