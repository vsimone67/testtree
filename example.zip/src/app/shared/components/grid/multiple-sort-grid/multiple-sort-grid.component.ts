import {Component, OnChanges, OnInit, SimpleChange} from '@angular/core';
import {GridBase} from "@shared/componentsgrid/GridBase";

@Component({
  selector: 'multiple-sort-grid',
  templateUrl: './multiple-sort-grid.component.html',
  styleUrls: ['./multiple-sort-grid.component.css']
})
export class MultipleSortGridComponent extends GridBase implements OnInit, OnChanges {
  sortingOrder = ['desc', 'asc', null];
  sortModel: {
    colId: string;
    sort: string;
  }[] = []
  lastSortModel: {
    colId: string;
    sort: string;
  }[] = [];

  constructor() {
    super();
  }

  ngOnInit(): void {
  }
  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component, call base class to do that
    super.ngOnChanges(changes);
  }
  callsorting(event) {
    let sort = this.currentGridOptons.api.getSortModel()
    // new Sort
    if (JSON.stringify(this.sortModel) !== JSON.stringify(sort)) {
      if ((!this.sortModel || this.sortModel.length === 0) && sort.length > 0) {
        this.sortModel.push(this.currentGridOptons.api.getSortModel()[0]);
        this.currentGridOptons.api.setSortModel(this.sortModel)

      } else if (this.sortModel && this.sortModel.length > 0 && sort && sort.length > 0) {
        //update sorting
        let currentsort = sort[0]
        let found = this.sortModel.filter(sortmo => sortmo.colId === currentsort.colId).length <= 0;
        if (found) {
          // new columns to be sorted
          this.sortModel.push(currentsort);
        } else {
          // update sorting value
          this.sortModel.forEach(sort => {
            if (sort.colId == currentsort.colId) sort.sort = currentsort.sort
          })
        }
        this.currentGridOptons.api.setSortModel(this.sortModel)

      } else if (this.sortModel && this.sortModel.length > 0 && sort.length === 0) {
        //delete sorting
        let colId = '';
        this.currentGridOptons.columnApi.getAllDisplayedColumns().forEach(col => {
          if (col.getSort() === null && !colId) {
            colId = col.getColId();
          }
        })
        this.sortModel = this.sortModel.filter(sort => sort.colId !== colId);
        this.currentGridOptons.api.setSortModel(this.sortModel)

      }
      this.lastSortModel = sort;
    }


  }
}
