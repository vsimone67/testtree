import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainCrmComponent } from './main-crm.component';

describe('MainCrmComponent', () => {
  let component: MainCrmComponent;
  let fixture: ComponentFixture<MainCrmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainCrmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainCrmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
