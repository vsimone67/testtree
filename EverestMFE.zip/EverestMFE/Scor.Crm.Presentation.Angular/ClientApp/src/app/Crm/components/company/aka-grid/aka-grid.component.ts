import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";
import {GeneraliAkaDto} from "../../../dto/generaliAkaDto";
import {CompanyDto} from "../../../dto/companyDto";
import {SiteConstants} from "@constants/siteConstants";

@Component({
  selector: 'aka-grid',
  templateUrl: './aka-grid.component.html',
  styleUrls: ['./aka-grid.component.css']
})
export class AkaGridComponent implements OnInit {
  @Input() akaList;
  @Input() company:CompanyDto;
  @Output() refreshData:EventEmitter<any> =new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;

  constructor(private crmService:CrmService, private _messageService:MessageService , private confirm:ConfirmationService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 350px;";
    this.columnDefs = this.createColumns();
  }

  createColumns() {
    return [
      {
        field: 'akaname',
        headerName: "AKA Name",
        width:300

      },
      {
        field: 'akanotes',
        headerName: "Notes",
        width:300
      },
      {
        field: "edit",
        headerName:"",
        cellRendererFramework: ImageButtonCellComponent,
        width:5,
        cellRendererParams: {
          onClick: this.onEditAKA.bind(this),
          icon: "pi-pencil",
        },
      },
      {
        field: "delete",
        headerName:"",
        cellRendererFramework: ImageButtonCellComponent,
        width:5,
        cellRendererParams: {
          onClick: this.onDeleteAKA.bind(this),
          icon: "pi-trash",
        },
      }
    ]
  }

  onEditAKA(data) {
    console.log(data)
    this.mode='edit';
    this.showDialog =true;
    this.selectedAKA=data.rowData
  }

  onDeleteAKA(data) {
    this.confirm.confirm({
      message: "Do you want to delete this AKA ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        this.crmService.DeleteAka(data.rowData.generaliAkaid).finally(()=>{
          this.refreshData.emit();
          this._messageService.add({severity: "success", detail: "Generali AKA Has been Deleted"});

        })
      },
      reject: () => {},
    });

  }
  showDialog:boolean=false;
  mode:string;
  selectedAKA:GeneraliAkaDto;
  addAKACompany(){
    this.mode='add';
    this.showDialog =true;
    this.selectedAKA=<GeneraliAkaDto>{}
  }

  submitDialog(Aka: GeneraliAkaDto) {
    if(this.mode == 'add'){
      Aka.companyId = this.company.companyId;
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      Aka.createdBy = user.userId;
      this.crmService.AddAka(Aka).then(aka=> this.refreshData.emit())
    }else {
      this.crmService.EditAka(Aka).then(aka=> this.refreshData.emit())

    }
  }

  hideDialog() {
    this.showDialog=false;
  }
}
