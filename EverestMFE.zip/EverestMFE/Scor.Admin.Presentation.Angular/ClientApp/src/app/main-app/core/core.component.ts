import { Component } from '@angular/core';

@Component({
  template: `
    <div id="admin">
      <p-toast></p-toast>
      <loading></loading>
      <router-outlet></router-outlet>
    </div>
  `,
  styles: [],
})
export class CoreComponent {}
