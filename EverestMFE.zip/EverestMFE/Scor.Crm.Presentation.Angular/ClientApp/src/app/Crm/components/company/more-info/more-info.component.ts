import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CompanyDto} from "../../../dto/companyDto";

@Component({
  selector: 'more-info',
  templateUrl: './more-info.component.html',
  styleUrls: ['./more-info.component.css']
})
export class MoreInfoComponent implements OnInit {
  @Input() company:CompanyDto;
  @Output() refreshCompany:EventEmitter<any>=new EventEmitter<any>()
  activeindex:number =0;

  constructor() { }

  ngOnInit(): void {
  }
  refreshData(){
    this.refreshCompany.emit()
  }

}
