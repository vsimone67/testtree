import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  NgZone,
} from '@angular/core';
import { Router } from '@angular/router';
import { ImageButtonCellComponent } from '@scor/common';
import { formatRowStatusToWord } from '@shared/grid/formatRowStatusToWord';
import { ColDef, GridOptions } from 'ag-grid-community';
import { CodeCategoryModel } from '../../models/CodeCategoryModel';
import { CodeModel } from '../../models/CodeModel';
import { CodeService } from '../../services/code.service';

@Component({
  selector: 'app-code-admin',
  templateUrl: './code-admin.component.html',
  styleUrls: ['./code-admin.component.css'],
})
export class CodeAdminComponent implements OnInit {
  @ViewChild('f') myForm: ElementRef;

  codeCategoryList: Array<CodeCategoryModel>;
  selectedCodeCategory: CodeCategoryModel;
  codeValueList: Array<CodeModel>;
  selectedCodeModel: CodeModel;
  GridCssStyle: string;
  columnDefs: Array<ColDef>;
  gridOption: GridOptions;
  showGrid: boolean;
  isUserAllowedToEdit: boolean;
  showDialog: boolean;
  rowToEdit: CodeModel;
  mode: string;
  categorySelected: boolean = false;
  codeCategoryId: string;

  constructor(
    private _codeService: CodeService,
    private router: Router,
    private zone: NgZone
  ) {
    this.clearForm();
    this.gridOption = {
      defaultColDef: {
        sortable: true,
        resizable: false,
      },
      pagination: true,
      paginationAutoPageSize: true,
    };
    this.gridOption.tooltipShowDelay = 500;
  }

  ngOnInit(): void {
    this.fillCodeCategories();
    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = 'width: 100%; height:550px;';
    this.showGrid = false;
    this.isUserAllowedToEdit = true;
    this.showDialog = false;

    // Grid Buttons
    if (this.isUserAllowedToEdit) {
      this.columnDefs.push({
        headerName: '',
        cellRendererFramework: ImageButtonCellComponent,
        cellRendererParams: {
          onClick: this.onNavigateToCodeEdit.bind(this),
          icon: 'pi-pencil',
        },
        width: 65,

        tooltipValueGetter: (params) => 'Edit',
      });
    }
  }

  async fillCodeCategories() {
    this.codeCategoryList = await this._codeService.getCodeCategories();
  }

  clearForm() {
    this.selectedCodeCategory = null;
    if (this.myForm != null) this.myForm['form'].pristine = true;
    this.showGrid = false;
  }
  createColumnDefs() {
    return [
      { headerName: 'Code', field: 'codeName' },
      { headerName: 'Value', field: 'codeValue' },
      { headerName: 'Description', field: 'codeDescription' },
      { headerName: 'Sequence', field: 'sequenceNumber' },
      { headerName: 'Is Default', field: 'isDefault' },
      {
        headerName: 'Row Status',
        field: 'rowStatusId',
        valueFormatter: formatRowStatusToWord,
      },
    ];
  }
  async LoadCodeValueGrid() {
    console.log('LoadCodeValueGrid');
    this.codeValueList = await this._codeService.getCodeValueByCategory(
      this.selectedCodeCategory.codeCategoryId
    );
    this.codeCategoryId = this.selectedCodeCategory.codeCategoryId;
    // this.newCodeModel.codeCategoryId = this.selectedCodeCategory.codeCategoryId;
    // this.newCodeModel.codeName = "New Entry";
    console.log(this.codeCategoryId);
    console.log(this.selectedCodeCategory.codeCategoryId);
    console.log(this.codeValueList.length);
    this.showGrid = true;
    this.categorySelected = true;
    console.log(this.categorySelected);
  }

  onNavigateToCodeEdit(data) {
    this.mode = 'Edit';
    console.log(data.rowData.codeId);
    this.rowToEdit = data.rowData;
    //this.rowToEdit.rowStatusId = (this.rowToEdit.rowStatusId.toLocaleUpperCase() === "0C84441F-9FFF-49ED-8E26-7BCE4259EC07")?true:false;
    this.showDialog = true;
    console.log('Dialog should popup');
    // this.zone.run(() =>
    // this._router.navigate([`${SiteConstants.editCode}/${data.rowData.CodeId}`]));
  }
  hideEditDialog() {
    console.log('hideEditDialog');
    this.showDialog = false;
    //this._codeService.updateCode(data);
  }
  // updateCodeModel(codeModel) {
  //   this.selectedCodeModel = codeModel.rowData;
  //   //this.selectedCodeModel.modifiedBy = this.currentUser.UserId;
  //   this.selectedCodeModel.modifiedDate = new Date().toString();
  // }

  saveCodeData(data) {
    console.log('saved Data');
    console.log(data);

    console.log(this.mode);

    data.rowStatusId = data.rowStatusId
      ? '0C84441F-9FFF-49ED-8E26-7BCE4259EC07'
      : '04D3195C-C00A-4D22-AB3A-4526E4C5BDC5';
    console.log(data.rowStatusId);
    console.log(data);
    if (this.mode === 'Edit') {
      data.modifiedDate = new Date();
      this._codeService.updateCode(data);
    } else if (this.mode === 'Add') {
      data.createDate = new Date();
      this._codeService.insertCode(data);
    }
    this.showDialog = false;
  }

  onAddCode(data) {
    this.mode = 'Add';
    const cc = <CodeModel>{};
    cc.codeCategoryId = this.codeCategoryId;
    cc.codeName = 'New Name';
    cc.rowStatusId = '0C84441F-9FFF-49ED-8E26-7BCE4259EC07';
    this.rowToEdit = cc;
    // let cc: CodeModel;
    // cc.codeCategoryId = this.codeCategoryId;
    this.showDialog = true;
  }
}
