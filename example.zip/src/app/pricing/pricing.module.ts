import { NgModule } from "@angular/core";
import { SharedModule } from "@shared/shared.module";
import { PricingService } from "./services/pricing.service";
import { StackGridComponent } from './components/grids/stack-grid/stack-grid.component';
import { PoolGridComponent } from './components/grids/pool-grid/pool-grid.component';
import {RetroModule} from "@retro/retro.module";

@NgModule({
  declarations: [StackGridComponent, PoolGridComponent],
  imports: [SharedModule],
  providers: [PricingService],
  exports: [StackGridComponent, PoolGridComponent],
})
export class PricingModule { }
