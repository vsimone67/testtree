import { NgModule } from "@angular/core";
import { AgGridModule } from "ag-grid-angular";
import { DocumentListComponent } from "../documents/document-list/document-list.component";
import { ButtonCellComponent } from "../grid/button-cell/button-cell.component";
import { GridModule } from "../grid/grid.module";
import { ImageButtonCellComponent } from "../grid/image-button-cell/image-button-cell.component";
import { LinkCellComponent } from "../grid/link-cell/link-cell.component";
import { DialogModule } from "primeng/dialog";
import { ConfirmDialogModule } from "primeng/confirmdialog";
import { DropdownModule } from "primeng/dropdown";
import { FormsModule } from "@angular/forms";
import { FileUploadModule } from "primeng/fileupload";
import { TooltipModule } from "primeng/tooltip";
import { CalendarModule } from "primeng/calendar";

@NgModule({
  declarations: [DocumentListComponent],
  imports: [
    FormsModule,
    GridModule,
    AgGridModule.withComponents([
      ButtonCellComponent,
      ImageButtonCellComponent,
      LinkCellComponent,
    ]),
    ConfirmDialogModule,
    DialogModule,
    DropdownModule,
    FileUploadModule,
    TooltipModule,
    CalendarModule,
  ],
  exports: [DocumentListComponent],
})
export class DocumentsModule {}
