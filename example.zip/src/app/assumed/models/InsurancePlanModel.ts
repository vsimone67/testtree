export interface InsurancePlanModel {
  InsurancePlanId: string;
  BaseRiderTypeId: string | null;
  ExpiryAge: number | null;
  ExpiryTypeId: string | null;
  GuaranteePeriod: number | null;
  InsurancePlanLongName: string;
  InsurancePlanShortName: string;
  InsurancePlanTypeId: string;
  IsExtendedMaturity: boolean | null;
  IsGeneralized: boolean;
  JointTypeId: string | null;
  MaturityAge: number | null;
  PlanDurationOrYears: number | null;
  CreateDate: Date | string | null;
  CreatedBy: string | null;
  ModifiedDate: Date | string | null;
  ModifiedBy: string | null;

}
