import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { User } from "@auth/models/user";
import { SiteConstants } from "@constants/siteConstants";
import { SplitModel } from "@retro/models/SplitModel";
import { SplitsService } from "@retro/services/splits.service";
import { MessageService } from "primeng";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { ColDef, GridOptions } from "ag-grid-community";
import { formatCurrency } from "@shared/components/grid/formatters/formatCurrency";
import { formatDate } from "@shared/components/grid/formatters/formatDate";
import { AppSettingsService } from "@shared/service/app-settings.service";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";

@Component({
  selector: "cession-naar-splits",
  templateUrl: "./cession-naar-splits.component.html",
  styleUrls: ["./cession-naar-splits.component.css"],
})
export class CessionNaarSplitsComponent implements OnInit {
  asofDate: Date;
  cessionId: string;
  splitToAdd: SplitModel;
  currentSplits: Array<SplitModel>;
  hasSplits: boolean;

  showDialog: boolean;
  isAdmin: boolean;

  columnDefs: Array<ColDef>;
  gridOptions: GridOptions;
  GridCssStyle: string;
  private _reportUrl: string;

  constructor(
    private _route: ActivatedRoute,
    private _appSettingsService: AppSettingsService,
    private _splitsService: SplitsService,
    private _messageService: MessageService
  ) {
    this.hasSplits = false;
    this.gridOptions = <GridOptions>{};
    this._reportUrl = `${this._appSettingsService.GetValue(
      SiteConstants.reportUrl
    )}`;
  }

  ngOnInit() {
    this.cessionId = this._route.snapshot.paramMap.get("id");
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.isAdmin = LifeLineRoleCheck.isCessionDetailWrite();
    this.columnDefs = this.createColumns();
    this.GridCssStyle = "width: 100%; height: 400px;";
    this._splitsService.getSplitsForCession(this.cessionId).then((splits) => {
      this.currentSplits = splits.filter(
        (exp) => exp.isActive && exp.productionCancelDate === null
      );

      if (this.currentSplits.length > 0) {
        this.hasSplits = true;
      }

      this.currentSplits.sort((a, b) => {
        // Sort by reinsurance duration descending
        // If the first item has a higher number, move it up
        // If the first item has a lower number, move it down
        if (a.splitCategory > b.splitCategory) return 1;
        if (b.splitCategory > a.splitCategory) return -1;

        // If the duration is the same between both items, sort by create date desc
        // If the first item has a higher date, move it up
        // If the first item has a lower date, move it down
        if (a.companyName > b.companyName) return 1;
        if (a.companyName < b.companyName) return -1;
      });
    });
  }

  addSplit() {
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.splitToAdd = <SplitModel>{};
    this.splitToAdd.cessionId = this.cessionId;
    this.splitToAdd.createdBy = currentUser.userId;
    this.splitToAdd.userName = currentUser.userName;

    this.showDialog = true;
  }

  closeSplitDialog() {
    this.showDialog = false;
  }

  saveSplit(split) {
    this.showDialog = false;
    this._splitsService.addNaarSplit(split).finally(() =>
      this._messageService.add({
        severity: "success",
        detail: "Split Has Been Saved",
      })
    );
  }

  generateSplits() {
    this._splitsService
      .generateNaarSplits(this.cessionId, this.asofDate)
      .finally(() =>
        this._messageService.add({
          severity: "success",
          detail: "Naar Splits Have Been Generated",
        })
      );
  }

  createColumns() {
    return [
      {
        headerName: "Company",
        field: "companyName",
      },
      {
        headerName: "NAAR Amount",
        field: "splitAmount",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Ceded Split Amount",
        field: "cededSplitAmount",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Effective",
        field: "effectiveDate",
        valueFormatter: formatDate,
      },
      {
        headerName: "Cancel",
        field: "cancelDate",
        valueFormatter: formatDate,
      },
      {
        headerName: "Pool",
        field: "retroPoolName",
      },
      {
        headerName: "Treaty",
        field: "retroTreatyNumber",
      },
      {
        headerName: "Category",
        field: "splitCategory",
      },
      {
        headerName: "Type",
        field: "splitType",
      },
      {
        headerName: "Block Location",
        field: "blockLocation",
      },
      {
        headerName: "Payor Legal Entity",
        field: "payorLegalEntityName",
      },
    ];
  }

  goToInfos() {
    let url = this._reportUrl
      .concat(
        "NarSplitHistoryReport&rs:Command=Render&rc:Parameters=false&CessionId="
      )
      .concat(this.cessionId);
    window.open(url, "_blank");
  }
  goToInfosAllocation() {
    let url = this._reportUrl
      .concat(
        "AllocationDebugReport&rs:Command=Render&rc:Parameters=false&CessionId="
      )
      .concat(this.cessionId);
    window.open(url, "_blank");
  }
}
