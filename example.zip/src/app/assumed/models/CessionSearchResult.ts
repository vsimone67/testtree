export interface CessionSearchResult {
  insuredId: string;
  cessionId: string;
  insuredFirstName: string;
  gender: string;
  insuredStatus: string;
  insuredLastName: string;

  insuredMiddleInitial: string;

  policyNumber: string;
  cessionStatus: string;
  policyDate: Date | string | null;
  insuredDateOfBirth: Date | string | null;
  companyName: string;
  treatyNumber: string;
  planName: string;

  planDescription: string;

  insuredFullName: string;

  completePolicyNumber: string;
  quoteNumber: string;
  baseNaramount: number | null;
  generaliCessionNumber: number;

  cessionCategory: string;
  legalEntityName: string;
}
