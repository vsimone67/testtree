import {
  formatNumber,
  formatNumberCent,
  formatNumberSplits,
} from './formatNumber';

export function formatCurrency(data: any) {
  return '$' + formatNumber(data);
}

export function formatCurrencyCent(data: any) {
  return '$' + formatNumberCent(data);
}

export function formatCurrencySplits(data: any) {
  return '$' + formatNumberSplits(data);
}
