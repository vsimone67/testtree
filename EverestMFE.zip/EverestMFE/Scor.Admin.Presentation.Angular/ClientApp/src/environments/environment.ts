export const environment = {
  production: false,
  standalone: true,
  env: 'prod',
};
