import { Component, OnInit } from "@angular/core";
import { CessionGeneralModel } from "@assumed/models/CessionGeneralModel";
import { NoteModel } from "@shared/models/NoteModel";
import { AssumedService } from "@assumed/services/assumed.service";
import { RetroService } from "@retro/services/retro.service";
import { CommonService } from "@shared/services/common.service";
import { ActivatedRoute, Router } from "@angular/router";
import { UnderwritingService } from "@shared/services/underwriting.service";
import { StandardRateService } from "@shared/services/standardRate.service";
import { ColDef, GridOptions } from "ag-grid-community";
import { GetNotesByParentAndGroupCriteria } from "@shared/models/GetNotesByParentAndGroupCriteria";
import { DropPair } from "@shared/models/dropPair";
import { SiteConstants } from "@constants/siteConstants";
import { User } from "@auth/models/user";
import { ConfirmationService, MessageService } from "primeng";
import { LifeLineRoles } from "@auth/models/lifeLineRoles";
import { CessionOverrideAggregate } from "@assumed/models/cessionOverrideAggregate";
import { RollbackService } from "@shared/service/rollback.service";
import { formatDate } from "@shared/components/grid/formatters/formatDate";
import { AssumedAggregatorService } from "@shared/services/assumedAggregatorService";
import { AssumedRollbackAggregatorService } from "@assumed/services/assumed-rollback-aggregator.serivce";
import { AppSettingsService } from "@shared/service/app-settings.service";
import { KeyValuePair } from "@shared/models/KeyValuePair";
import { LifeLineRoleCheck } from "@auth/LifeLineRoleCheck";

@Component({
  selector: "cession-override",
  templateUrl: "./cession-override.component.html",
  styleUrls: ["./cession-override.component.css"],
})
export class CessionOverrideComponent implements OnInit {
  GridCssStyle: string;
  _cessionId: string;
  _generalModel: CessionGeneralModel;
  currentGeneralModel: CessionGeneralModel;
  _criteria: GetNotesByParentAndGroupCriteria;
  retroRatingsList: Array<DropPair>;
  boolList: Array<DropPair>;
  notesList: Array<NoteModel>;
  poolList: Array<DropPair>;
  stackList: Array<DropPair>;
  gradedLimitList: Array<DropPair>;
  rateTables: Array<DropPair>;
  riskClasses: Array<DropPair>;
  retroTypeList: Array<DropPair>;
  howCededList: Array<DropPair>;
  columnDefs: Array<ColDef>;
  gridOptions: GridOptions;
  errors: { key: string; value: string }[];
  isValid: boolean = false;
  isAdmin: boolean = false;
  rollbackOverride: any = null;
  private _reportUrl: string;
  ageBasis: Array<DropPair>;
  constructor(
    private _assumedService: AssumedService,
    private _retroService: RetroService,
    private _commonService: CommonService,
    private _AssumedAggregatorService: AssumedAggregatorService,
    private _messageService: MessageService,
    private _rollbackService: RollbackService,
    private _appSettingsService: AppSettingsService,
    private _rollbackAgregator: AssumedRollbackAggregatorService,
    private _underwritingService: UnderwritingService,
    private _standardRateService: StandardRateService,
    private _router: Router,
    private _route: ActivatedRoute,
    private _confirmService: ConfirmationService
  ) {
    this.gridOptions = <GridOptions>{};
    this._reportUrl = `${this._appSettingsService.GetValue(
      SiteConstants.reportUrl
    )}`;
    this._generalModel = <CessionGeneralModel>{}; // remove error on page load
  }

  ngOnInit(): void {
    this._cessionId = this._route.snapshot.paramMap.get("id");
    this._criteria = <GetNotesByParentAndGroupCriteria>{
      ParentId: this._cessionId,
      NoteGroup: "Notes from Cession General Screen",
    };
    this.populateGeneralModel().then((data) => this.populateDropdowns());
    this.createColumns();
    this.GridCssStyle = "width: 100%; height: 150px;";
    this.populateNotes();

    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this.isAdmin = LifeLineRoleCheck.isCessionDetailWrite();
  }

  //get the override
  async populateGeneralModel() {
    var over = await this._assumedService.displayCessionOverride(
      this._cessionId
    );
    var cession = await this._assumedService.getCessionById(this._cessionId);
    var cessionDetail = await this._assumedService.displayCessionDetails(
      this._cessionId
    );

    //map the override to a generalmodel
    if (over == null) {
      this._generalModel = <CessionGeneralModel>{
        cessionId: this._cessionId,
        applicationDate: new Date(cessionDetail.applicationDate),
        note: "",
      };
    } else {
      this._generalModel = <CessionGeneralModel>{
        applicationDate: new Date(cessionDetail.applicationDate),
        cessionId: this._cessionId,
        cessionOverrideId: over.cessionOverrideId,
        policyDate: cessionDetail.policyDate,
        insuredIssueAge: over.insuredIssueAge,
        isEorprocessingLocked: over.isEorprocessingLocked,
        jointEqualAge: over.jointEqualAge,
        overrideAllowRecapture: over.overrideAllowRecapture,
        overrideBaseReinsuredAmount: over.overrideBaseReinsuredAmount,
        overrideRetentionStackId: cession.overrideRetentionStackId,
        overrideRetroPoolId: cession.overrideRetroPoolId,
        overrideSCORGradedLimitScheduleId:
          over.overrideScorgradedLimitScheduleId,
        overrideSCORRetentionAmount: over.overrideScorretentionAmount,
        rateFactor: over.rateFactor,
        rateTableId: over.rateTableId,
        retentionSequenceNumber: cession.retentionSequenceNumber,
        retroHowCededTypeId: over.retroHowCededTypeId,
        retroRiskClassId: cession.retroRiskClassId,
        retroTableRating: over.retroTableRating,
        retroTypeId: over.retroTypeId,
        scorRetentionSequenceNumber: over.scorRetentionSequenceNumber,
        secondInsuredIssueAge: over.secondInsuredIssueAge,
        secondInsuredRetroRiskClassId: cession.secondInsuredRetroRiskClassId,
        ageBasisTypeId: over.ageBasisTypeId,
        note: "",
      };
    }

    this.rollbackOverride = await this._rollbackService.hasRollback(
      this._cessionId,
      "CessionOverride"
    );

    this.currentGeneralModel = { ...this._generalModel }; // Save current value in case of update, this will be used to save for the rollback
  }

  //load the policy info

  //get reports URL

  //get the notes
  async populateNotes() {
    this.notesList = await this._commonService.getNotes(this._criteria);
  }

  async populateDropdowns() {
    this.populateBoolList();
    this.populateHowCeded();
    this.populateRetroTypeList();
    this.populateRetroPools();
    this.populateRetentionStacks();
    this.populateRetroTableRatings();
    this.populateScorGradedLimitSchedules();
    this.populateRateTables();
    this.populateRiskClasses();
    this.populateAgeBasis();
  }

  populateAgeBasis() {
    this.ageBasis = [
      {
        label: "",
        value: "00000000-0000-0000-0000-000000000000",
      },
      {
        label: "ALB",
        value: "97E4AD37-CCC4-4BCC-8928-9A83F2AAA1DE",
      },
      {
        label: "ANB",
        value: "B10DD475-B52D-42C1-B8DB-91A6E3570D8F",
      },
    ];
    this.ageBasis.forEach(
      (keyValue) => (keyValue.value = keyValue.value.toString().toLowerCase())
    );
  }
  //get retro pools
  async populateRetroPools() {
    var overrideRetroPoolId =
      this._generalModel.overrideRetroPoolId == undefined
        ? "00000000-0000-0000-0000-000000000000"
        : this._generalModel.overrideRetroPoolId;
    await this._retroService
      .getRetroPools(overrideRetroPoolId)
      .then((liste: any[]) => {
        this.poolList = [];
        liste.forEach((pool) => {
          if (pool) {
            this.poolList.push({
              label: pool.poolName,
              value: pool.retroPoolId,
            });
          }
        });
        this.poolList.sort((a, b) =>
          a.label.toLowerCase().localeCompare(b.label.toLowerCase())
        );
      });
  }

  //get retention stacks
  async populateRetentionStacks() {
    var overrideRetentionStack =
      this._generalModel.overrideRetentionStackId == undefined
        ? "00000000-0000-0000-0000-000000000000"
        : this._generalModel.overrideRetentionStackId;
    await this._assumedService
      .getRetentionStacksForOverride(overrideRetentionStack)
      .then((liste) => {
        this.stackList = [];
        liste.forEach((line: any) => {
          if (line)
            this.stackList.push({
              label: line.stackName,
              value: line.retentionStackId,
            });
        });
        this.stackList.sort((a, b) =>
          a.label.toLowerCase().localeCompare(b.label.toLowerCase())
        );
      });
  }

  populateBoolList() {
    this.boolList = [
      { value: "true", label: "Yes" },
      { value: "false", label: "No" },
    ];
    this.boolList.sort((a, b) =>
      a.label.toLowerCase().localeCompare(b.label.toLowerCase())
    );
  }

  //get retroTypes
  async populateRetroTypeList() {
    await this._retroService.getCodesByCategory("Retro Type").then((liste) => {
      this.retroTypeList = [];
      liste.forEach((line: any) => {
        if (line) {
          this.retroTypeList.push({
            label: line.codeName,
            value: line.codeId,
          });
        }
      });
      this.retroTypeList.sort((a, b) =>
        a.label.toLowerCase().localeCompare(b.label.toLowerCase())
      );
    });
  }

  //populate howCeded
  async populateHowCeded() {
    await this._retroService.getCodesByCategory("How Ceded").then((liste) => {
      this.howCededList = [];
      liste.forEach((line: any) => {
        if (line) {
          this.howCededList.push({
            label: line.codeName,
            value: line.codeId,
          });
        }
      });
      this.howCededList.sort((a, b) =>
        a.label.toLowerCase().localeCompare(b.label.toLowerCase())
      );
    });
  }

  //get retro table ratings
  populateRetroTableRatings() {
    this.retroRatingsList = [
      { label: "1", value: "1" },
      { label: "2", value: "2" },
      { label: "3", value: "3" },
      { label: "4", value: "4" },
      { label: "5", value: "5" },
      { label: "6", value: "6" },
      { label: "7", value: "7" },
      { label: "8", value: "8" },
      { label: "9", value: "9" },
      { label: "10", value: "10" },
      { label: "11", value: "11" },
      { label: "12", value: "12" },
      { label: "13", value: "13" },
      { label: "14", value: "14" },
      { label: "15", value: "15" },
      { label: "16", value: "16" },
      { label: "17", value: "17" },
      { label: "18", value: "18" },
      { label: "19", value: "19" },
      { label: "20", value: "20" },
      { label: "21", value: "21" },
      { label: "22", value: "22" },
      { label: "23", value: "23" },
      { label: "24", value: "24" },
      { label: "25", value: "25" },
      { label: "26", value: "26" },
      { label: "27", value: "27" },
      { label: "28", value: "28" },
      { label: "29", value: "29" },
      { label: "30", value: "30" },
      { label: "31", value: "31" },
      { label: "32", value: "32" },
      { label: "33", value: "33" },
      { label: "34", value: "34" },
      { label: "35", value: "35" },
      { label: "36", value: "36" },
    ];
    this.retroRatingsList.forEach((line) => (line.value = Number(line.value)));
  }

  //get scor graded limit schedules
  async populateScorGradedLimitSchedules() {
    var gradedLimit =
      this._generalModel.overrideSCORGradedLimitScheduleId == undefined
        ? "00000000-0000-0000-0000-000000000000"
        : this._generalModel.overrideSCORGradedLimitScheduleId;
    await this._assumedService
      .getScorGradedLimitSchedulesByOverride(gradedLimit)
      .then((liste) => {
        this.gradedLimitList = [];
        liste.forEach((line: any) => {
          if (line)
            this.gradedLimitList.push({
              label: line.retentionScheduleName,
              value: line.scorGradedLimitScheduleId,
            });
        });
        this.gradedLimitList.sort((a, b) =>
          a.label.toLowerCase().localeCompare(b.label.toLowerCase())
        );
      });
  }

  //get rate tables
  async populateRateTables() {
    await this._standardRateService.getRateTables().then((liste) => {
      this.rateTables = [];
      liste.forEach((line: any) => {
        if (line)
          this.rateTables.push({
            label: line.rateTableName,
            value: line.rateTableId,
          });
      });
      this.rateTables.sort((a, b) =>
        a.label.toLowerCase().localeCompare(b.label.toLowerCase())
      );
    });
  }

  //get risk classes
  async populateRiskClasses() {
    await this._underwritingService.getRetroRiskClasses().then((liste) => {
      this.riskClasses = liste.map((line: any) => {
        return {
          label: line.uwclassName,
          value: line.uwclassId,
        };
      });
      this.riskClasses.sort((a, b) =>
        a.label.toLowerCase().localeCompare(b.label.toLowerCase())
      );
    });
  }

  createColumns() {
    this.columnDefs = this.getColumns();
  }

  getColumns() {
    return [
      {
        headerName: "Note",
        field: "noteText",
        cellClass: "text-left",
      },
      {
        headerName: "Note Date",
        field: "noteDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "Created By",
        field: "creator",
        cellClass: "text-left",
      },
    ];
  }

  async saveOverride() {
    var currentUser: User = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
    this._generalModel.updateUser = currentUser.userName;
    this._generalModel.updateUserid = currentUser.userId;

    this.currentGeneralModel.updateUser = currentUser.userName;
    this.currentGeneralModel.updateUserid = currentUser.userId;

    var aggregateModel = <CessionOverrideAggregate>{
      CurrentValue: this.currentGeneralModel,
      NewValue: this._generalModel,
    };

    this._AssumedAggregatorService
      .SaveCessionOverride(aggregateModel)
      .then((data) => {
        this._messageService.add({
          severity: "success",
          detail: "Cession Override has been Updated",
        });
        this.populateNotes();
        this.populateGeneralModel();
      });
  }

  update(currentNoteValue: string) {
    this.isValid = currentNoteValue.length > 0;
    this.errors = [];
    if (
      this._generalModel.overrideSCORRetentionAmount &&
      this._generalModel.overrideSCORGradedLimitScheduleId
    ) {
      this.errors.push({
        key: "OverrideSCORRetentionAmount",
        value:
          "Please enter SCOR Retention Schedule or SCOR Retention Amount but not both.",
      });
      this.isValid = false;
    }

    if (
      this._generalModel.overrideAllowRecapture &&
      this._generalModel.overrideAllowRecapture === "true" &&
      this._generalModel.overrideSCORGradedLimitScheduleId
    ) {
      this.errors.push({
        key: "OverrideSCORGradedLimitScheduleId",
        value:
          "SCOR Retention Schedule is required when overriding Allow Recapture is Yes.",
      });
      this.isValid = false;
    }
  }

  rollback() {
    this._confirmService.confirm({
      message: "Are you sure you want to Rollback this cession override?",
      header: "Rollback",
      icon: "pi pi-exclamation-triangle",
      acceptLabel: "Yes",
      rejectLabel: "No",
      key: "general",
      accept: () => {
        this._rollbackAgregator
          .rollbackCessionOverride(this._cessionId)
          .then((data) => {
            this._messageService.add({
              severity: "success",
              detail: "Rollback done successfully",
            });
            this.populateNotes();
            this.populateGeneralModel();
          });
      },
    });
  }

  goToInfos() {
    let url = this._reportUrl
      .concat(
        "RetroPriorsReport&rs:Command=Render&rc:Parameters=false&CessionId="
      )
      .concat(this._cessionId);
    window.open(url, "_blank");
  }
}
