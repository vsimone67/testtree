import { ContactDto } from './contactDto';
import { EmployeeDto } from './employeeDto';

export interface EmployeeContactDto {
    employeeId: string;
    contactId: string;
    employeeContactRoleTypeId: string;
    isPrimary: boolean | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    employeeContactNote: string;
    contact: ContactDto;
    employee: EmployeeDto;
}