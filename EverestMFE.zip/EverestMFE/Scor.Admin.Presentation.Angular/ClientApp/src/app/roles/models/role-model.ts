export interface RoleModel {
    applicationId: string;
    roleId: string;
    roleName: string;
    loweredRoleName: string;
    description: string;
    userId: string;
    rowStatusId: string;
}