import { Injectable } from '@angular/core';
import { events } from '@constants/events.model';
import { AppSettingsService, EventService } from '@scor/common';
import { MicroFrontEnd } from '../models/microFrontEnd';

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  public _microFontEnds: Array<MicroFrontEnd>;

  constructor(
    private appsettings: AppSettingsService,
    private _eventService: EventService
  ) {
    this._microFontEnds = <Array<MicroFrontEnd>>(
      this.appsettings.GetValue('microFrontEnds')
    );
  }

  loadMicroFrontEnd(name: string): void {
    var microFrontEnd = this._microFontEnds.find((exp) => exp.name === name);

    // only load the MFE once
    if (!microFrontEnd.loaded) {
      this._eventService.sendEvent(events.loadingEvent, true);

      microFrontEnd.loaded = true;

      const content = document.getElementById('content');
      const script = document.createElement('script');
      script.src = microFrontEnd.path;
      content.appendChild(script);

      const element: HTMLElement = document.createElement(
        microFrontEnd.element
      );
      content.appendChild(element);

      script.onerror = () =>
        console.error(`error loading ${microFrontEnd.path}`);

      this._eventService.sendEvent(events.loadingEvent, false);
    }
  }
}
