import { Injectable } from '@angular/core';
import { User } from '@auth/models/user';
import { SiteConstants } from '@constants/siteConstants';
import { HttpService, AppSettingsService } from '@scor/common';
import { AssignableModel } from '../models/assignable-model';
import { GroupModel } from '../models/group-model';
import { MembershipModel } from '../models/membership-model';

@Injectable({
  providedIn: 'root',
})
export class SecurityGroupsService {
  baseApiUrl: string;
  controllerUrl: string;
  currentUser: User;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this.baseApiUrl = `${this._appSettingsService.GetValue('apiGatewayUrl')}`;
    this.controllerUrl = `${this._appSettingsService.GetValue(
      'apiGatewayUrl'
    )}/securitygroups`;
    this.currentUser = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
  }

  async getGroups() {
    return await this._httpService.getData<GroupModel[]>(
      `${this.controllerUrl}/GetSecurityGroups`
    );
  }

  async getGroupMembers(groupId: string) {
    return await this._httpService.getData<MembershipModel[]>(
      `${this.controllerUrl}/GetRolesInGroup?groupId=${groupId}`
    );
  }

  async getUnassignedMembers(groupId: string) {
    return await this._httpService.getData<AssignableModel[]>(
      `${this.controllerUrl}/GetAssignableRoles?groupId=${groupId}`
    );
  }

  async addSecurityGroup(
    groupName: string,
    codeDescription: string,
    codeValue: string,
    moduleReferenceId: string
  ) {
    const body = {
      GroupName: groupName,
      CodeDescription: codeDescription,
      CodeValue: codeValue,
      ModuleReferenceId: moduleReferenceId,
      UserId: this.currentUser.id,
    };

    return await this._httpService.postData(
      `${this.controllerUrl}/AddSecurityGroup`,
      body
    );
  }

  async editSecurityGroup(
    groupId: string,
    groupName: string,
    codeDescription: string,
    codeValue: string,
    moduleReferenceId: string,
    rowStatusId: string
  ) {
    const body = {
      GroupId: groupId,
      GroupName: groupName,
      CodeDescription: codeDescription,
      CodeValue: codeValue,
      ModuleReferenceId: moduleReferenceId,
      UserId: this.currentUser.id,
      RowStatusId: rowStatusId,
    };

    return await this._httpService.putData(
      `${this.controllerUrl}/EditSecurityGroup`,
      body
    );
  }

  async setStatus(
    groupId: string,
    groupName: string,
    codeDescription: string,
    codeValue: Date,
    moduleReferenceId: string,
    rowStatusId: string
  ) {
    const body = {
      GroupId: groupId,
      GroupName: groupName,
      CodeDescription: codeDescription,
      CodeValue: codeValue,
      ModuleReferenceId: moduleReferenceId,
      UserId: this.currentUser.id,
      RowStatusId: rowStatusId,
    };

    return await this._httpService.putData(
      `${this.controllerUrl}/SetStatus`,
      body
    );
  }

  async addRoleToGroup(
    applicationId: string,
    groupCodeId: string,
    roleId: string
  ) {
    const body = {
      ApplicationId: applicationId,
      GroupCodeId: groupCodeId,
      RoleId: roleId,
      CreatedBy: this.currentUser.id,
    };

    return await this._httpService.postData(
      `${this.controllerUrl}/AddRoleToGroup`,
      body
    );
  }

  async removeRoleFromGroup(roleHistoryId: string) {
    const body = {
      RoleHistoryId: roleHistoryId,
      CreatedBy: this.currentUser.id,
    };

    return await this._httpService.postData(
      `${this.controllerUrl}/RemoveRoleFromGroup`,
      body
    );
  }
}
