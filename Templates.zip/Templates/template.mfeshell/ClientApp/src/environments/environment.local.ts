export const environment = {
  env: "local",
  production: false,
  displayEnvironment: "LOCAL",
};
