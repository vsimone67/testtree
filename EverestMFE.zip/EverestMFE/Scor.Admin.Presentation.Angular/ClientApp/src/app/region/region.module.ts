import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegionsContainerComponent } from './components/regions-container/regions-container.component';
import { RegionsResultsComponent } from './components/regions-results/regions-results.component';
import { RegionsSearchComponent } from './components/regions-search/regions-search.component';
import { AssociateCountryComponent } from './dialogs/associate-country/associate-country.component';
import { EditRegionComponent } from './dialogs/edit-region/edit-region.component';
import { RemoveCountryComponent } from './dialogs/remove-country/remove-country.component';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [
    RegionsContainerComponent,
    RegionsResultsComponent,
    RegionsSearchComponent,
    AssociateCountryComponent,
    EditRegionComponent,
    RemoveCountryComponent,
  ],
  imports: [CommonModule, SharedModule],
})
export class RegionModule {}
