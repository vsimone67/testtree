import { Component } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from '@scor/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  date: number;
  version: string;
  environment: string;
  constructor(private appsettings: AppSettingsService) {}

  ngOnInit() {
    // gather data for footer
    this.date = new Date().getFullYear();
    this.version = SiteConstants.version;
    this.environment = this.appsettings.GetValue('environment');
  }
}
