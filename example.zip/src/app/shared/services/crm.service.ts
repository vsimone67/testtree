import { Injectable } from '@angular/core';
import { HttpService } from './http-service.service';
import { SiteConstants } from '@constants/siteConstants';
import { CompanyModel } from '@assumed/models/companyModel';
import { CompanyMinimalModel } from '@assumed/models/companyMinimalModel';
import { AppSettingsService } from './app-settings.service';

@Injectable({
  providedIn: 'root'
})
export class CrmService {
  private _crmUrl: string;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {

    //this._crmUrl = `${environment.apiGatewayUrl}/${SiteConstants.crmController}`;
    this._crmUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.crmController}`;

  }
  async getAllCompanies() {
    return await this._httpService.getData<Array<CompanyModel>>(
      `${this._crmUrl}/GetAllCompanies`
    );
  }

  async GetAllLegalEntities() {
    return await this._httpService.getData<Array<CompanyModel>>(
      `${this._crmUrl}/GetAllLegalEntities`
    );
  }

  async GetRetroCompanies() {
    return await this._httpService.getData<Array<CompanyMinimalModel>>(
      `${this._crmUrl}/GetRetroCompanies`
    );
  }
}
