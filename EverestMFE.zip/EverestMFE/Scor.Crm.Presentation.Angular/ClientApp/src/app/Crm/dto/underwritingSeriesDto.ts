import { EmployeeUnderwritingSeriesDto } from './employeeUnderwritingSeriesDto';
import { UnderwritingSeriesCountryDto } from './underwritingSeriesCountryDto';
import { UnderwritingSeriesDecisionLanguageDto } from './underwritingSeriesDecisionLanguageDto';

export interface UnderwritingSeriesDto {
    seriesId: string;
    seriesName: string;
    seriesSequence: number;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string;
    seriesSortSequence: number;
    employeeUnderwritingSeries: EmployeeUnderwritingSeriesDto[];
    underwritingSeriesCountry: UnderwritingSeriesCountryDto[];
    underwritingSeriesDecisionLanguage: UnderwritingSeriesDecisionLanguageDto[];
}