import { NgModule } from '@angular/core';
import { LogViewerComponent } from './components/log-viewer/log-viewer.component';
import { SharedModule } from '@shared/shared.module';
import { LoggingService } from './services/logging.service';

import { CessionHistoryDialogComponent } from './components/dialogs/cession-history-dialog/cession-history-dialog.component';
import { RetentionLimitComponent } from './components/retention-limit/retention-limit.component';
import { PoolComponent } from './components/pool/pool.component';
import { StackComponent } from './components/stack/stack.component';
import { SplitsComponent } from './components/splits/splits.component';
import { PriorPostsComponent } from './components/prior-posts/prior-posts.component';
import { VerboseItemsComponent } from './components/verbose-items/verbose-items.component';
import { SplitsAnalysisComponent } from './components/splits-analysis/splits-analysis.component';
import { SplitDetailComponent } from './components/split-detail/split-detail.component';
import { PersonSplitViewerComponent } from './components/person-split-viewer/person-split-viewer.component';
import {AgGridModule} from "ag-grid-angular";
import {TreeTableModule} from "primeng";
import { CessionInfoComponent } from './components/cession-info/cession-info.component';

@NgModule({
  declarations: [LogViewerComponent, PersonSplitViewerComponent, CessionHistoryDialogComponent, RetentionLimitComponent, PoolComponent, StackComponent, SplitsComponent, PriorPostsComponent, VerboseItemsComponent, SplitsAnalysisComponent, SplitDetailComponent, CessionInfoComponent],
  imports: [SharedModule, AgGridModule, TreeTableModule],
  exports: [LogViewerComponent],
  providers: [LoggingService]
})
export class LoggingModule { }
