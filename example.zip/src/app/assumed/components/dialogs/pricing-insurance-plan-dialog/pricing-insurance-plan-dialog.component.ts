import { Component, OnInit, Input } from '@angular/core';
import { PricingInsurancePlanModel } from '@assumed/models/PricingIncurancePlanModel';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';

@Component({
  selector: 'pricing-insurance-plan-dialog',
  templateUrl: './pricing-insurance-plan-dialog.component.html',
  styleUrls: ['./pricing-insurance-plan-dialog.component.css']
})
export class PricingInsurancePlanComponent extends DialogBase implements OnInit {

  @Input() pricingInsurancePlanModel: PricingInsurancePlanModel
  constructor() { super(); }

  ngOnInit(): void {
  }

}
