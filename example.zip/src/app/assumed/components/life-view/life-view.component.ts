import { Component, OnInit, ViewChild, ViewEncapsulation, NgZone } from "@angular/core";

import { SelectItem } from "primeng/api";
import { ActivatedRoute, Router } from '@angular/router';
import { AssumedService } from '@assumed/services/assumed.service';
import { PersonModel } from '@assumed/models/PersonModel';
import { GraphEventModel } from '@assumed/models/GraphEventModel';
import { CessionViewComponent } from '../cession-view/cession-view.component';
import { EventService } from '@shared/services/event.service';
import { events } from '@constants/events.model';
import { CessionTransactionModel } from '@assumed/models/CessionTransactionModel';
import { NodeConstants } from '@constants/nodeConstants';
import { SiteConstants } from '@constants/siteConstants';
import { CessionSearchResult } from "@assumed/models/CessionSearchResult";
import { CessionSearchModel } from "@assumed/models/CessionSearchmodel";


@Component({
  encapsulation: ViewEncapsulation.None,
  selector: "life-view",
  templateUrl: "./life-view.component.html",
  styleUrls: ["./life-view.component.css"],
})
export class LifeViewComponent implements OnInit {
  @ViewChild(CessionViewComponent, { static: false }) cessionViewComponent;

  // cession info
  cessonsForLife: PersonModel;
  cessionToSearch: number;
  currentCessionId: string;

  // Flag to display grids
  showTransactions: boolean = false;
  showHistory: boolean = false;
  showNaarDifferences: boolean = false;

  // slider
  minMonth: number;
  maxMonth: number;
  startingMonth: Date;
  monthLabel: string;

  // Dropdown
  txnFilters: SelectItem[];
  txtFilter: SelectItem;

  searchVisible: boolean = true;  // show/hide group id text box and search button (will be hidden if the staring path is Everest)
  showSearch: boolean = true;  // true = seach border is expanded, false = collapsed
  currentEvent: GraphEventModel;

  person:string;
  constructor(
    private _assumedService: AssumedService,
    private _route: ActivatedRoute,
    private _eventService: EventService,
    private zone: NgZone,
    private _router: Router
  ) {
    // history filter
    this.txnFilters = [
      { label: "All", value: "" },
      { label: "Change", value: "CHG" },
      { label: "Death", value: "DTH" },
      { label: "Lapse", value: "LAP" },
      { label: "New", value: "NEW" },
      { label: "Renewal", value: "REN" },
      { label: "Reinstatment", value: "REI" },
      { label: "Reverse", value: "REV" }
    ];

    this.minMonth = 1;
    this.showSearch = false;
  }

  async ngOnInit() {
    var id = this._route.snapshot.paramMap.get("id");  // get ID that will be passeed from the Everest App

    if (id !== null) {  // if value is not undefined, the page was called from Everest
      this.currentCessionId = id;
      this.cessonsForLife = await this._assumedService.getPersonFromCesson(id);
      // if value is not undefined, the page was called from Everest
			var searchModel = <CessionSearchModel>{ CessionId: id };
			var searchResult = await this._assumedService.searchCession(searchModel);

			// set the current cession info to local storage so the logging screen can ue some of the info
			localStorage.removeItem(SiteConstants.cessionLocalStorage);
			localStorage.setItem(SiteConstants.cessionLocalStorage,	JSON.stringify(searchResult[0]));
      this.showSearch = false;
    }

    var storedCession = localStorage.getItem(SiteConstants.cessionLocalStorage); // get the stored cession data so we can show the cession info

    if (storedCession) {
      var cessionData = JSON.parse(localStorage.getItem(SiteConstants.cessionLocalStorage)) as CessionSearchResult;
      this.person = `${cessionData.insuredFullName} ${cessionData.completePolicyNumber}`;
    }
  }

  // person graph will send data to this method when node is clicked
  displayNodeData(event: GraphEventModel) {
    switch (event.data.metaData) {
      case NodeConstants.transaction: {
        this.showTransactions = true;
        this.setFilterDateParameters(event.data.payload)
        break;
      }
      case NodeConstants.history: {
        this.showHistory = true;
        this.showNaarDifferences = true;
        break;
      }
      case NodeConstants.split: {
        this.showHistory = true;
        this.showNaarDifferences = true;
        break;
      }

    }
    this.currentEvent = event;
  }

  async searchCession() {
    this.resetValues();
    this.cessonsForLife = await this._assumedService.getPerson(this.cessionToSearch);
  }

  setFilterDateParameters(transactions: Array<CessionTransactionModel>) {
    var earliestDate = new Date();
    var latestDate = new Date(2016, 1, 1);

    // go through each row and get the earlest date to use for the starting filter
    transactions.forEach(txn => {

      var fromDate = new Date(txn.fromDate);
      if (fromDate < earliestDate)
        earliestDate = new Date(txn.fromDate);

      if (fromDate > latestDate)
        latestDate = new Date(txn.fromDate);
    })

    this.startingMonth = earliestDate;
    // calc number of months
    var diff = (latestDate.getTime() - earliestDate.getTime()) / 1000;
    diff /= (60 * 60 * 24 * 7 * 4);
    this.maxMonth = Math.abs(Math.round(diff));

    // set the month label to show the staring month of the filter
    this.monthLabel = this.startingMonth.getMonth() + "/" + this.startingMonth.getDay() + "/" + this.startingMonth.getFullYear();
  }

  // Slider
  filterTxnDate(e) {
    //e.value is the new value
    var filterDate = new Date(this.startingMonth); // make cone of staring date

    filterDate.setMonth(filterDate.getMonth() + e.value);
    this.monthLabel = filterDate.getMonth() + "/" + filterDate.getDay() + "/" + filterDate.getFullYear();

    this._eventService.sendEvent(events.txnDateFilter, filterDate); // send date filter to txnGrid Component
  }

  //  Drop down triggers filter
  filterByTxn() {
    // send event to TxnGrid for txn type filter
    if(this.txtFilter)
    this._eventService.sendEvent(events.tnxTypeFilter, this.txtFilter.value)
    else
      this._eventService.sendEvent(events.tnxTypeFilter, null)
  }

  toggleNaarFilter(e) {
    if (!e.checked) {
      this.turnOnDifferences();
    } else {
      this.turnOffDifferences();
    }
  }

  turnOnDifferences() {
    this._eventService.sendEvent(events.showHistoryNaarDifferences, true);
    this._eventService.sendEvent(events.showSplitsNaarDifferences, true);
  }

  turnOffDifferences() {
    this._eventService.sendEvent(events.showHistoryNaarDifferences, false);
    this._eventService.sendEvent(events.showSplitsNaarDifferences, false);
  }

  hideSearch() {
    this.searchVisible = !this.searchVisible
  }

  resetValues() {
    this.cessonsForLife = null;
    this.showHistory = false;
    this.showNaarDifferences = false;
    this.showTransactions = false;
  }

  clearAll() {
    this.showHistory = false;
    this.showTransactions = false;
    this.showNaarDifferences = false;
    this.currentEvent = null;
    this.cessionViewComponent.clearAllGrids();
    this._eventService.clearAllEvents();
  }

  gridHidden(gridName: string) {
    this.currentEvent = null;

    if (gridName === NodeConstants.history) {
      this.showHistory = false;
    }
    else if (gridName === NodeConstants.transaction) {
      this.showTransactions = false;
    }
  }

  jumpToLogging() {
    this.zone.run(() =>
      this._router.navigate([`${SiteConstants.logRoute}/${this.currentCessionId}`])
    );
  }

  jumpToEdit() {
    this.zone.run(() =>
      this._router.navigate([`${SiteConstants.editCessionRoute}/${this.currentCessionId}`])
    );
  }
}
