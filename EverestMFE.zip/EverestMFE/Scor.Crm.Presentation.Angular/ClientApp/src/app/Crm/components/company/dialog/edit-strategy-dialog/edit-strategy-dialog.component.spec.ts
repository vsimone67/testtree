import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditStrategyDialogComponent } from './edit-strategy-dialog.component';

describe('EditStrategyDialogComponent', () => {
  let component: EditStrategyDialogComponent;
  let fixture: ComponentFixture<EditStrategyDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditStrategyDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditStrategyDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
