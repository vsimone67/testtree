import { TreatyModel } from './TreatyModel';

export interface TreatyCompleteModel {
  treaty: TreatyModel;
}
