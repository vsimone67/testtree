import { AddressDto } from './addressDto';
import { CompanyDto } from './companyDto';
import { ContactDto } from './contactDto';
import { EmailAddressDto } from './emailAddressDto';
import { EmployeeDto } from './employeeDto';
import { PhoneNumberDto } from './phoneNumberDto';

export interface DemographicInfoGroupDto {
    groupId: string;
    groupDescription: string;
    groupName: string;
    groupSubTypeId: string | null;
    groupTypeId: string | null;
    parentId: string | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    address: AddressDto[];
    company: CompanyDto[];
    contact: ContactDto[];
    emailAddress: EmailAddressDto[];
    employee: EmployeeDto[];
    phoneNumber: PhoneNumberDto[];
}