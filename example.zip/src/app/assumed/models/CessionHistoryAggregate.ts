import { CessionHistoryModel } from "./CessionHistoryModel";

export interface CessionHistoryAggregate {
  currentValue: CessionHistoryModel;
  newValue: CessionHistoryModel;
}
