import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AddNoteDto } from '@scor/common/lib/components/notes/models/AddNoteDto';
import { CrmService } from '../../../service/CrmService';
import { DatePipe } from '@angular/common';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from '@scor/common';

@Component({
  selector: 'notes',
  templateUrl: './notes-components.component.html',
  styleUrls: ['./notes-components.component.css'],
})
export class NotesComponents implements OnInit {
  noteType: any;
  @Input() parentId: any;
  notesUrl: any;
  showDialog: boolean;
  selectedNote: AddNoteDto;
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    private _appSettingsService: AppSettingsService,
    private crmService: CrmService
  ) {}

  ngOnInit(): void {
    this.noteType = 'Group_Company_Note';
    this.notesUrl = this._appSettingsService.GetValue('apiNoteurl');
    console.log(`The note URL is ${this.notesUrl}`);

    if (this.parentId === null) {
      this.parentId = '00000000-0000-0000-0000-000000000000';
    }
  }

  addNote() {
    this.selectedNote = <AddNoteDto>{};
    this.showDialog = true;
  }

  submiTDialog(note: AddNoteDto) {
    note.parentId = this.parentId;
    let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
    note.createdBy = user.userId;
    this.crmService.CreateNote(note).then((lis) => this.refreshData.emit());
    this.showDialog = false;
  }

  hide() {
    this.showDialog = false;
  }
}
