import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {AddNoteDto} from "@scor/common/lib/components/notes/models/AddNoteDto";
import {DatePipe} from "@angular/common";

@Component({
  selector: 'note-dialog',
  templateUrl: './note-dialog.component.html',
  styleUrls: ['./note-dialog.component.css']
})
export class NoteDialogComponent implements OnInit {
  @Input() note: AddNoteDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  date: Date = new Date()

  constructor(private datePipe:DatePipe) {
  }

  ngOnInit(): void {
  }

  hideDialog() {
    this.onDialogHide.emit()
  }

  submitDialog() {
    this.note.noteDate =  this.datePipe.transform(this.date,"yyyy-MM-ddTHH:mm:ss")
    this.onSubmitDialog.emit(this.note);
    this.onDialogHide.emit()

  }
}
