import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { SiteConstants } from '@constants/siteConstants';
import { PersonModel } from "../models/PersonModel";
import { QuoteCompleteModel } from '@assumed/models/QuoteCompleteModel';
import { CessionSearchModel } from '@assumed/models/CessionSearchmodel';
import { CessionSearchResult } from '@assumed/models/CessionSearchResult';
import { RetentionStackModel } from '@assumed/models/RetentionStackModel';
import { ScorGradedLimitScheduleModel } from '@assumed/models/ScorGradedLimitScheduleModel';
import { CessionOverrideModel } from '@assumed/models/CessionOverrideModel';
import { CessionDetailsModel } from '@assumed/models/CessionDetailsModel';
import { CessionModel } from '@assumed/models/CessionModel';
import { CessionGeneralModel } from '@assumed/models/cessionGeneralModel'
import { CessionPoolBindingOverrideModel } from '@assumed/models/CessionPoolBindingOverrideModel';
import { CessionHistoryModel } from '@assumed/models/CessionHistoryModel';
import { AppSettingsService } from '@shared/services/app-settings.service';

@Injectable({
  providedIn: "root",
})
export class AssumedService {

  private _cessionUrl: string;

  constructor(
    private _httpService: HttpService, private _appSettingsService: AppSettingsService) {

    //this._cessionUrl = `${environment.apiGatewayUrl}/${SiteConstants.cessionController}`;
    this._cessionUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.cessionController}`;
  }

  async getPerson(groupId: number) {
    return await this._httpService.getData<PersonModel>(
      `${this._cessionUrl}/DisplayPerson/${groupId}`
    );
  }

  async getPersonFromCesson(cessionId: string) {
    return await this._httpService.getData<PersonModel>(
      `${this._cessionUrl}/DisplayPersonFromCession/${cessionId}`
    );
  }

  async getCessionHistory(cessionId: string) {
    return await this._httpService.getData<Array<CessionHistoryModel>>(
      `${this._cessionUrl}/GetCessionHistoryForCession/${cessionId}`
    );
  }

  async AddCessionHistory(model: CessionHistoryModel) {
    return await this._httpService.postData(`${this._cessionUrl}/AddCessionHistory`,model);
  }

  async EditCessionHistory(model: CessionHistoryModel) {
    return await this._httpService.postData(`${this._cessionUrl}/EditCessionHistory`,model);
  }

  async getProposalQuoteBandShare(proposalQuoteBandShareId) {
    return await this._httpService.getData<QuoteCompleteModel>(
      `${this._cessionUrl}/DisplayQuoteCompleteForProposalQuoteBandShareId/${proposalQuoteBandShareId}`
    );
  }

  async getQuoteInfo(quoteId) {
    return await this._httpService.getData<QuoteCompleteModel>(
      `${this._cessionUrl}/DisplayQuoteComplete/${quoteId}`
    );
  }

  async searchCession(model: CessionSearchModel) {
    return await this._httpService.postData<Array<CessionSearchResult>>(
      `${this._cessionUrl}/CessionSearch`, model);
  }
  async getRetentionStacksForOverride(overrideRetentionStackId: string) {
    return await this._httpService.getData<Array<RetentionStackModel>>(
      `${this._cessionUrl}/GetRetentionStacksForOverrideRetentionStackId/${overrideRetentionStackId}`);

  }
  async getScorGradedLimitSchedulesByOverride(overrideRetentionStackId: string) {
    return await this._httpService.getData<Array<ScorGradedLimitScheduleModel>>(
      `${this._cessionUrl}/GetScorGradedLimitSchedulesByOverride/${overrideRetentionStackId}`);

  }
  async displayCessionOverride(cessionId: string) {
    return await this._httpService.getData<CessionOverrideModel>(
      `${this._cessionUrl}/DisplayCessionOverride/${cessionId}`);

  }
  async displayCessionDetails(cessionId: string) {
    return await this._httpService.getData<CessionDetailsModel>(
      `${this._cessionUrl}/DisplayCessionDetails/${cessionId}`);
  }
  async getCessionById(cessionId: string) {
    return await this._httpService.getData<CessionModel>(
      `${this._cessionUrl}/GetCessionByPrimaryKey/${cessionId}`);
  }
  async getRetroCessionDetailsByCessionId(cessionId: string) {
    return await this._httpService.getData<CessionModel>(
      `${this._cessionUrl}/GetRetroCessionDetailsByCession/${cessionId}`);
  }
  async saveOverride(model: CessionGeneralModel) {
    return await this._httpService.postData<Array<CessionGeneralModel>>( `${this._cessionUrl}/SaveOverride`, model);
  }

  async getRetroPoolBindingOverride(cessionId: string) {
    return await this._httpService.getData<Array<CessionPoolBindingOverrideModel>>(`${this._cessionUrl}/GetCessionPoolBindingOverride/${cessionId}`);
  }

  async AddRetroPoolBindingOverride(model: CessionPoolBindingOverrideModel) {
    return await this._httpService.postData<CessionPoolBindingOverrideModel>(`${this._cessionUrl}/AddCessionPoolOverride`, model);
  }

  async editRetroPoolBindingOverride(model: CessionPoolBindingOverrideModel) {
    return await this._httpService.postData<CessionPoolBindingOverrideModel>(`${this._cessionUrl}/EditCessionPoolOverride`, model);
  }

  async deleteRetroPoolBindingOverride(model: CessionPoolBindingOverrideModel) {
    return await this._httpService.postData<CessionPoolBindingOverrideModel>(`${this._cessionUrl}/DeleteCessionPoolOverride`, model);
  }

  async getCessionOverride(cessionId: string) {
    return await this._httpService.getData<CessionOverrideModel>(`${this._cessionUrl}/DisplayCessionOverride/${cessionId}`);
  }
}
