import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {PhoneNumberDto} from "../../../../dto/phoneNumberDto";
import {CrmService} from "../../../../service/CrmService";

@Component({
  selector: 'phone-dialog',
  templateUrl: './phone-dialog.component.html',
  styleUrls: ['./phone-dialog.component.css']
})
export class PhoneDialogComponent implements OnInit {
  @Input() phone:PhoneNumberDto
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  types

  constructor(private _crmService: CrmService) { }

  ngOnInit(): void {
    this._crmService.GetPhoneTypeCodes().then(typesOb => {
      this.types = [];
      typesOb.forEach(t => {
        this.types.push({
          label: t.codeName,
          value: t.codeId,
          data: t
        })
      })
    })
  }
  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    if (this.phone.phoneNumberTypeId) {
      this.phone.phoneNumberType = this.types.filter(ty => ty.value === this.phone.phoneNumberTypeId)[0].data;
    }
    this.onSubmitDialog.emit(this.phone);
    this.onDialogHide.emit()

  }
}
