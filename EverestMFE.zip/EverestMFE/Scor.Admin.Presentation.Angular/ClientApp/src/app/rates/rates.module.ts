import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RatesContainerComponent } from '../rates/components/rates-container/rates-container.component';
import { RatesResultsComponent } from '../rates/components/rates-results/rates-results.component';
import { RatesSearchComponent } from '../rates/components/rates-search/rates-search.component';
import { AddExchangeRateComponent } from '../rates/dialogs/add-exchange-rate/add-exchange-rate.component';
import { DeleteExchangeRateComponent } from '../rates/dialogs/delete-exchange-rate/delete-exchange-rate.component';
import { EditExchangeRateComponent } from '../rates/dialogs/edit-exchange-rate/edit-exchange-rate.component';
import { SharedModule } from '@shared/shared.module';

@NgModule({
  declarations: [
    RatesContainerComponent,
    RatesResultsComponent,
    RatesSearchComponent,
    AddExchangeRateComponent,
    DeleteExchangeRateComponent,
    EditExchangeRateComponent,
  ],
  imports: [CommonModule, SharedModule],
  exports: [],
})
export class RatesModule {}
