import {CompanyDto} from './companyDto';
import {ActionPlanDto} from './actionPlanDto';
import {SalesObjectiveDto} from './salesObjectiveDto';
import {SalesObstacleDto} from './salesObstacleDto';
import {SalesOpportunityDto} from './salesOpportunityDto';
import {CodeDto} from "./codeDto";

export interface StrategyDto {
  strategyId: string;
  companyId: string;
  generaliDivisionId: string;
  strategyName: string;
  strategyTypeId: string | null;
  createDate: string;
  createdBy: string | null;
  modifiedDate: string | null;
  modifiedBy: string | null;
  moduleReference: string | null;
  rowStatusId: string | null;
  company: CompanyDto;
  actionPlan: ActionPlanDto[];
  salesObjective: SalesObjectiveDto[];
  salesObstacle: SalesObstacleDto[];
  salesOpportunity: SalesOpportunityDto[];
  generaliDivision: CodeDto;
  strategyType:CodeDto
}
