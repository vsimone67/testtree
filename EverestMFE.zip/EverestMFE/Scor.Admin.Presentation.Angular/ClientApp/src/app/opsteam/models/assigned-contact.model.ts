export interface AssignedContactModel {
    contactId: string;
    contactLastName: string;
    contactMiddleName: string;
    contactFirstName: string;
}