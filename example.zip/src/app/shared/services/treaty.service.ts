import { Injectable } from '@angular/core';
import { HttpService } from './http-service.service';
import { TreatyCompleteModel } from '@assumed/models/TreatyCompleteModel';
import { SiteConstants } from '@constants/siteConstants';
import { VwTreatyPlanBasicInfo } from '@shared/models/VwTreatyPlanBasicInfo';
import { TreatyModel } from '@shared/models/TreatyModel';
import { VwTreatySearchRetro } from '@shared/models/VwTreatySearchRetro';
import { AppSettingsService } from './app-settings.service';

@Injectable({
  providedIn: 'root'
})
export class TreatyService {
  private _treatyUrl: string;

  constructor(
    private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    //this._treatyUrl = `${environment.apiGatewayUrl}/${SiteConstants.treatyController}`;
    this._treatyUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.treatyController}`;
  }

  async getTreatyInfo(treatyId) {
    return await this._httpService.getData<TreatyCompleteModel>(`${this._treatyUrl}/DisplayTreatyComplete/${treatyId}`);
  }

  async getTreatyPlanBasicInfo(treatyPlanTreatyId: string) {
    return await this._httpService.getData<Array<VwTreatyPlanBasicInfo>>(`${this._treatyUrl}/GetTreatyPlanBasicInfo/${treatyPlanTreatyId}`);
  }

  async getTreatyForCompanies(companyId: string) {
    return await this._httpService.getData<Array<VwTreatySearchRetro>>(`${this._treatyUrl}/GetTreatiesForCompany/${companyId}`);
  }

  async getQuotesForTreaty(treatyId: string) {
    return await this._httpService.getData<Array<TreatyModel>>(`${this._treatyUrl}/GetQuotesForTreaty/${treatyId}`);
  }

}
