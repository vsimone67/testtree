import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { SecurityRolesService } from 'src/app/roles/services/security-roles.service';
import { RoleModel } from '../../models/role-model';

@Component({
  selector: 'app-remove-member',
  templateUrl: './remove-member.component.html',
  styleUrls: ['./remove-member.component.css'],
})
export class RemoveMemberComponent
  extends EditDialogBase<RoleModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() selectedData;
  teamName: string;
  roleName;

  constructor(private rolesService: SecurityRolesService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.roleName = this.selectedData.roleName;
  }

  async confirm() {
    await this.rolesService.removeUserFromRole(
      this.selectedData.userId,
      this.selectedData.roleId
    );
    this.submitDialog();
    this.hideDialog();
  }

  deny() {
    this.hideDialog();
  }
}
