import { Component, OnInit, Input } from "@angular/core";
import { DialogBase } from '@assumed/components/dialogs/dialog-base';
import { CessionOverrideModel } from '@assumed/models/CessionOverrideModel';

@Component({
  selector: "override-dialog",
  templateUrl: "./override-dialog.component.html",
  styleUrls: ["./override-dialog.component.css"],
})
export class OverrideDialogComponent extends DialogBase implements OnInit {
  @Input() OverrideData: CessionOverrideModel;

  showDialog: boolean;
  constructor() {
    super();
    this.showDialog = true;
  }

  ngOnInit() { }


}
