export interface KeyValuePair{
    Key: string;
    Value: string;
}