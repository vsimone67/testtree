import { Component, OnInit, Input, SimpleChange } from "@angular/core";
import { Layout, Edge, Node } from "@swimlane/ngx-graph";
import * as shape from "d3-shape";
import { SiteConstants } from "@constants/siteConstants";
import { CessionSearchResult } from "@assumed/models/CessionSearchResult";
import { ActivatedRoute, Router } from "@angular/router";
import { AssumedService } from "@assumed/services/assumed.service";
import { PersonModel } from "@assumed/models/PersonModel";
import { CessionSearchModel } from "@assumed/models/CessionSearchmodel";

@Component({
	selector: "cession-edit",
	templateUrl: "./cession-edit.component.html",
	styleUrls: ["./cession-edit.component.css"]
})
export class CessionEditComponent implements OnInit {
	person: string;

	constructor(
		private _route: ActivatedRoute,
		private _assumedService: AssumedService
	) {}

	async ngOnInit() {
		var id = this._route.snapshot.paramMap.get("id"); // get ID that will be passeed from the Everest App

		if (id !== null) {
			// if value is not undefined, the page was called from Everest
			var searchModel = <CessionSearchModel>{ CessionId: id };
			var searchResult = await this._assumedService.searchCession(searchModel);

			// set the current cession info to local storage so the logging screen can ue some of the info
			localStorage.removeItem(SiteConstants.cessionLocalStorage);
			localStorage.setItem(SiteConstants.cessionLocalStorage,	JSON.stringify(searchResult[0]));
		}

		var storedCession = localStorage.getItem(SiteConstants.cessionLocalStorage); // get the stored cession data so we can show the cession info

		if (storedCession) {
			var cessionData = JSON.parse(localStorage.getItem(SiteConstants.cessionLocalStorage)) as CessionSearchResult;
			this.person = `${cessionData.insuredFullName} ${cessionData.completePolicyNumber}`;
		}
	}
}
