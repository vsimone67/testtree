import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {SalesObstacleDto} from "../../../dto/salesObstacleDto";
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {SiteConstants} from "@constants/siteConstants";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'obstacles-strategy',
  templateUrl: './obstacles-strategy.component.html',
  styleUrls: ['./obstacles-strategy.component.css']
})
export class ObstaclesStrategyComponent implements OnInit {
  @Input() strategy
  @Input() obstacles: SalesObstacleDto[];
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  columnDefs: ColDef[];
  gridOptions: GridOptions
  GridCssStyle: string;
  showDialog: any;
  private mode: string;
   selectedObstacle: SalesObstacleDto;

  constructor(private crmService: CrmService, private Confirmation:ConfirmationService, private _messageService:MessageService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 200px;";
    this.columnDefs = this.createColumns();
  }

  addObstacle() {
    this.mode = 'add';
    this.showDialog = true;
    this.selectedObstacle = <SalesObstacleDto>{}
  }

  EditStrategyObstacle(data) {
    this.mode = 'edit';
    this.showDialog = true;
    this.selectedObstacle = data.rowData
  }

  deleteObstacle(data) {
    this.Confirmation.confirm({
      message: "Do you want to delete this Obstacle ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        let id=data.rowData.salesObstacleId
        this.crmService.DeleteObstacle(id).then(liste=>{
          this.refreshData.emit();
          this._messageService.add({severity: "success", detail: "Obstacle Has been Deleted"});

        })
      },
      reject: () => {},
    });

  }

  submitDialog(obstacle: any) {
    if (this.mode == 'add') {
      obstacle.strategyId = this.strategy;
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      obstacle.createdBy = user.userId;
      obstacle.modifiedBy = user.userId;
      obstacle.moduleReference = null;
      obstacle.salesObjectiveId = null;

      this.crmService.AddObstacle(obstacle).then(aka => this.refreshData.emit())
    } else {
      this.crmService.EditObstacle(obstacle).then(aka => this.refreshData.emit())

    }
  }

  hideDialog() {
    this.showDialog = false;
  }

  private createColumns() {
    return <ColDef[]>[
      {
        field: "obstacleType.codeName",
        headerName: "Type",
        width: 250
      },
      {
        field: "obstacleNote",
        headerName: "Note",
        width: 350
      },
      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.EditStrategyObstacle.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteObstacle.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }
}
