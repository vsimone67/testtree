import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { SiteConstants } from '@constants/siteConstants';
import { RateTableModel } from '@shared/models/RateTableModel'
import { AppSettingsService } from './app-settings.service';

@Injectable({
  providedIn: "root",
})

export class StandardRateService {

  private _standardRateUrl: string;
  constructor(private _httpService: HttpService,private _appSettingsService: AppSettingsService  ) {

    //this._standardRateUrl = `${environment.apiGatewayUrl}/${SiteConstants.standardRateController}`;
    this._standardRateUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.standardRateController}`;
  }

  async getRateTables() {
    return await this._httpService.getData<Array<RateTableModel>>(
      `${this._standardRateUrl}/GetRateTables`);

  }
}
