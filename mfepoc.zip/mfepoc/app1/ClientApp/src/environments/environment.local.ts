export const environment = {
  env: "local",
  production: false,
  standalone: true,
};
