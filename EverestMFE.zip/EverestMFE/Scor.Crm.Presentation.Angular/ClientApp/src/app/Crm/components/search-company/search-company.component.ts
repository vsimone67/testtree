import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {CrmService} from "../../service/CrmService";
import {CompanyDto} from "../../dto/companyDto";
import {MessageService, TreeNode} from "primeng/api";

@Component({
  selector: 'search-company',
  templateUrl: './search-company.component.html',
  styleUrls: ['./search-company.component.css']
})
export class SearchCompanyComponent implements OnInit {
  @Output() openCompany: EventEmitter<any> = new EventEmitter<any>();
  types: string[] = ['Company', 'Contact', 'AKA'];
  currentIndex = 0;
  searchCriteria: string = ""
  companies: Array<any>
  listCompanies: Array<any>
  expanded: boolean = false

  constructor(private crmService: CrmService, private notification: MessageService) {
  }

  ngOnInit(): void {
  }

  changetype() {
    this.currentIndex++;
    if (this.currentIndex > 2) this.currentIndex = 0;
  }

  async search() {
    if (this.currentIndex === 1) {
      this.notification.add(
        {severity: 'error', closable: true, detail: 'not supprted yet'}
      )
    } else {
      this.crmService.GetCompaniesByName(this.searchCriteria).then(companies => {
        this.prepareTree(companies)
      })
    }

  }

  prepareTree(companies) {
    this.companies = [];
    if (companies) {
      let root: TreeNode = {};
      root.label = "Companies";
      root.expanded = true;
      root.children = []
      companies.forEach((com: CompanyDto) => {
        let node: TreeNode = {};
        node.data = com.companyId;
        node.type = "url";
        node.label = com.companyName;
        node.children = [];
        let city = com.demographicInfoGroup?.address[0]?.city;
        let state = com.demographicInfoGroup?.address[0]?.state?.codeName;
        let address = "";
        if (city) address = address.concat(city).concat(",");
        if (city && state)
          if (state) address = address.concat(state)
        if (city && state) {
          let addressNode: TreeNode = {label: address};
          node.children.push(addressNode);
        }
        let numberphone
        if (com.demographicInfoGroup)
          numberphone = com.demographicInfoGroup.phoneNumber.filter(ph => ph.isPrimaryPhone)[0]?.phoneNumber1
        if (numberphone) {
          let phone: TreeNode = {label: numberphone};
          node.children.push(phone);
        }

        let contacts: TreeNode = {label: "Contacts"};
        contacts.children = [];
        com.userRelationship.forEach(user => {
          let node: TreeNode = {};
          node.data = user.employeeId;
          node.type = "urlcontact";
          node.label = user.employee.lastName.concat(',').concat(user.employee.firstName);
          node.children = [{
            label: user.employee.jobTitle
          }];
          contacts.children.push(node);
        });
        node.children.push(contacts)

        root.children.push(node)
      });
      this.companies.push(root)
    }

  }

  open(company) {
    this.openCompany.emit(company)
  }

  expand() {
    this.expanded = !this.expanded;
    this.companies.forEach(node => {
      this.expandRecursive(node, this.expanded);
    });
  }

  openContact(data: any) {

  }

  private expandRecursive(node: TreeNode, isExpand: boolean) {
    if (node.label === "Companies") node.expanded = true;
    else node.expanded = isExpand;
    if (node.children) {
      node.children.forEach(childNode => {
        this.expandRecursive(childNode, isExpand);
      });
    }
  }
}
