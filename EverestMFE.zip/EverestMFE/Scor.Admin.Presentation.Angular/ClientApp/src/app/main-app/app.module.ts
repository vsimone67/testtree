import {
  ApplicationRef,
  APP_INITIALIZER,
  CUSTOM_ELEMENTS_SCHEMA,
  Injector,
  NgModule,
} from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';
import { AuthModule } from '@auth/auth.module';
import { AuthenticationService } from '@auth/services/authentication.service';
import { environment } from '@environment/environment';
import { SharedModule } from '@shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { initApp } from './initApp';
import { AppSettingsService } from '@scor/common';
import { RatesModule } from '../rates/rates.module';
import { GroupsModule } from '../groups/groups.module';
import { RegionModule } from '../region/region.module';
import { CoreComponent } from './core/core.component';
import { EmptyComponent } from './empty/empty.component';
import { CodeModule } from '../code/code.module';
import { OpsteamModule } from '../opsteam/opsteam.module';
import { RolesModule } from '../roles/roles.module';

@NgModule({
  declarations: [AppComponent, CoreComponent, EmptyComponent],
  imports: [
    BrowserModule,
    SharedModule,
    AuthModule,
    AppRoutingModule,
    RatesModule,
    GroupsModule,
    RegionModule,
    CodeModule,
    OpsteamModule,
    RolesModule,
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      deps: [AppSettingsService, AuthenticationService],
      multi: true,
    },
  ],
  // schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [AppComponent],
})
export class AppModule {
  constructor(private injector: Injector) {}

  ngDoBootstrap(appRef: ApplicationRef) {
    // if you are testing locally bootstrap the AppComponent, if not create custom elements
    if (environment.standalone) {
      appRef.bootstrap(AppComponent);
    } else {
      const appElement = createCustomElement(AppComponent, {
        injector: this.injector,
      });
      customElements.define('admin-app', appElement);
    }
  }
}
