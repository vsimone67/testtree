import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpportunityStrategyComponent } from './opportunity-strategy.component';

describe('OpportunityStrategyComponent', () => {
  let component: OpportunityStrategyComponent;
  let fixture: ComponentFixture<OpportunityStrategyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpportunityStrategyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpportunityStrategyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
