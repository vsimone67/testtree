export function formatBooleanToWord(data: any) {
  return data.value ? 'Yes' : 'No';
}
