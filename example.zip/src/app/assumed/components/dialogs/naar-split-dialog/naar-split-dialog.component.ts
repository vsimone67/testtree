import { Component, Input, OnInit } from '@angular/core';
import { CompanyModel } from '@assumed/models/companyModel';
import { RetroQuotePlanModel } from '@retro/models/retroQuotePlanModel';
import { SplitModel } from '@retro/models/SplitModel';
import { RetroService } from '@retro/services/retro.service';
import { VwTreatySearchRetro } from '@shared/models/VwTreatySearchRetro';
import { TreatyModel } from '@shared/models/TreatyModel';
import { CrmService } from '@shared/services/crm.service';
import { TreatyService } from '@shared/services/treaty.service';
import { EditDialogBase } from '../EditDialogBase';
import { RetroQuoteBandModel } from '@retro/models/RetroQuoteBandModel';

@Component({
  selector: 'naar-split-dialog',
  templateUrl: './naar-split-dialog.component.html',
  styleUrls: ['./naar-split-dialog.component.css']
})
export class NaarSplitDialogComponent extends EditDialogBase<SplitModel> implements OnInit {

  legalEntityList: Array<CompanyModel>;
  companyList: Array<CompanyModel>;
  selectedEntity: CompanyModel;
  selectedCompany: CompanyModel;
  treatyList: Array<VwTreatySearchRetro>;
  selectedTreaty: VwTreatySearchRetro;
  quoteList: Array<TreatyModel>;
  selectedQuote: TreatyModel;
  quotePlanList: Array<RetroQuotePlanModel>;
  selectQuotePlan: RetroQuotePlanModel;
  bandList: Array<RetroQuoteBandModel>;
  selectedBand: RetroQuoteBandModel;
  effectiveDate: Date;
  cancelDate: Date;

  constructor(private _crmService: CrmService, private _treatyService: TreatyService, private _retroService: RetroService) { super();}

  ngOnInit(): void {
    this.loadDropDowns();
  }

  loadDropDowns() {

    this._crmService.GetAllLegalEntities().then((data) => this.legalEntityList = data);
    this._crmService.getAllCompanies().then((data) => this.companyList = data);

  }

  loadTreatyDropdown() {
    this._treatyService.getTreatyForCompanies(this.selectedCompany.companyId).then((data) => this.treatyList = data);
  }

  loadQuote() {
    this._treatyService.getQuotesForTreaty(this.selectedTreaty.treatyId).then((data) => this.quoteList = data);
  }

  loadQuoteRetroPlan() {
    this._retroService.getQuotePlan(this.selectedQuote.quoteId).then((data) => this.quotePlanList = data);
  }

  loadRetroBand() {
    this._retroService.getRetroBand(this.selectQuotePlan.retroQuotePlanId).then((data) => this.bandList = data);
  }

  saveSplit() {
    this.dialogData.payorLegalEntityId = this.selectedEntity.companyId;
    this.dialogData.companyId = this.selectedCompany.companyId;
    this.dialogData.retroTreatyId = this.selectedTreaty.treatyId;
    this.dialogData.retroQuoteId = this.selectedQuote.quoteId;
    this.dialogData.retroQuotePlanId = this.selectQuotePlan.retroQuotePlanId;
    this.dialogData.retroQuoteBandId = this.selectedBand.retroQuoteBandId;
    this.submitDialog();
  }

}
