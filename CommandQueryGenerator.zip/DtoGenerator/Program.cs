﻿using System.Linq;
using System;
using System.IO;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Collections.Generic;

namespace DtoGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourcePath = @"C:\VS2019\Playground\ScaffoldDb\ScaffoldDb\Entities\pdaaf\";
            string destPath = @"C:\VS2019\Playground\ScaffoldDb\ScaffoldDb\dto\pdaaf";  // make sure you create the filename from the passed in file
            string slimPath = @"C:\VS2019\Playground\ScaffoldDb\ScaffoldDb\dto\pdaafSlim";  // make sure you create the filename from the passed in file
            string mapperFile = @"C:\VS2019\Playground\ScaffoldDb\ScaffoldDb\mapper\pdaaf\mapper.cs";

            var files = Directory.GetFiles(sourcePath);

            IDictionary<string, string> mapper = new Dictionary<string, string>();  // create mapper dictionary to keep track of all DTO's/Entities

            foreach (var file in files)
            {
                var sourceFileName = file;
                //var sourceFileName = @"C:\VS2019\Playground\ScaffoldDb\ScaffoldDb\Entities\Crm\MarketingListContact.cs";
                var destFileName = $"{destPath}\\{Path.GetFileNameWithoutExtension(file)}Dto.cs";
                var slimDestFileName = $"{slimPath}\\{Path.GetFileNameWithoutExtension(file)}SlimDto.cs";

                using (StreamReader sr = File.OpenText(sourceFileName))
                {
                    var sourceCode = sr.ReadToEnd();

                    var tree = CSharpSyntaxTree.ParseText(sourceCode);
                    var root = (CompilationUnitSyntax)tree.GetRoot();

                    // get all properties in class
                    var codeProperties = root.DescendantNodes().OfType<PropertyDeclarationSyntax>().ToList();
                    // get class declarations
                    var codeClasses = root.DescendantNodes().OfType<ClassDeclarationSyntax>().ToList();

                    string className = codeClasses[0].Identifier.ToString(); // there is only one class per file so we can just get the first instance
                    string dtoName = className + "Dto";  // create the DTO name
                    string slimName = className + "SlimDto";  // create the DTO name

                    mapper.Add(className, dtoName);

                    // replace class name with dto name
                    sourceCode = sourceCode.Replace($"public partial class {className}", $"public partial class {dtoName}");
                    // replace constructor with DTO
                    sourceCode = sourceCode.Replace($"public {className}", $"public {dtoName}");
                    // replace namespace
                    sourceCode = sourceCode.Replace("Domain.Entities", "Application.Dto");

                    // iterate through all the properites
                    foreach (var prop in codeProperties)
                    {
                        if (prop.Modifiers.Any(exp => exp.ValueText == "virtual"))  // navigation properties are denoted with virtial keyword
                        {
                            string property = prop.Identifier.ToString();  // property name
                            string propertyType = prop.Type.ToString(); // property type
                            string classNameStripped = propertyType.Replace("ICollection<", "");
                            classNameStripped = classNameStripped.Replace(">", "");
                            string newProperty;

                            if (propertyType.Contains($"ICollection"))
                            {
                                newProperty = propertyType.Replace($"virtual ICollection<", $"virtual {propertyType + "Dto"}");
                                newProperty = propertyType.Replace(">", "");
                                string newPropertyType = propertyType.Replace(newProperty, newProperty + "Dto");
                                string hashSet = $"HashSet<{classNameStripped}>";
                                string newHasSet = $"HashSet<{classNameStripped + "Dto"}>";
                                sourceCode = sourceCode.Replace(propertyType, newPropertyType);
                                sourceCode = sourceCode.Replace(hashSet, newHasSet);
                            }
                            else
                            {
                                if (!sourceCode.Contains("virtual " + propertyType + "Dto"))
                                {
                                    sourceCode = sourceCode.Replace($"virtual {propertyType} ", $"virtual {propertyType + "Dto"} ");
                                }
                            }

                            if (!mapper.ContainsKey(classNameStripped))
                            {

                                mapper.Add(classNameStripped, classNameStripped + "Dto");
                            }
                        }

                    }

                    File.WriteAllText(destFileName, sourceCode);  // write the DTO File   

                    sourceCode = sourceCode.Replace("Dto", "SlimDto");

                    File.WriteAllText(slimDestFileName, sourceCode);  // write the DTO File   


                }
            }
            // all files have been processed, write out the mapping profile for everything
            var mapperString = "";
            mapper.ToList().ForEach(exp => mapperString += $"CreateMap<{exp.Key}, {exp.Value}>();\n");
            File.WriteAllText(mapperFile, mapperString);
            Console.WriteLine("Completed...");

        }

    }

    // class ClassVirtualizationVisitor : CSharpSyntaxRewriter
    // {
    //     public ClassVirtualizationVisitor()
    //     {
    //         Classes = new List<ClassDeclarationSyntax>();
    //     }

    //     public List<ClassDeclarationSyntax> Classes { get; set; }

    //     public override SyntaxNode VisitClassDeclaration(ClassDeclarationSyntax node)
    //     {
    //         node = (ClassDeclarationSyntax)base.VisitClassDeclaration(node);
    //         Classes.Add(node); // save your visited classes
    //         return node;
    //     }
    // }
}
