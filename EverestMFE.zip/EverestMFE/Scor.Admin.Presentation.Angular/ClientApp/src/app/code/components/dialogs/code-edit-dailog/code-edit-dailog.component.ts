import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChange,
} from '@angular/core';

import { EditDialogBase } from '../EditDialogBase';

import { isNumeric } from 'rxjs/util/isNumeric';
import { INPUTNUMBER_VALUE_ACCESSOR } from 'primeng/inputnumber/public_api';
import { CodeModel } from 'src/app/code/models/CodeModel';
import { CodeService } from 'src/app/code/services/code.service';

@Component({
  selector: 'app-code-edit-dailog',
  templateUrl: './code-edit-dailog.component.html',
  styleUrls: ['./code-edit-dailog.component.css'],
})
export class CodeEditDailogComponent
  extends EditDialogBase<CodeModel>
  implements OnInit
{
  @Input() codeCategoryId: string;
  @Input('mode') mode: string;
  codeId: string;
  errors: { key: string; value: string }[];
  isNew: boolean = false;
  holdCodeModel: CodeModel;
  showDialog: boolean = true;

  constructor(private _codeService: CodeService) {
    super();
  }

  ngOnInit(): void {
    console.log(this.dialogData);
    console.log(this.mode);
    if (this.mode === 'Add') {
      console.log('ng init New');
      console.log(this.codeCategoryId);
      this.codeId = '00000000-0000-0000-0000-000000000000';
      this.dialogData.rowStatusId = 'true';
      // this.newCodeModel.codeCategoryId = this.codeCategoryId;
      // this.newCodeModel.codeDescription = "";
      console.log(this.dialogData);
    } else {
      console.log(this.dialogData.codeId);
      this.codeId = this.dialogData.codeId;
      this.dialogData.rowStatusId =
        this.dialogData.rowStatusId.toLocaleUpperCase() ===
        '0C84441F-9FFF-49ED-8E26-7BCE4259EC07'
          ? 'true'
          : 'false';
      this.holdCodeModel = Object.assign({}, this.dialogData);
      console.log(this.holdCodeModel);
    }
  }

  async validateData() {
    console.log('Validate Data');
    this.errors = [];
    let validated: boolean = true;

    var codeList = await this._codeService.getCodeValueByCategory(
      this.dialogData.codeCategoryId
    );
    var codeNameList = codeList.filter(
      (x) => x.codeName.toLowerCase() == this.dialogData.codeName.toLowerCase()
    );
    var codeValueList = codeList.filter(
      (x) =>
        x.codeValue.toLowerCase() == this.dialogData.codeValue.toLowerCase()
    );

    console.log(codeNameList);
    console.log(codeValueList);
    if (this.mode === 'Add') {
      console.log('IsNew Validation');
      if (codeNameList.length > 0) {
        this.errors.push({
          key: 'CodeName',
          value: 'Code Name already Exists',
        });
        validated = false;
      }
      if (codeValueList.length > 0) {
        this.errors.push({
          key: 'CodeValue',
          value: 'Code Value already Exists',
        });
        validated = false;
      }
      this.isNew = false;
    } else {
      console.log('code name');
      console.log(this.dialogData.codeName + ':' + this.holdCodeModel.codeName);
      console.log(codeNameList.length);
      console.log('END');
      if (
        this.dialogData.codeName.toLowerCase() !=
          this.holdCodeModel.codeName.toLowerCase() &&
        codeNameList.length > 0
      ) {
        this.errors.push({
          key: 'CodeName',
          value: 'Code Name already Exists',
        });
        validated = false;
      }
      if (
        this.dialogData.codeValue.toLowerCase() !=
          this.holdCodeModel.codeValue.toLowerCase() &&
        codeValueList.length > 0
      ) {
        this.errors.push({
          key: 'CodeValue',
          value: 'Code Value already Exists',
        });
        validated = false;
      }
    }

    if (!isNumeric(this.dialogData.sequenceNumber)) {
      this.errors.push({
        key: 'SequenceNumber',
        value: 'Sequence must be Numeric',
      });
      validated = false;
    }
    if (
      this.dialogData.sequenceNumber < 0 ||
      this.dialogData.sequenceNumber > 255
    ) {
      this.errors.push({
        key: 'SequenceNumber',
        value: 'Sequence must be between 0 and 255',
      });
      validated = false;
    }

    console.log(this.errors.length);
    if (validated) {
      this.submitDialog();
    } else {
      console.log('error');
    }
  }
  cancelDialog() {
    console.log('Cancel Dialog');
    this.hideDialog();
  }
  IsRowStatusActive(val: string) {
    var tf;
    console.log(val);
    tf = val.toLocaleUpperCase() === '0C84441F-9FFF-49ED-8E26-7BCE4259EC07';
    console.log(tf);
    return tf;
  }
}
