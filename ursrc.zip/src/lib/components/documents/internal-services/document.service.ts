import { Injectable } from '@angular/core';
import { HttpService } from '../../../services/http/http-service.service';
import { Observable } from 'rxjs';
import { HttpEvent } from '@angular/common/http';
import { serviceBase } from './servicebase';
import { DocumentDto } from '../models/documentModel';

@Injectable({
  providedIn: 'root',
})
export class DocumentService extends serviceBase {
  private _documentUrl!: string;

  get documentUrl(): string {
    return this._documentUrl;
  }
  set documentUrl(value: string) {
    this._documentUrl = value;
  }

  constructor(private httpService: HttpService) {
    super(httpService);
  }

  public async getDocumentByGroup(groupId: string) {
    return await this.getData<Array<DocumentDto>>(
      `${this._documentUrl}/GetDocumentsByGroup/${groupId}`
    );
  }

  public uploadFile(payload: FormData) {
    return this._httpService.uploadfile(
      `${this._documentUrl}/UploadFile/`,
      payload
    );
  }

  public downloadFile(
    docUrl: string,
    userId: string
  ): Observable<HttpEvent<Blob>> {
    return this._httpService.getBlob(
      `${this._documentUrl}/DownloadFile/${docUrl}/${userId}`
    );
  }

  public async deleteDocument(documentId: string, userId: string) {
    return await this.getData<string>(
      `${this._documentUrl}/DeleteDocument/${documentId}/${userId}`
    );
  }
}
