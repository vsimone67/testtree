import { EmployeeUnderwritingDto } from './employeeUnderwritingDto';
import { CompanyDto } from './companyDto';

export interface EmployeeUnderwritingExcludedCompaniesDto {
    employeeId: string;
    excludedCompanyId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string | null;
    employee: EmployeeUnderwritingDto;
    excludedCompany: CompanyDto;
}