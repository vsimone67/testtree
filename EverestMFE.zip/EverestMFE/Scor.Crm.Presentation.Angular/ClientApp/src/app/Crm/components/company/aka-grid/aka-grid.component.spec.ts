import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AkaGridComponent } from './aka-grid.component';

describe('AkaGridComponent', () => {
  let component: AkaGridComponent;
  let fixture: ComponentFixture<AkaGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AkaGridComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AkaGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
