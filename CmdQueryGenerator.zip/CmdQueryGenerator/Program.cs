﻿using System;

namespace CmdQueryGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourceFileName = args[0];
            string methodToGenerate = "";

            if (args.Length == 2)
            {
                methodToGenerate = args[1];
            }

            CmdQueryScaffold scaffold = new CmdQueryScaffold(sourceFileName, methodToGenerate);
            scaffold.GenerateFiles();

        }
    }
}
