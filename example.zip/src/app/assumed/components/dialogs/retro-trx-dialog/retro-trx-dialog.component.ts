import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {EditDialogBase} from "@assumed/componentsdialogs/EditDialogBase";
import {RetroTransactionHistoryUpdateModel} from "@retro/models/RetroTransactionHistoryUpdateModel";
import {formatDate} from "@shared/componentsgrid/formatters/formatDate";
import {GetNotesByParentAndGroupCriteria} from "@shared/models/GetNotesByParentAndGroupCriteria";
import {NoteModel} from "@shared/models/NoteModel";
import {CommonService} from "@shared/service/common.service";

@Component({
  selector: 'retro-trx-dialog',
  templateUrl: './retro-trx-dialog.component.html',
  styleUrls: ['./retro-trx-dialog.component.css']
})
export class RetroTrxDialogComponent extends EditDialogBase<RetroTransactionHistoryUpdateModel> implements OnInit, OnChanges {
  columnList: any;
  noteList: Array<NoteModel>;
  @Input() showNotes: boolean ;
  transactionType: string=null;

  constructor(private _commonService: CommonService) {
    super();
  }

  getColumns() {
    return [
      {
        headerName: "Note",
        field: "noteText"
      },
      {
        headerName: "Note Date",
        field: "noteCreateDate",
        valueFormatter: formatDate

      },
      {
        headerName: "Created By",
        cellRenderer: (params) => `${params.data.noteCreatedByFirstName} ${params.data.noteCreatedByLastName}`

      }
    ];
  }

  ngOnInit(): void {
    this.columnList = this.getColumns();
    this._commonService.getRetroTransactionTypes().then((list:any)=>{
      this.transactionType = list.filter(type=>{

        return type.codeId === this.dialogData.TransactionTypeId
      })[0].codeName

    })
    if(this.showNotes){
      var criteria = <GetNotesByParentAndGroupCriteria>{ParentId: this.dialogData.CessionId, NoteGroup: "Cession Notes"};
      this._commonService.getNotes(criteria).then((data) =>{
        this.noteList = data;
      } );
    }else {
      this.noteList = [];
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
  }

  cancelDialog(){
    this.showDialog = false;
    this.hideDialog();
  }
}
