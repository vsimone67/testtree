export interface ApplicationRoleModel {
  application: string;
  role: string;
}
