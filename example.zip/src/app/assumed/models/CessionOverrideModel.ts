export interface CessionOverrideModel {
  cessionOverrideId: string;
  cessionId: string;
  overrideScorgradedLimitScheduleId: string | null;
  overrideScorretentionAmount: number | null;
  retroTableRating: number | null;
  retroHowCededTypeId: string | null;
  overrideAllowRecapture: boolean | null;
  createDate: Date | string;
  createdBy: string | null;
  modifiedBy: string | null;
  modifiedDate: Date | string | null;
  rowStatus: boolean | null;
  rateTableId: string | null;
  rateFactor: number | null;
  insuredIssueAge: number | null;
  secondInsuredIssueAge: number | null;
  scorRetentionSequenceNumber: number | null;
  jointEqualAge: number | null;
  retroRiskClassId: string | null;
  secondInsuredRetroRiskClassId: string | null;
  isEorprocessingLocked: boolean | null;
  everstCessionNumber: number;
  overrideBaseReinsuredAmount : number | null;
  retroTypeId : string | null;
  ageBasisTypeId: string | null;
}
