export interface NoteModel {
  parentId: string;
  noteType: string;
  nodeId: string;
  noteDate: Date | string | null;
  noteDescription: string | null;
  noteGroupId: string;
  noteText: string;
  noteCreateDate: Date | string | null;
  noteCreatedByFirstName: string | null;
  noteCreatedByLastName: string | null;
  noteModifiedByFirstName: string | null;
  noteModifiedByLastName: string | null;
  createdBy: string;
  creator: string | null;
}
