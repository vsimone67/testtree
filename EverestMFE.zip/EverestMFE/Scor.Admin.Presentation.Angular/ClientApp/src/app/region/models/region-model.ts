export interface RegionModel {
    codeId: string;
    codeName: string;
}