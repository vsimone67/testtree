export interface GeneraliDivisionDto{
  codeId: string|null;
  codeCategoryId: string|null;
  codeDescription: string|null;
  codeName: string|null;
  codeValue: string|null;
  isDefault: boolean | null;
  sequenceNumber: number | null ;
  createDate: Date | null ;
  createdBy: string|null;
  modifiedDate: Date | null;
  modifiedBy: string|null;
  moduleReference: string|null;
  rowStatusId:string|null;
}
