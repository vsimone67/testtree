import { Component, OnInit } from '@angular/core';

@Component({
  template: ''
})
export class EmptyComponent {
}
