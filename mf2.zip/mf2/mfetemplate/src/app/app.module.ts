import { ApplicationRef, APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AuthModule } from '@auth/auth.module';
import { AuthenticationService } from '@auth/services/authentication.service';
import { environment } from '@environment/environment';
import { AppSettingsService } from '@shared/services/app-settings.service';
import { SharedModule } from '@shared/shared.module';
import { AppComponent } from './app.component';
import { CoreComponent } from './core/core.component';
import { EmptyComponent } from './empty/empty.component';
import { Page1Component } from './page1/page1.component';

export function initApp(appSettings: AppSettingsService,authService: AuthenticationService) {
  return () => {
    return new Promise<void>((resolve) => {
      appSettings
        .LoadConfigData(
          `assets/app-settings/appsettings.${environment.env}.json`
        ) //load app config file
        //.then(() => authService.login()) // have the user loging  **UNCOMMENT THIS!!!!!!!! ******
        .then(() => resolve()) // all is done return control back to angular
        .catch((error) =>
          alert(
            "Error connecting to authorization service...Please make sure it is running, message from server: " +
              error.message
          )
        );
    });
  };
}


@NgModule({
  declarations: [
    AppComponent,
    Page1Component,
    CoreComponent,
    EmptyComponent,
  ],
  imports: [
    BrowserModule,
    SharedModule,
    AuthModule,
    RouterModule.forRoot(
      [
        {
          path: 'mfetemplate', component: CoreComponent, children: [
            { path: 'page1', component: Page1Component, data: { breadcrumb: "Page 1" }, },
            { path: 'page2', component: Page1Component },
          ],
        },
        { path: '**', component: EmptyComponent },
      ],
      { useHash: true }
    ),
  ],
  providers: [{
      provide: APP_INITIALIZER,
      useFactory: initApp,
      deps: [AppSettingsService, AuthenticationService],
      multi: true,
    }],
  //schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [AppComponent],
})
export class AppModule  {
  constructor(private injector: Injector) {}

  ngDoBootstrap(appRef: ApplicationRef) {

    // if you are testing locally bootstrap the AppComponent, if not create custom elements
    if (environment.standalone) {
      appRef.bootstrap(AppComponent);
    } else {
      const appElement = createCustomElement(AppComponent, {injector: this.injector});
      customElements.define('mfetemplate-app', appElement);
    }
  }
}
