export interface CountryModel {
    regionsCountryRelationshipId: string;
    regionId: string;
    regionName: string;
    countryId: string;
    countryName: string;
}