import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {StrategyDto} from "../../../dto/strategyDto";
import {SiteConstants} from "@constants/siteConstants";
import {CrmService} from "../../../service/CrmService";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'strategy-company',
  templateUrl: './strategy-company.component.html',
  styleUrls: ['./strategy-company.component.css']
})
export class StrategyCompanyComponent implements OnInit {
  @Input() strategy: StrategyDto[];
  @Input() company:string;
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = false
  showDialogEdit: boolean = false
  selectedStrategy: StrategyDto;
  activeindex: number = 0;

  constructor(private crmService:CrmService, private confirm:ConfirmationService,
              private _messageService:MessageService) {
  }

  ngOnInit(): void {
  }

  refresh() {
    this.refreshData.emit()
  }

  addStrategy() {
    this.showDialog = true;
    this.showDialogEdit=false;
    this.selectedStrategy = <StrategyDto>{}
  }

  confirmAdd(strategy: StrategyDto) {
    let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
    strategy.createdBy=user.userId;
    strategy.modifiedBy=user.userId;
    this.crmService.AddStrategy(strategy).then(st=>this.refreshData.emit())
    this.hideDialog()
  }
  confirmEdit(strategy: StrategyDto) {
    let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
    strategy.modifiedBy=user.userId;
    strategy.companyId=this.company;
    this.crmService.EditStrategy(strategy).then(st=>this.refreshData.emit());
    this.hideDialog()
  }

  editStrategy() {
    this.showDialogEdit = true;
    this.showDialog=false;
    this.selectedStrategy = this.strategy[0]
  }

  hideDialog() {
    this.showDialog=false;
    this.showDialogEdit=false;
  }

  deleteStrategy() {
    if(this.strategy[0]){
      this.confirm.confirm({
        message: "Do you want to delete this Strategy ?",
        header: "Delete Confirmation",
        icon: "pi pi-info-circle",
        rejectButtonStyleClass: "cleardata",
        accept: () => {
          let id=this.strategy[0].strategyId
          this.crmService.DeleteStrategy(id).then(liste=>{
            this.refreshData.emit()
            this._messageService.add({severity: "success", detail: "Strategy Has been Deleted"});
          })
        },
        reject: () => {},
      });
    }

  }
}
