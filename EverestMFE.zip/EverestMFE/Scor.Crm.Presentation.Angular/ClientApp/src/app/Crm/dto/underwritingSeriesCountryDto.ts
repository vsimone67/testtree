import { UnderwritingSeriesDto } from './underwritingSeriesDto';
import { EmployeeDto } from './employeeDto';

export interface UnderwritingSeriesCountryDto {
    seriesId: string;
    countryCodeId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string;
    mibauthorized: boolean | null;
    seriesSupervisorEmployeeId: string | null;
    jumboAmountLimit: number | null;
    underwriterAssignable: boolean;
    overLimitAuthorizationId: string | null;
    isDecisionManuallyHandled: boolean | null;
    series: UnderwritingSeriesDto;
    seriesSupervisorEmployee: EmployeeDto;
}