import { Component, OnInit, Input } from '@angular/core';
import { DialogBase } from '@assumed/components/dialogs/dialog-base';
import { RetroQuoteBandRateModel } from '@retro/models/retroQuoteBandRateModel';
import { ColDef } from 'ag-grid-community';

@Component({
  selector: 'retro-quote-band-rate-dialog',
  templateUrl: './retro-quote-band-rate-dialog.component.html',
  styleUrls: ['./retro-quote-band-rate-dialog.component.css']
})
export class RetroQuoteBandRateComponent extends DialogBase implements OnInit {

  @Input() RetroQuoteBandRate: Array<RetroQuoteBandRateModel>;
  columnDefs: Array<ColDef>;
  GridCssStyle: string;
  constructor() { super() }

  ngOnInit(): void {
    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 65vh;";
  }

  createColumnDefs() {
    return [
      {
        headerName: "Min Duration",
        field: "minDuration"
      },
      ,
      {
        headerName: "Max Duration",
        field: "maxDuration"
      },
      {
        headerName: "Min Issue Age",
        field: "minIssueAge"
      },
      {
        headerName: "Max Issue Age",
        field: "maxIssueAge"
      },
      {
        headerName: "UW Class Name",
        field: "uwClassName"
      },
      {
        headerName: "Pricing Rate",
        field: "pricingRate"
      },
      ,
      {
        headerName: "Pricing Rate Male",
        field: "retroPremiumRateMalePricingRate"
      },
      {
        headerName: "Pricing Rate Female",
        field: "retroPremiumRateFemalePricingRate"
      },
      {
        headerName: "Pricing Rate Gender",
        field: "retroPremiumRateBothGenderPricingRate"
      },
      {
        headerName: "Gender Code Name",
        field: "retroPremiumRateGenderTypeIdCodeName"
      },
      {
        headerName: "Rate Table Name",
        field: "rateTableName"
      },




    ];
  }

}
