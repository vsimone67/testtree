import { Component, OnInit, ViewChild, ComponentFactoryResolver, ViewContainerRef, Type, OnChanges, SimpleChange, Input, Output, EventEmitter } from "@angular/core";
import { HistoryGridComponent } from '../grids/history-grid/history-grid.component';
import { TransactionGridComponent } from '../grids/transaction-grid/transaction-grid.component';
import { StackGridComponent } from '@pricing/components/grids/stack-grid/stack-grid.component';
import { PoolGridComponent } from '@pricing/components/grids/pool-grid/pool-grid.component';
import { RetroGridComponent } from '@retro/components/grids/retro-grid/retro-grid.component';
import { SplitsGridComponent } from '@retro/components/grids/splits-grid/splits-grid.component';
import { CessionOverrideModel } from '@assumed/models/CessionOverrideModel';
import { GraphEventModel } from '@assumed/models/GraphEventModel';
import { NodeConstants } from '@constants/nodeConstants';

@Component({
  selector: 'cession-view',
  templateUrl: './cession-view.component.html',
  styleUrls: ['./cession-view.component.css']
})
export class CessionViewComponent implements OnInit, OnChanges {

  @ViewChild('gridContainer', { read: ViewContainerRef }) container: ViewContainerRef;
  @Input() nodeClickEvent;
  @Output() gridHideEvent: EventEmitter<string> = new EventEmitter<string>();

  showOverride: boolean = false;
  showClaim: boolean = false;
  overRideData: CessionOverrideModel;
  claimCessionId: string;

  activeGrids = [];  // holds active dynamic grids (shown on screen)

  constructor(private componentFactoryResolver: ComponentFactoryResolver) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {

    if (changes.nodeClickEvent.currentValue != undefined) {
      this.displayNodeData(changes.nodeClickEvent.currentValue);
    }

  }

  displayNodeData(event: GraphEventModel) {
    switch (event.data.metaData) {
      case NodeConstants.transaction: {

        this.displayTransactions(event);
        break;
      }
      case NodeConstants.history: {
        this.displayHistory(event);
        break;
      }
      case NodeConstants.retro: {
        this.displayRetro(event);
        break;
      }
      case NodeConstants.pool: {
        this.displayPool(event);
        break;
      }
      case NodeConstants.stack: {
        this.displayStack(event);
        break;
      }
      case NodeConstants.override: {
        this.displayOverride(event);
        break;
      }
      case NodeConstants.split: {
        this.displaySplit(event);
        break;
      }
      case NodeConstants.claim: {
        this.displayClaim(event);
        break;
      }
    }
  }

  displayOverride(data: GraphEventModel) {
    this.showOverride = true;
    this.overRideData = <CessionOverrideModel>data.data.payload;
    this.overRideData.everstCessionNumber = data.data.everestCessionNumber;
  }
  async displayStack(data: GraphEventModel) {

    // // show stack grid on page (dynamic)
    var stackGrid = this.addGrid(StackGridComponent);
    stackGrid.instance.EventData = data;
    stackGrid.instance.hidetable.subscribe(v => this.hideStackGrid(event));
  }
  async displayPool(data: GraphEventModel) {

    // // show pool grid on page (dynamic)
    var poolGrid = this.addGrid(PoolGridComponent);
    poolGrid.instance.EventData = data;
    poolGrid.instance.hidetable.subscribe(v => this.hidePoolGrid(event));
  }

  async displayRetro(data: GraphEventModel) {

    // // show retro grid on page (dynamic)
    var retroGrid = this.addGrid(RetroGridComponent);
    retroGrid.instance.EventData = data;
    retroGrid.instance.hidetable.subscribe(v => this.hideRetroGrid(event));
  }

  async displaySplit(data: GraphEventModel) {

    // // show  split grid on page (dynamic)
    var splitGrid = this.addGrid(SplitsGridComponent);
    splitGrid.instance.EventData = data;
    splitGrid.instance.hidetable.subscribe(v => this.hideSplitGrid(event));
  }

  displayHistory(data: GraphEventModel) {

    // show history grid on page (dynamic)
    var historyGrid = this.addGrid(HistoryGridComponent);
    historyGrid.instance.EventData = data;
    historyGrid.instance.hidetable.subscribe(v => this.hideHistoryGrid(event));
  }

  displayTransactions(data: GraphEventModel) {

    // show txn grid on page (dynamic)
    var tnxGrid = this.addGrid(TransactionGridComponent);
    tnxGrid.instance.EventData = data;
    tnxGrid.instance.hidetable.subscribe(v => this.hideTxnGrid(event));
  }
  async displayClaim(data: GraphEventModel) {
    this.claimCessionId = data.data.payload.cessionId;
    this.showClaim = true;

  }

  //******END Display grids/dialog

  // *******Hide grids/dialog

  hideHistoryGrid(event) {
    this.removeGrid(HistoryGridComponent);
    this.gridHideEvent.emit(NodeConstants.history);
  }

  hideTxnGrid(event) {
    this.removeGrid(TransactionGridComponent);
    this.gridHideEvent.emit(NodeConstants.transaction);
  }

  hideStackGrid(event) {
    this.removeGrid(StackGridComponent);
    this.gridHideEvent.emit(NodeConstants.stack);
  }

  hidePoolGrid(event) {
    this.removeGrid(PoolGridComponent);
    this.gridHideEvent.emit(NodeConstants.pool);
  }

  hideRetroGrid(event) {
    this.removeGrid(RetroGridComponent);
    this.gridHideEvent.emit(NodeConstants.retro);
  }

  hideSplitGrid(event) {
    this.removeGrid(SplitsGridComponent);
    this.gridHideEvent.emit(NodeConstants.split);
  }

  overrideHidden(event) {
    this.showOverride = false;
  }

  hildeClaimDialog(event) {
    this.showClaim = false;
  }
  // **** End Hide grids/dialog

  findGrid(componentClass: Type<any>) {
    return this.activeGrids.find((component) => component.instance instanceof componentClass);
  }

  // ***** Dynamic Grid Add/Delete
  addGrid(componentClass: Type<any>) {

    // remove the grid first (if exist)
    this.removeGrid(componentClass);

    // Create component dynamically inside the ng-template
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentClass);
    const component = this.container.createComponent(componentFactory, 0);


    // Push the component so that we can keep track of which components are created
    this.activeGrids.push(component);

    return component;
  }

  removeGrid(componentClass: Type<any>) {
    // Find the component
    const component = this.activeGrids.find((component) => component.instance instanceof componentClass);
    const componentIndex = this.activeGrids.indexOf(component);

    if (componentIndex !== -1) {
      // Remove component from both view and array
      this.container.remove(this.container.indexOf(component.hostView));
      this.activeGrids.splice(componentIndex, 1);
    }

  }
  // ***** End Dynamic Grid Add/Delete

  clearAllGrids() {
    this.container.clear();
    this.activeGrids = [];
  }

}
