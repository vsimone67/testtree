import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CrmService} from "../../../../service/CrmService";
import {AddressDto} from "../../../../dto/addressDto";

@Component({
  selector: 'address-dialog',
  templateUrl: './address-dialog.component.html',
  styleUrls: ['./address-dialog.component.css']
})
export class AddressDialogComponent implements OnInit {
  @Input() address : AddressDto
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;
  states;
  countries;
  provinces
  types
  constructor(private crmService:CrmService) { }

  ngOnInit(): void {
    this.crmService.GetAddressTypeCodes().then(typesOb => {
      this.types = [];
      typesOb.forEach(t => {
        this.types.push({
          label: t.codeName,
          value: t.codeId,
          data: t
        })
      })
    })
    this.crmService.GetStates().then(states => {
      this.states = [];
      states.forEach(t => {
        this.states.push({
          label: t.codeName,
          value: t.codeId
        })
      })
    })
    this.crmService.GetCountries().then(countries => {
      this.countries = [];
      countries.forEach(t => {
        this.countries.push({
          label: t.codeName,
          value: t.codeId
        })
      })
    })
    this.crmService.GetProvinceCodes().then(provinces => {
      this.provinces = [];
      provinces.forEach(t => {
        this.provinces.push({
          label: t.codeName,
          value: t.codeId
        })
      })
    })
  }
  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {
    this.onSubmitDialog.emit(this.address);
    this.onDialogHide.emit()

  }
}
