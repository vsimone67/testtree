import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { AssignableModel } from '../../models/assignable-model';
import { GroupModel } from '../../models/group-model';
import { SecurityGroupsService } from '../../services/security-groups.service';

@Component({
  selector: 'app-add-role-to-group',
  templateUrl: './add-role-to-group.component.html',
  styleUrls: ['./add-role-to-group.component.css'],
})
export class AddRoleToGroupComponent
  extends EditDialogBase<GroupModel>
  implements OnInit
{
  showDialog: boolean = true;
  companyList;
  @Input() selectedData;
  groupName: string;
  applicationId: string;
  groupCodeId: string;
  roleId: string;
  roles: any = [];
  allUnassigned: AssignableModel[];

  constructor(private groupsService: SecurityGroupsService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.groupName = this.selectedData.groupName;

    const members = await this.groupsService.getUnassignedMembers(
      this.selectedData.groupId
    );

    this.allUnassigned = members;

    this.roles = [];
    members.forEach((line: AssignableModel) => {
      if (line)
        this.roles.push({
          label: line.roleName,
          value: line.roleId,
        });
    });
  }

  async confirm() {
    var ur;

    this.allUnassigned.forEach((line: AssignableModel) => {
      if (line.roleId == this.roleId) {
        ur = line;
      }
    });

    await this.groupsService.addRoleToGroup(
      ur.applicationId,
      this.selectedData.groupId,
      this.roleId
    );
    this.submitDialog();
    this.hideDialog();
  }

  deny() {
    this.hideDialog();
  }

  updateDrops(data) {
    this.roleId = data.value;
  }
}
