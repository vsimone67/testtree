import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChange,
} from "@angular/core";
import { Edge, Layout, Node } from "@swimlane/ngx-graph";
import { Subject } from "rxjs";
import * as shape from "d3-shape";
import { CustomDagreNodesOnlyLayout } from "@assumed/components/person-graph/DagreNodesOnlyLayout";
import { GraphEventModel } from "@assumed/models/GraphEventModel";
import { NaarSplitRootViewModel } from "../../models/NaarSplit/naarSplitRootViewModel";
import { CessionViewModel } from "../../models/NaarSplit/cessionViewModel";
import { CessionHistoryViewModel } from "../../models/NaarSplit/cessionHistoryViewModel";
import { NodeConstants } from "@constants/nodeConstants";
import { EventService } from "@shared/service/event.service";
import { events } from "@constants/events.model";

@Component({
  selector: "person-split-viewer",
  templateUrl: "./person-split-viewer.component.html",
  styleUrls: ["./person-split-viewer.component.css"],
})
export class PersonSplitViewerComponent implements OnInit, OnChanges {
  @Input() naarSplitInfo: NaarSplitRootViewModel;
  @Output() nodeClicked = new EventEmitter();

  // ngx variables
  layout: Layout;
  curve: any = shape.curveLinear;
  draggingEnabled: boolean = true;
  panningEnabled: boolean = true;
  zoomEnabled: boolean = true;
  autoZoom: boolean = false;
  autoCenter: boolean = false;
  update$: Subject<boolean> = new Subject();
  center$: Subject<boolean> = new Subject();
  zoomToFit$: Subject<boolean> = new Subject();

  cessionNodes: Node[] = [];
  cessionLinks: Edge[] = [];
  filtercessionNodes: Node[];
  filtercessionLinks: Edge[];

  // set orientation for graph
  layoutSettings = {
    orientation: "TB",
  };

  // node id's used to reference node data and create relationships
  personId: string = "person";
  cessionId: string = "cession";
  cessionLinkId: string = "cessionLink";
  cessionHistoryId: string = "history";
  cessionHistoryLinkId: string = "historyLink";

  historyDate: Date;
  SCORSequence: string;

  constructor(private _eventService: EventService) {
    this.layout = new CustomDagreNodesOnlyLayout();
    _eventService
      .getEvent(events.historyEffectiveDateFilter)
      .subscribe((filterDate) => {
        this.historyDate = filterDate;
        this.filtercessionNodes = [];
        this.filtercessionLinks = [];
        this.filterEffectiveDate();
      });
    _eventService
      .getEvent(events.SCORSequenceFilter)
      .subscribe((cessionNumber) => {
        this.SCORSequence = cessionNumber;
        this.filterEffectiveDate();
      });
  }

  filterEffectiveDate() {
    if (this.historyDate) {
      this.filtercessionNodes = this.cessionNodes.filter(
        (cession) =>
          !(
            cession.label.includes("History") &&
            (new Date(cession.data.payload.effectiveDate) <
              new Date(this.historyDate[0]) ||
              new Date(cession.data.payload.effectiveDate) >
                new Date(this.historyDate[1]))
          )
      );
      this.filtercessionLinks = this.cessionLinks.filter(
        (link) =>
          this.filtercessionNodes.filter((node) => node.id === link.target)
            .length > 0
      );
    } else {
      this.filtercessionNodes = this.cessionNodes;
      this.filtercessionLinks = this.cessionLinks;
    }
    if (this.SCORSequence) {
      let excludedNodes = this.filtercessionNodes.filter(
        (cession) =>
          cession.id.includes("cession") &&
          !cession.id.includes("history") &&
          !cession.data.payload.scorRetentionSequenceNumber
            .toString()
            .includes(this.SCORSequence)
      );
      //delete cession from node
      this.filtercessionNodes = this.filtercessionNodes.filter(
        (cession) =>
          excludedNodes.filter((node) => node.id === cession.id).length <= 0
      );
      // delete cession from Links
      this.filtercessionLinks = this.filtercessionLinks.filter(
        (link) =>
          this.filtercessionNodes.filter((node) => node.id === link.target)
            .length > 0
      );
      // get histories for the deleted cession
      let excludedLinks = this.filtercessionNodes.filter(
        (cession) =>
          this.filtercessionLinks.filter(
            (link) =>
              excludedNodes.filter(
                (node) => node.id === link.source && cession.id === link.target
              ).length > 0
          ).length > 0
      );
      // delete histories in node and links
      this.filtercessionLinks = this.filtercessionLinks.filter(
        (link) =>
          excludedLinks.filter((node) => node.id === link.target).length <= 0
      );
      this.filtercessionNodes = this.filtercessionNodes.filter(
        (node) =>
          excludedLinks.filter((exnode) => node.id === exnode.id).length <= 0
      );
    }
    this.updateGraph();
  }

  ngOnInit(): void {}

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if options are passed, override default
    if (changes.naarSplitInfo) {
      this.historyDate = null;
      this.naarSplitInfo = changes.naarSplitInfo.currentValue;
      this.ConvertCessionToGraph();
    }

    this.updateGraph();
  }

  centerGraph() {
    this.zoomToFit$.next(true);
  }

  fitGraph() {
    this.center$.next(true);
  }

  updateGraph() {
    this.update$.next(true);
  }

  ConvertCessionToGraph() {
    // Add top person node, all child nodes will branch off of this
    this.resetGraph();

    if (this.naarSplitInfo !== undefined) {
      // Angular will call this twice as the @Input get updated, check to make sure the person @Input is valid before you draw it
      var tooltip = "";
      this.addNode(
        this.personId,
        this.naarSplitInfo.firstName + " " + this.naarSplitInfo.lastName,
        this.naarSplitInfo,
        "",
        "",
        "Person",
        0,
        0,
        tooltip
      );

      // Add Cessions to Person Node
      let currentCession = 1;
      this.naarSplitInfo.cessions.forEach((cession) =>
        this.addCession(cession, currentCession++)
      );
      this.filterEffectiveDate();
    }
  }

  addCession(cession: CessionViewModel, currentCession) {
    var tooltip = `Cession: ${cession.cessionNumber}\n Policy: ${cession.policyNumber}\n Coverage No: ${cession.coverageNumber}\n Cession Seq: ${cession.cessionSequence}\n Unique Plan No: ${cession.uniquePlanNumber}\n `;

    this.addNode(
      this.cessionId + currentCession.toString(),
      `Scor Seq #: ${cession.scorRetentionSequenceNumber}`,
      cession,
      this.cessionLinkId + currentCession.toString(),
      this.personId,
      NodeConstants.cession,
      currentCession,
      cession.cessionNumber,
      tooltip
    );
  }

  addNode(
    nodeId: string,
    nodeLabel: string,
    nodeData: any,
    linkId: string,
    linkSource: string,
    dataType: string,
    cessionNumber: number,
    everestCessionNumber: number,
    toolTip: string
  ) {
    this.cessionNodes.push({
      id: nodeId,
      label: nodeLabel,
      data: {
        metaData: dataType,
        payload: nodeData,
        parentCession: cessionNumber,
        isExpanded: false,
        everestCessionNumber: everestCessionNumber,
        tooltip: toolTip,
      },
    });

    // balnk link id means top node and it will not link to anyting so do not associate anyting with it
    if (linkId != "") {
      this.cessionLinks.push({
        id: linkId,
        source: linkSource,
        target: nodeId,
      });
    }
    this.filterEffectiveDate();
  }

  // when user clicks node sent event to parent to evalute
  displayNodeData(event: GraphEventModel) {
    this.resetHistory(); // set all the expanded flags for history to false

    if (event.data.metaData === NodeConstants.cession) {
      if (!event.data.isExpanded) {
        this.resetCession(); // set all the expanded flags for history to false
        event.data.isExpanded = true;
        this.addCessionHistory(event.data.payload, event.data.parentCession);
      } else {
        event.data.isExpanded = false;
        this.removeCessionDetail(event.data.parentCession);
      }
      this.filterEffectiveDate();
      this.updateGraph();
    } else if (event.data.metaData === NodeConstants.history) {
      if (!event.data.isExpanded) {
        event.data.isExpanded = true;
      } else {
        event.data.isExpanded = false;
      }
    }
    this.nodeClicked.emit(event);
  }

  resetHistory() {
    this.cessionNodes.forEach((node) => {
      if (node.data.metaData === NodeConstants.history) {
        node.data.isExpanded = false;
      }
    });
  }

  resetCession() {
    this.cessionNodes.forEach((node) => {
      if (node.data.metaData === NodeConstants.cession) {
        node.data.isExpanded = false;
      }
    });
  }

  addCessionHistory(cession, currentCession: number) {
    var historyNode = 1;
    cession.cessionHistories.forEach((history: CessionHistoryViewModel) => {
      //var tooltip = `Effective Date: ${new Date(history.effectiveDate).toLocaleDateString()}\n Pool: ${history.pool.poolName}\n Stack: ${history.stack.stackName}\n `;
      var tooltip = "";

      this.addNode(
        this.cessionId +
          currentCession.toString() +
          this.cessionHistoryId +
          historyNode.toString(),
        NodeConstants.history +
          " " +
          `${new Date(history.effectiveDate).toLocaleDateString()}`,
        history,
        this.cessionId +
          currentCession.toString() +
          this.cessionHistoryLinkId +
          historyNode.toString(),
        this.cessionId + currentCession.toString(),
        NodeConstants.history,
        currentCession,
        0,
        tooltip
      );

      historyNode++;
    });
  }

  removeCessionDetail(currentCession: number) {
    //TODO: refactor this to be more efficient, it works for now
    var idToDelete = []; // holds the id in the array to delete
    // iternate through the cessionNode array and capture all the id's that need to be removed
    this.cessionNodes.forEach((node) => {
      if (node.id.indexOf(currentCession.toString()) > -1) {
        if (
          node.id.indexOf(
            this.cessionId + currentCession.toString() + this.cessionHistoryId
          ) !== -1
        ) {
          idToDelete.push(node.id);
        }
      }
    });
    // iterate through all the id's that were flagged to delete and remove them from the cessionNode array
    idToDelete.forEach((index) => {
      let indexToDelete = this.cessionNodes.findIndex((d) => d.id === index); //find index in your array
      this.cessionNodes.splice(indexToDelete, 1); //remove element from array
    });

    // iternate through the cessionLink array and capture all the id's that need to be removed
    idToDelete = [];
    this.cessionLinks.forEach((node) => {
      if (node.id.indexOf(currentCession.toString()) > -1) {
        if (
          node.id.indexOf(this.cessionLinkId + currentCession.toString()) === -1
        ) {
          idToDelete.push(node.id);
        }
      }
    });

    // iterate through all the id's that were flagged to delete and remove them from the cessinnLink array
    idToDelete.forEach((index) => {
      let indexToDelete = this.cessionLinks.findIndex((d) => d.id === index); //find index in your array
      this.cessionLinks.splice(indexToDelete, 1); //remove element from array
    });
    // redraw the graph on the screen with the updated nodes and links that were removed
    this.filterEffectiveDate();
  }

  resetGraph() {
    this.cessionNodes = [];
    this.cessionLinks = [];
    this.filtercessionLinks = [];
    this.filtercessionNodes = [];
  }

  getcolor(node: Node) {
    var retColor = "#30A9C7"; // default color

    if (
      node.id.toLowerCase().includes("cession") &&
      !node.id.toLowerCase().includes("history") &&
      !node.data.isExpanded
    ) {
      retColor = "#9E6C80";
    } else if (
      node.id.toLowerCase().includes("cession") &&
      !node.id.toLowerCase().includes("history") &&
      node.data.isExpanded
    ) {
      retColor = "#800000";
    } else if (
      node.id.toLowerCase().includes("history") &&
      node.data.isExpanded
    ) {
      retColor = "#00bfff";
    } else if (
      node.id.toLowerCase().includes("history") &&
      !node.data.isExpanded
    ) {
      retColor = "#30A9C7";
    } else if (node.id.toLowerCase().includes("person")) {
      retColor = "#0e6a81";
    }

    return retColor;
  }
}
