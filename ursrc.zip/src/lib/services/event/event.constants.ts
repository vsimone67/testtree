export const eventConstants = {
  loadingEvent: "loadingEvent",
};
