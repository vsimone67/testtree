import { Injectable } from '@angular/core';
import { User } from '@auth/models/user';
import { SiteConstants } from '@constants/siteConstants';
import { HttpService, AppSettingsService } from '@scor/common';
import { RoleMemberModel } from '../models/role-member-model';
import { RoleModel } from '../models/role-model';

@Injectable({
  providedIn: 'root',
})
export class SecurityRolesService {
  baseApiUrl: string;
  controllerUrl: string;
  currentUser: User;

  constructor(
    private _httpService: HttpService,
    private _appSettingsService: AppSettingsService
  ) {
    this.baseApiUrl = `${this._appSettingsService.GetValue('apiGatewayUrl')}`;
    this.controllerUrl = `${this._appSettingsService.GetValue(
      'apiGatewayUrl'
    )}/securityroles`;
    this.currentUser = JSON.parse(
      localStorage.getItem(SiteConstants.UserToken)
    );
  }

  async getRoles() {
    return await this._httpService.getData<RoleModel[]>(
      `${this.controllerUrl}/GetSecurityRoles`
    );
  }

  async getUsersInRole(roleId: string) {
    return await this._httpService.getData<RoleMemberModel[]>(
      `${this.controllerUrl}/GetUsersInRole?roleId=${roleId}`
    );
  }

  async getUnassignedMembers(roleId: string) {
    return await this._httpService.getData<RoleMemberModel[]>(
      `${this.controllerUrl}/GetAssignableUsers?roleId=${roleId}`
    );
  }

  async addSecurityRole(
    roleName: string,
    applicationId: string,
    loweredRoleName: string,
    description: string
  ) {
    const body = {
      RoleName: roleName,
      ApplicationId: applicationId,
      loweredRoleName: loweredRoleName,
      Description: description,
      UserId: this.currentUser.id,
    };

    return await this._httpService.postData(
      `${this.controllerUrl}/AddSecurityRole`,
      body
    );
  }

  async editSecurityRole(
    roleId: string,
    roleName: string,
    applicationId: string,
    loweredRoleName: string,
    description: string,
    rowStatusId: string
  ) {
    const body = {
      RoleId: roleId,
      RoleName: roleName,
      ApplicationId: applicationId,
      loweredRoleName: loweredRoleName,
      Description: description,
      UserId: this.currentUser.id,
      RowStatusId: rowStatusId,
    };

    return await this._httpService.putData(
      `${this.controllerUrl}/EditSecurityRole`,
      body
    );
  }

  async setStatus(
    roleId: string,
    roleName: string,
    applicationId: string,
    loweredRoleName: string,
    description: string,
    rowStatusId: string
  ) {
    const body = {
      RoleId: roleId,
      RoleName: roleName,
      ApplicationId: applicationId,
      loweredRoleName: loweredRoleName,
      Description: description,
      UserId: this.currentUser.id,
      RowStatusId: rowStatusId,
    };

    return await this._httpService.putData(
      `${this.controllerUrl}/SetStatus`,
      body
    );
  }

  async addUserToRole(userId: string, roleId: string) {
    const body = { UserId: userId, RoleId: roleId };

    return await this._httpService.postData(
      `${this.controllerUrl}/AddUserToRole`,
      body
    );
  }

  async removeUserFromRole(userId: string, roleId: string) {
    const body = { UserId: userId, RoleId: roleId };

    return await this._httpService.postData(
      `${this.controllerUrl}/RemoveUserFromRole`,
      body
    );
  }
}
