import { OfacResponseModel } from './ofacResponseModel';

export interface OfacRequestModel {

  ofacRequestId: string;
  businessUnitTypeId: string;
  entityTypeId: string;
  parentId: string;
  requestDate: Date | string;
  requestStatusId: string;
  threshold: number | null;
  createDate: Date | string;
  createdBy: string;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;
  moduleReference: string | null;
  ofacResponses: OfacResponseModel[];
}
