import { CessionCompleteModel } from "./CessionCompleteModel";
export interface PersonModel {
  new (): PersonModel;
  personGroupId: number;
  personId: string;
  firstName: string;
  lastName: string;
  middleInitial: string;
  cessions: CessionCompleteModel[];
}
