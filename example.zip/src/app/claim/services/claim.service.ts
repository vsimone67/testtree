import { Injectable } from '@angular/core';
import { HttpService } from '@shared/services/http-service.service';
import { SiteConstants } from '@constants/siteConstants';
import { ClaimCompleteModel } from '../models/claimCompleteModel';

import { AppSettingsService } from '@shared/services/app-settings.service';

@Injectable({
  providedIn: 'root'
})
export class ClaimService {

  private _claimUrl: string;

  constructor(
    private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    //this._claimUrl = `${environment.apiGatewayUrl}/${SiteConstants.claimsController}`;
    this._claimUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.claimsController}`;
  }

  async getClaimDataForCession(cessionId: string) {
    return await this._httpService.getData<ClaimCompleteModel>(
      `${this._claimUrl}/DisplayClaimComplete/${cessionId}`
    );
  }

  async cessionHasClaims(cessionId: string) {
    var retVal = false;
    var claimData = await await this._httpService.getData<ClaimCompleteModel>(`${this._claimUrl}/DisplayClaimComplete/${cessionId}`);

    if (claimData.claim !== null) {
      retVal = true;
    }

    return retVal;
  }
}
