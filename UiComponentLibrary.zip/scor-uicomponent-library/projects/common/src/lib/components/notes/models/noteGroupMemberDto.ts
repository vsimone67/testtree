import { NoteGroupDto } from './noteGroupDto';
import { NoteDto } from './noteDto';

export interface NoteGroupMemberDto {
    groupId: string;
    noteId: string;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    group: NoteGroupDto;
    note: NoteDto;
}