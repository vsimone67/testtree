export function formatDate(dateToFormat) {
  return dateToFormat ? new Date(dateToFormat).toLocaleDateString() : "";
}
