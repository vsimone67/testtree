export enum SiteConstants {
  UserToken = 'UserToken',
  authorizationApiUrl = 'authorizationApiUrl',
  authorizationApiController = 'Authorize',
  version = 'V.1.0',
}
