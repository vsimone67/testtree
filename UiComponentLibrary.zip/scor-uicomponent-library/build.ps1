ng build common
$currentDir = (Get-Item .).FullName
set-location dist/common
npm pack
copy-item *.tgz /scorui
set-location $currentDir