export interface AddNoteDto {
  parentId: string;
  noteType: string;
  noteDescription: string;
  noteGroupId: string;
  noteId: string;
  noteDate: string | null;
  noteText: string;
  noteCreateDate: string;
  createdBy: string;
}
