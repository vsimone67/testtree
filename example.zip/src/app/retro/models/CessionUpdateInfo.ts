export interface CessionUpdateInfo {
  insuredId: string;
  cessionId: string;
  companyName: string;
  cCedingCompanyId: string | null;
  policyNumber: string;
  coverageNumber: string;
  cessionSequence: string;
  note: string;
  addToWarningExemptionList: boolean;
  uniquePlanNumber: string;
  modifiedById: string;
  firstName: string;
  lastName: string;
  middleInitial: string;
  isExtendable: boolean;
  isActive: boolean;
  baseNARAmount: number;
  baseReinsuredAmount: number;
  paidToDate: Date |string;
  transactionType: string;
  userName: string;
}
