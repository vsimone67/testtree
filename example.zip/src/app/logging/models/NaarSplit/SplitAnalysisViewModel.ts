import {SplitsModel} from "./splitsModel";

export class SplitAnalysisViewModel {
  cessionNumber: number;

  children: SplitsModel[]

}
