import { CodeDto } from './codeDto';
import { NoteGroupMemberDto } from './noteGroupMemberDto';

export interface NoteGroupDto {
    groupId: string;
    groupDescription: string;
    groupName: string;
    groupSubTypeId: string | null;
    groupTypeId: string | null;
    parentId: string | null;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    groupType: CodeDto;
    noteGroupMember: NoteGroupMemberDto[];
}