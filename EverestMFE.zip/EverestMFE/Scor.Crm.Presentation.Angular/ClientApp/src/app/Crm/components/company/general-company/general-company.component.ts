import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ColDef, GridOptions} from "ag-grid-community";
import {ImageButtonCellComponent} from "@scor/common";
import {SiteConstants} from "@constants/siteConstants";
import {CompanyThresholdVolumeDto} from "../../../dto/companyThresholdVolumeDto";
import {CrmService} from "../../../service/CrmService";
import {CompanyTargetDto} from "../../../dto/companyTargetDto";
import {ConfirmationService, MessageService} from "primeng/api";

@Component({
  selector: 'general-company',
  templateUrl: './general-company.component.html',
  styleUrls: ['./general-company.component.css']
})
export class GeneralCompanyComponent implements OnInit {
  @Input() companyid
  @Input() years;
  @Input() treshData;
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()
  gridOptions: GridOptions
  GridCssStyle: string;
  yearsColumns: any;
  treshColumns: any;
  selectedThreshold: CompanyThresholdVolumeDto;
  mode: string;
  showDialogThreshold: boolean;
  selectedTarget: CompanyTargetDto;
  showDialogTarget: boolean;

  constructor(private crmService: CrmService, private confirm: ConfirmationService,
              private _messageService: MessageService) {
  }

  ngOnInit(): void {
    this.GridCssStyle = "width: 100%; height: 250px;";
    this.yearsColumns = this.createYearsColumns();
    this.treshColumns = this.createTreshColumns();
  }

  addYear() {
    this.mode = 'add';
    this.showDialogTarget = true;
    this.showDialogThreshold = false;
    this.selectedTarget = <CompanyTargetDto>{}
  }

  deleteYear(data) {
    this.confirm.confirm({
      message: "Do you want to delete this Target Year ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        let id = data.rowData.companyTargetId
        this.crmService.DeleteCompanyTarget(id).then(liste => {
          this.refreshData.emit()
          this._messageService.add({severity: "success", detail: "Target Year Has been Deleted"});
        })
      },
      reject: () => {
      },
    });
  }

  editTresh(data) {
    this.mode = 'edit';
    this.showDialogThreshold = true;
    this.selectedThreshold = data.rowData
  }

  deleteTresh(data) {
    this.confirm.confirm({
      message: "Do you want to delete this Threshold ?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      rejectButtonStyleClass: "cleardata",
      accept: () => {
        let id = data.rowData.companyThresholdVolumeId
        this.crmService.DeleteCompanyTreashold(id).then(liste => {
          this.refreshData.emit()
          this._messageService.add({severity: "success", detail: "Threshold Has been Deleted"});
        })
      },
      reject: () => {
      },
    });
  }

  addTreshold() {
    this.mode = 'add';
    this.showDialogThreshold = true;
    this.selectedThreshold = <CompanyThresholdVolumeDto>{}
  }

  submitDialogThreshold(threshold: CompanyThresholdVolumeDto) {
    if (this.mode == 'add') {
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      threshold.createdBy = user.userId;
      threshold.modifiedBy = user.userId;
      threshold.companyId = this.companyid
      this.crmService.AddCompanyTreashold(threshold).then(th => this.refreshData.emit())
    } else {
      this.crmService.EditCompanyTreashold(threshold).then(th => this.refreshData.emit())

    }
  }

  hideDialog() {
    this.showDialogThreshold = false;
    this.showDialogTarget = false;
  }

  submitDialogTarget(target: CompanyTargetDto) {
    if (this.mode == 'add') {
      let user = JSON.parse(localStorage.getItem(SiteConstants.UserToken));
      target.createdBy = user.userId;
      target.modifiedBy = user.userId;
      target.companyId = this.companyid
      this.crmService.AddCompanyTarget(target).then(th => this.refreshData.emit())
    }
  }

  private createYearsColumns() {
    return <ColDef[]>[
      {
        field: "targetYear",
        headerName: 'Year',
        width: 130
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteYear.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }

  private createTreshColumns() {
    return <ColDef[]>[
      {
        field: "thresholdYear",
        headerName: 'Year',
        width: 100
      },
      {
        field: "thresholdTypeNavigation.codeName",
        headerName: 'Type',
        width: 100
      },
      {
        field: "thresholdVolume",
        headerName: 'Threshold',
        width: 100
      },
      {
        field: "thresholdReasonNavigation.codeName",
        headerName: 'Reason',
        width: 100
      },
      {
        field: "edit",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.editTresh.bind(this),
          icon: "pi-pencil",
        }
      },
      {
        field: "delete",
        headerName: "",
        cellRendererFramework: ImageButtonCellComponent,
        width: 5,
        cellRendererParams: {
          onClick: this.deleteTresh.bind(this),
          icon: "pi-trash",
        }
      }
    ];
  }
}
