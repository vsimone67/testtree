import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vinnypage',
  templateUrl: './vinnypage.component.html',
  styleUrls: ['./vinnypage.component.css']
})
export class VinnypageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
