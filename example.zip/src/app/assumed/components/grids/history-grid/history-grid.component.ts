import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from "@angular/core";
import { ColDef } from "ag-grid-community";
import { LinkCellComponent } from "@shared/components/grid/link-cell/link-cell.component";
import { formatDate } from "@shared/components/grid/formatters/formatDate";
import { formatNumber } from "@shared/components/grid/formatters/formatNumber";
import {
  formatCurrency,
  formatCurrencyCent,
} from "@shared/components/grid/formatters/formatCurrency";
import { TreatyCompleteModel } from "@assumed/models/TreatyCompleteModel";
import { TreatyService } from "@shared/services/treaty.service";
import { CessionHistoryModel } from "@assumed/models/CessionHistoryModel";
import { GraphEventModel } from "@assumed/models/GraphEventModel";
import { EventService } from "@shared/services/event.service";
import { events } from "@constants/events.model";
import { ConfigurableGridComponent } from "@shared/components/grid/configurable-grid/configurable-grid.component";

@Component({
  selector: "history-grid",
  templateUrl: "./history-grid.component.html",
  styleUrls: ["./history-grid.component.css"],
})
export class HistoryGridComponent implements OnInit {
  HistoryData: Array<CessionHistoryModel>;
  @Input() EventData: GraphEventModel;
  @Output() hidetable: EventEmitter<Boolean> = new EventEmitter<Boolean>();
  @ViewChild(ConfigurableGridComponent, { static: false }) grid;

  currentCessionNumber: string;
  columnDefs: Array<ColDef>;
  defaultCols: Array<String>;
  rowClassRules: any;
  showTreaty: boolean = false;
  treatyId: string;
  proposalQuoteBandShareId: string;
  currentTreaty: TreatyCompleteModel;

  constructor(
    private _treatySerivce: TreatyService,
    private _eventService: EventService
  ) {
    this.createHistoryColumns();
    this.rowClassRules = {
      "row-difference": function (params) {
        var retval: boolean = false;

        if (params.data.hasDifferences !== undefined) {
          retval = params.data.hasDifferences;
        }
        return retval;
      },
    };
    // listen for NaarSplit Differences event
    _eventService.clearEvent(events.showHistoryNaarDifferences);
    _eventService
      .getEvent(events.showHistoryNaarDifferences)
      .subscribe((showDifferences) => {
        if (showDifferences) {
          this.checkHistoryDifferences();
          //this.turnOnRowColorRules();
        } else {
         //this.turnOffRowColorRules();
          this.turnOffDifferences();
        }

        this.grid.refresh();
      });
  }

  ngOnInit() {
    this.HistoryData = this.EventData.data.payload;
    this.currentCessionNumber = this.EventData.data.everestCessionNumber.toString();
  }

  createHistoryColumns() {
    this.columnDefs = this.getColumns();
    this.defaultCols = this.getDefaultColumns();
  }

  checkHistoryDifferences() {
    var baseNaramount = this.HistoryData[0].baseNaramount;
    var baseReinsuredAmount = this.HistoryData[0].baseReinsuredAmount;
    this.HistoryData.forEach((exp) => {
      if (
        exp.baseNaramount !== baseNaramount ||
        exp.baseReinsuredAmount !== baseReinsuredAmount
      )
        exp.hasDifferences = true;
    });
  }

  turnOffDifferences() {
    this.HistoryData.forEach((exp) => (exp.hasDifferences = false));
  }

  turnOnRowColorRules() {
    this.rowClassRules = {
      "row-difference": function (params) {
        var retval: boolean = false;

        if (params.data.hasDifferences !== undefined) {
          retval = params.data.hasDifferences;
        }
        return retval;
      },
    };
  }

  turnOffRowColorRules() {
    this.rowClassRules = {};
  }

  rowColorRulesAction(action: boolean) {
    if (action) {
      this.turnOnRowColorRules();
    } else {
      this.turnOffRowColorRules();
    }
  }

  refresh() {
    this.grid.refresh();
  }

  disable(visible) {
    this.hidetable.emit(visible);
  }

  async onShowTreatyInfo(gridRow) {
    var historyRecord = <CessionHistoryModel>gridRow.rowData;
    this.treatyId = historyRecord.treatyId;
    this.currentTreaty = await this._treatySerivce.getTreatyInfo(this.treatyId);
    this.showTreaty = true;
  }
  hideTreatyDialog() {
    this.showTreaty = false;
  }

  getColumns() {
    return [
      {
        headerName: "Base Nar amount",
        field: "baseNaramount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Base Premium Amount",
        field: "basePremiumAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent,
      },
      {
        headerName: "Policy Date",
        field: "policyDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "Policy Number",
        field: "policyNumber",
        cellClass: "text-left",
      },
      {
        headerName: "Coverage Number",
        field: "coverageNumber",
        cellClass: "text-left",
      },
      {
        headerName: "Cession Sequence",
        field: "cessionSequence",
        cellClass: "text-left",
      },
      {
        headerName: "Unique Plan Number",
        field: "uniquePlanNumber",
        cellClass: "text-left",
      },
      {
        headerName: "First Name",
        field: "firstName",
        cellClass: "text-left",
      },
      {
        headerName: "Last Name",
        field: "lastName",
        cellClass: "text-left",
      },
      {
        headerName: "EffectiveDate ",
        field: "effectiveDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "Reinsurance Effective Date",
        field: "reinsuranceEffectiveDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "Original Issue Date",
        field: "originalIssueDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "Cancel Date",
        field: "cancelDate",
        cellClass: "text-left",
        valueFormatter: formatDate,
      },
      {
        headerName: "Insured Issue Age",
        field: "insuredIssueAge",
        cellClass: "text-left",
        valueFormatter: formatNumber,
      },
      {
        headerName: "Reinsurance Duration",
        field: "reinsuranceDuration",
        cellClass: "text-left",
        valueFormatter: formatNumber,
      },
      {
        headerName: "Policy Duration",
        field: "policyDuration",
        cellClass: "text-left",
        valueFormatter: formatNumber,
      },
      {
        headerName: "Insured Table Number",
        field: "insuredTableNumber",
        cellClass: "text-left",
        valueFormatter: formatNumber,
      },
      {
        headerName: "Active",
        field: "isActive",
        cellClass: "text-left",
      },
      {
        headerName: "Stack Name",
        field: "stackName",
        cellClass: "text-left",
      },
      {
        headerName: "PoolName",
        field: "poolName",
        cellClass: "text-left",
      },
      {
        headerName: "Adb premium Amount",
        field: "adbpremiumAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent,
      },
      {
        headerName: "Single Joint Type",
        field: "singleJointType",
        cellClass: "text-left",
      },
      {
        headerName: "Extra Allowance Amount3",
        field: "extraAllowanceAmount3",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Extra Premium Amount3",
        field: "extraPremiumAmount3",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent,
      },
      {
        headerName: "Policy Fee Amount",
        field: "policyFeeAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Policy Fee Allowance Amount",
        field: "policyFeeAllowanceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Premium Tax Amount",
        field: "premiumTaxAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent,
      },
      {
        headerName: "Extra Allowance Amount1",
        field: "extraAllowanceAmount1",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Extra Allowance Amount2",
        field: "extraAllowanceAmount2",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Extra Premium Amount1",
        field: "extraPremiumAmount1",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent,
      },
      {
        headerName: "Extra Premium Amount2",
        field: "extraPremiumAmount2",
        cellClass: "text-left",
        valueFormatter: formatCurrencyCent,
      },
      {
        headerName: "Base Allowance Amount",
        field: "baseAllowanceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Base Face Amount",
        field: "baseFaceAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Base Reinsured Amount",
        field: "baseReinsuredAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Base Retention Amount",
        field: "baseRetentionAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Insured Perm Flat Extra Amt",
        field: "insuredPermFlatExtraAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Insured Temp Flat Extra Amt",
        field: "insuredTempFlatExtraAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "2nd Insured Perm Flat Extra Amt",
        field: "secondInsuredPermFlatExtraAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "2nd Insured Temp Flat Extra Amt",
        field: "secondInsuredTempFlatExtraAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Ultimate Ceded Amount",
        field: "ultimateCededAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Base Nar Retro Override Amt",
        field: "baseNarretroOverrideAmount",
        cellClass: "text-left",
        valueFormatter: formatCurrency,
      },
      {
        headerName: "Treaty",
        field: "treatyNumber",
        cellRendererFramework: LinkCellComponent,
        cellRendererParams: {
          onClick: this.onShowTreatyInfo.bind(this),
        },
      },
    ];
  }

  getDefaultColumns() {
    return [
      "firstName",
      "lastName",
      "effectiveDate",
      "stackName",
      "poolName",
      "baseFaceAmount",
      "baseNaramount",
      "baseReinsuredAmount",
      "treatyNumber",
    ];
  }
}
