import { CompanyDto } from './companyDto';
import { CompanyContactGroupDto } from './companyContactGroupDto';

export interface CompanyLegalEventDto {
    companyLegalEventId: string;
    companyId: string | null;
    aiin: string;
    countryOfDomicileId: string | null;
    fein: string;
    gnaic: string;
    isActive: boolean;
    legalName: string;
    legalEventDescription: string;
    legalEventEffectiveDate: string | null;
    legalEventEndDate: string | null;
    legalEventStatusId: string | null;
    legalEventTypeId: string | null;
    naic: string;
    mergedToCompanyId: string | null;
    parentId: string | null;
    provinceOfDomicileId: string | null;
    stateOfDomicileId: string | null;
    vatnumber: string;
    documentGroupId: string | null;
    noteGroupId: string | null;
    companyContactGroupId: string | null;
    createDate: string | null;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    company: CompanyDto;
    companyContactGroup: CompanyContactGroupDto;
    mergedToCompany: CompanyDto;
    parent: CompanyDto;
}