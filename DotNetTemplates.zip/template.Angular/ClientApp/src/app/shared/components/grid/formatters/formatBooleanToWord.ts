export function formatBooleanToWord(data) {
  return data.value ? "Yes" : "No";
}
