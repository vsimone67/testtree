export interface NaarSplitGenerateInfo {
  ConnectionId: string;
  CessionId: string;
  AsOfDate: string;
}
