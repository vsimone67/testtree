import { Component, OnInit, Input } from '@angular/core';
import { SplitsViewModel } from '../../models/NaarSplit/splitsViewModel';
import { ColDef, GridOptions } from 'ag-grid-community';
import { formatDate } from '@shared/components/grid/formatters/formatDate';
import { formatCurrency } from '@shared/components/grid/formatters/formatCurrency';
import {PriorsViewModel} from "../../models/NaarSplit/priorsViewModel";
import {PriorsPostsViewModel} from "../../models/NaarSplit/priorsPostsViewModel";

@Component({
  selector: 'splits',
  templateUrl: './splits.component.html',
  styleUrls: ['./splits.component.css']
})
export class SplitsComponent implements OnInit {
  @Input() splitsInfo: SplitsViewModel
   @Input() priorPost : any

  columnDefs: Array<ColDef>;
  GridCssStyle: string;
  gridOptions: GridOptions;

  constructor() {

    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 350px;";
    this.gridOptions = <GridOptions>{};
    this.gridOptions.tooltipShowDelay = 500; //default tool tip to 1/2 second
  }

  ngOnInit(): void {

    this.priorPost.posts.retainedNAARformatted=formatCurrency({value:this.priorPost.posts.retainedNAAR})
    this.priorPost.posts.retainedCededformatted=formatCurrency({value:this.priorPost.posts.retainedCeded})
    this.priorPost.priors.affiliateCededRecaptureformatted=formatCurrency({value:this.priorPost.priors.affiliateCededRecapture})
    this.priorPost.priors.affiliateCededNonRecaptureformatted=formatCurrency({value:this.priorPost.priors.affiliateCededNonRecapture})
    this.priorPost.priors.retainedCededformatted=formatCurrency({value:this.priorPost.priors.retainedCeded})
    this.priorPost.priors.affiliateNAARRecaptureformatted=formatCurrency({value:this.priorPost.priors.affiliateNAARRecapture})
    this.priorPost.priors.affiliateNAARNonRecaptureformatted=formatCurrency({value:this.priorPost.priors.affiliateNAARNonRecapture})
    this.priorPost.priors.retainedNAARformatted=formatCurrency({value:this.priorPost.priors.retainedNAAR})
  }

  createColumnDefs() {
    return [
      {
        headerName: "Pool Name",
        field: "poolName"

      },
      {
        headerName: "Effective Date",
        field: "effectiveDate",
        valueFormatter: formatDate
      },
      {
        headerName: "Comapny Name",
        field: "retroCompanyName"
      },
      {
        headerName: "Treaty Number",
        field: "treatyNumber"
      },
      {
        headerName: "Split Type",
        field: "splitType"
      },
      ,
      {
        headerName: "Split Category",
        field: "splitCategory"
      },
      {
        headerName: "Split Amount",
        field: "splitAmount",
        valueFormatter: formatCurrency
      },
      {
        headerName: "Ceeded Amount",
        field: "cededAmount",
        valueFormatter: formatCurrency
      },
    ];
  }
}
