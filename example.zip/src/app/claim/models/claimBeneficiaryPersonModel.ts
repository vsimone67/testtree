import { OfacRequestModel } from './ofacRequestModel';

export interface ClaimBeneficiaryPersonModel {
  claimBeneficiaryId: string;
  claimId: string;
  dateOfBirth: Date | string | null;
  firstName: string;
  isOfac: boolean | null;
  lastName: string;
  middleName: string;
  ssn: string;
  createDate: Date | string;
  createdBy: string;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;
  ofacRequests: OfacRequestModel[];
}
