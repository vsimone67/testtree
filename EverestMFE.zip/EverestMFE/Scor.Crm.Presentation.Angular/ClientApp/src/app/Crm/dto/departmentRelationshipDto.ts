import { DepartmentDto } from './departmentDto';

export interface DepartmentRelationshipDto {
    departmentRelationshipId: string;
    childDepartmentId: string;
    childRoleTypeId: string;
    isHierarchal: boolean | null;
    isParent: boolean | null;
    parentChildId: string;
    parentRoleTypeId: string;
    recursionLevel: number | null;
    relationshipDescription: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    childDepartment: DepartmentDto;
    parentChild: DepartmentDto;
}