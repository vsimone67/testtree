import { Injectable } from '@angular/core';
import { SiteConstants } from '@constants/siteConstants';
import { AppSettingsService } from '../../shared/services/app-settings.service';
import { HttpService } from '../../shared/services/http-service.service';

@Injectable({
  providedIn: 'root'
})
export class RetroRollbackAggregatorService {

  private _rollbackAggregatorUrl: string;

  constructor(private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    this._rollbackAggregatorUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.retroRollbackAggregatorController}`;
  }

  async retroCessionOverrideRollback(screenId: string) {
    return await this._httpService.postData(`${this._rollbackAggregatorUrl}/RetroCessionOverrideRollback?screenId=${screenId}`,"");
  }

  async retroTxnRollback(screenId: string) {
    return await this._httpService.postData(`${this._rollbackAggregatorUrl}/retroTxnRollback?screenId=${screenId}`,"");
  }

  async retroCaptureProgramOverrideRollback(screenId: string) {
    return await this._httpService.postData(`${this._rollbackAggregatorUrl}/RetroCaptureProgramOverrideRollback?screenId=${screenId}`,"");
  }

  async rollbackCessionUpdate(screenId: string) {
    return await this._httpService.postData(`${this._rollbackAggregatorUrl}/RollbackCessionUpdate?screenId=${screenId}`,"");
  }
}
