export interface PoolCapacityViewModel {
    retroCompany: string;
    retroTreatyNumber: string;
    planName: string;
    reinsuranceType: string;
    retroSharePercentage: number;
    countryRatingGroup: string;
    bindingType: string;
    bindingLimit: number;
}