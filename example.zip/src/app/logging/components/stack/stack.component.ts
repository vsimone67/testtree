import { Component, OnInit, Input, SimpleChange } from '@angular/core';
import { StackViewModel } from '../../models/NaarSplit/stackViewModel';
import { ColDef } from 'ag-grid-community';
import { formatBooleanToWord } from '@shared/components/grid/formatters/formatBooleanToWord';
import { formatNumberToCurrency } from '@shared/functions/formatNumberToCurrency';
import { formatPercent } from '@shared/components/grid/formatters/formatPercent';


@Component({
  selector: 'stack',
  templateUrl: './stack.component.html',
  styleUrls: ['./stack.component.css']
})
export class StackComponent implements OnInit {
  @Input() stackInfo: StackViewModel;

  columnDefs: Array<ColDef>;
  GridCssStyle: string;

  effectiveDate: string;
  cancelDate: string;
  retainedRatio: string;
  naar: string;
  ceed: string;

  constructor() {

    this.columnDefs = this.createColumnDefs();
    this.GridCssStyle = "width: 100%; height: 250px;";
  }

  ngOnInit(): void {
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    // if we want to change the default options we will pass it and then assign it to the component

    // if options are passed, override default
    if (changes.stackInfo != undefined) {

      this.effectiveDate = new Date(changes.stackInfo.currentValue.effectiveDate).toLocaleDateString();
      this.cancelDate = new Date(changes.stackInfo.currentValue.cancelDate).toLocaleDateString();
      this.retainedRatio = (100 * (changes.stackInfo.currentValue.retainedRatio)).toString() + "%";
      this.naar = (changes.stackInfo.currentValue.nAARToAllocate) ? formatNumberToCurrency(changes.stackInfo.currentValue.nAARToAllocate) : "";
      this.ceed = (changes.stackInfo.currentValue.cededToAllocate) ? formatNumberToCurrency(changes.stackInfo.currentValue.cededToAllocate) : "";
    }
  }

  createColumnDefs() {
    return [
      {
        headerName: "Company Name",
        field: "companyName"

      },
      {
        headerName: "Treaty Number",
        field: "treatyNumber",

      },
      {
        headerName: "Retention Share %",
        field: "retentionSharePercentage",
        valueFormatter: formatPercent

      },
      {
        headerName: "Is Pass Through",
        field: "isStackPassThru",
        valueFormatter: formatBooleanToWord
      }
    ];
  }
}
