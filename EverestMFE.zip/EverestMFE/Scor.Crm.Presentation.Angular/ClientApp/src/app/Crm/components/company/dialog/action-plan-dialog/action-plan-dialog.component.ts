import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ActionPlanDto} from "../../../../dto/actionPlanDto";

@Component({
  selector: 'app-action-plan-dialog',
  templateUrl: './action-plan-dialog.component.html',
  styleUrls: ['./action-plan-dialog.component.css']
})
export class ActionPlanDialogComponent implements OnInit {
  @Input() actionplan: ActionPlanDto;
  @Output() onDialogHide: EventEmitter<any> = new EventEmitter<any>()
  @Output() onSubmitDialog: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean = true;

  constructor() {
  }

  ngOnInit(): void {
  }

  hideDialog() {
    this.showDialog = false;
    this.onDialogHide.emit()
  }

  submitDialog() {

    this.onSubmitDialog.emit(this.actionplan);
    this.onDialogHide.emit()

  }
}
