import { Component, OnInit, Input } from '@angular/core';
import { CessionHistoryViewModel } from '../../models/NaarSplit/cessionHistoryViewModel';
import { SplitsViewModel } from '../../models/NaarSplit/splitsViewModel';

@Component({
  selector: 'split-detail',
  templateUrl: './split-detail.component.html',
  styleUrls: ['./split-detail.component.css']
})
export class SplitDetailComponent implements OnInit {

  @Input() currentCessionHistory: CessionHistoryViewModel;  // current selected cession history


  constructor() { }

  ngOnInit(): void {
  }

}
