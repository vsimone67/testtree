export interface RetroCessionDetailModel {
    RetroCessionId : string;
    CompanyId : string;
    CompanyName : string;
    RetroTreatyId : string;
    TreatyNumber : string;
    SplitCategoryId : string;
    CategoryName : string;
    RetroEffectiveDate : Date | string;
    RetroEffectiveDateDisplay : string;
    RetroCancelDate : Date | string;
    RetroCancelDateDisplay : string;
    NarSplitId : string;
    SplitAmount : number;
    IsActive : boolean;
    PolicyDate : Date | string;
}