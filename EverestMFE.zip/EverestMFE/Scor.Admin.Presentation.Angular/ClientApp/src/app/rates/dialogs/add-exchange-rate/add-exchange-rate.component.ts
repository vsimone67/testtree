import { Component, Input, OnInit } from '@angular/core';
import { EditDialogBase } from '@shared/dialog/EditDialogBase';
import { RateModel } from '../../models/rate-model';
import { ExchangeRatesService } from '../../services/exchange-rates.service';

@Component({
  selector: 'app-add-exchange-rate',
  templateUrl: './add-exchange-rate.component.html',
  styleUrls: ['./add-exchange-rate.component.css'],
})
export class AddExchangeRateComponent
  extends EditDialogBase<RateModel>
  implements OnInit
{
  showDialog: boolean = true;
  @Input() currency;
  @Input() showAll: boolean;
  currencyName;
  exchangeRate;
  effectiveDate: Date;

  constructor(private ratesService: ExchangeRatesService) {
    super();
  }

  ngOnInit(): void {
    this.getInitialData();
  }

  async getInitialData() {
    this.currencyName = this.currency.label;
  }

  async saveAddTeamMember() {
    await this.ratesService.addExchangeRate(
      this.currency.value,
      this.exchangeRate,
      this.effectiveDate
    );
    this.submitDialog();
    this.hideDialog();
  }
}
