import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { Observable } from 'rxjs';
import { EventService } from '../event/event.service';
import { eventConstants } from '../event/event.constants';

@Injectable({
  providedIn: 'root',
})
export class HttpService {
  constructor(
    private _http: HttpClient,
    private _messageService: MessageService,
    private _eventService: EventService
  ) {}

  async getData<T>(url: string) {
    try {
      this._eventService.sendEvent(eventConstants.loadingEvent, true); // turn on loading spinner
      return await this._http
        .get<T>(url)
        .toPromise()
        .finally(() =>
          this._eventService.sendEvent(eventConstants.loadingEvent, false)
        ); // when http get ends call to turn off spinner;
    } catch (e) {
      if (e.error != undefined) {
        console.error(`Error From API: ${url} ${e.error.message}`);
        this._messageService.add({
          severity: 'error',
          summary: e.name,
          detail: e.error.message,
          sticky: true,
        });
      } else {
        console.error(`Error From API: ${e.statusText}`);
        this._messageService.add({
          severity: 'error',
          summary: e.name,
          detail: e.statusText,
          sticky: true,
        });
      }
      throw e;
    }
  }

  async postData<T>(url: string, payload: any) {
    try {
      this._eventService.sendEvent(eventConstants.loadingEvent, true); // turn on loading spinner
      return await this._http
        .post<T>(url, payload)
        .toPromise()
        .finally(() =>
          this._eventService.sendEvent(eventConstants.loadingEvent, false)
        ); // when http get ends call to turn off spinner
    } catch (e) {
      console.error(`Error From API: ${url} ${e.error.message}`);
      this._messageService.add({
        severity: 'error',
        summary: e.name,
        detail: e.message,
        sticky: true,
      });
      throw e;
    }
  }

  async putData<T>(url: string, payload: T) {
    try {
      this._eventService.sendEvent(eventConstants.loadingEvent, true); // turn on loading spinner
      return await this._http
        .put<T>(url, payload)
        .toPromise()
        .finally(() =>
          this._eventService.sendEvent(eventConstants.loadingEvent, false)
        ); // when http get ends call to turn off spinner
    } catch (e) {
      console.error(`Error From API: ${url} ${e.error.message}`);
      this._messageService.add({
        severity: 'error',
        summary: e.name,
        detail: e.message,
        sticky: true,
      });
      throw e;
    }
  }

  getBlob(url: string): Observable<HttpEvent<Blob>> {
    return this._http.request(
      new HttpRequest('GET', url, null, {
        reportProgress: true,
        responseType: 'blob',
      })
    );
  }

  uploadfile(url: string, payload: any) {
    return this._http.request(new HttpRequest('POST', url, payload));
  }

  getDataPromise<T>(url: string) {
    return this._http.get<T>(url);
  }
}
