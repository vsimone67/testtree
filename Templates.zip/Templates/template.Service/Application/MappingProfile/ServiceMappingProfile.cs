using System;
using AutoMapper;

namespace template.Service.Application.MappingProfile
{
    public class ServiceMapingProfile : Profile
    {
        public ServiceMapingProfile()
        {
            //CreateMap<Entity, MyDto>(MemberList.Destination);

        }
    }
}
