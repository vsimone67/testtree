export interface OwnershipRelationshipDto {
    ownershipRelationshipId: string;
    reasonForChangeId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
}