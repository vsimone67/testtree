import { OfacRequestModel } from './ofacRequestModel';

export interface ClaimBeneficiaryEntityModel {
  claimBeneficiaryId: string;
  claimId: string;
  entityName: string;
  isOfac: boolean | null;
  fein: string;
  createDate: Date | string;
  createdBy: string;
  modifiedDate: Date | string | null;
  modifiedBy: string | null;
  ofacRequests: OfacRequestModel[];
}
