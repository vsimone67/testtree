import { EmailAddressDto } from './emailAddressDto';
import { EmailDocumentDto } from './emailDocumentDto';

export interface EmailDocumentEmailAddressDto {
    emailDocumentId: string;
    emailAddressId: string;
    isSender: boolean | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    emailAddress: EmailAddressDto;
    emailDocument: EmailDocumentDto;
}