import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChange,
  Output,
  EventEmitter,
} from '@angular/core';
import { GridBase } from '../GridBase';

@Component({
  selector: 'paged-grid',
  templateUrl: './paged-grid.component.html',
  styleUrls: ['../agGridStyles.css'],
})
export class PagedGridComponent extends GridBase implements OnInit, OnChanges {
  @Input() PageSize: number;
  @Input() RecordCount: number;
  @Output() OnPageChanged = new EventEmitter();

  public pageTemplate: string;

  constructor() {
    super();

    this.PageSize = 25;
    this.RecordCount = 0;
    this.pageTemplate = '';

    // generic page template to use for paging (it will be localized)
  }

  ngOnInit(): void {}

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    super.ngOnChanges(changes);
  }

  onPageChanged(event: any) {
    this.OnPageChanged.emit(event);
  }
}
