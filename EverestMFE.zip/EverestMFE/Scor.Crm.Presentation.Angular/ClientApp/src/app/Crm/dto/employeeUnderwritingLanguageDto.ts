import { EmployeeUnderwritingDto } from './employeeUnderwritingDto';

export interface EmployeeUnderwritingLanguageDto {
    employeeId: string;
    languageTypeId: string;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    rowStatusId: string | null;
    employee: EmployeeUnderwritingDto;
}