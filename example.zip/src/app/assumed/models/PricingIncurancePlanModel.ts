import { InsurancePlanModel } from './InsurancePlanModel';

export interface PricingInsurancePlanModel {
  PricingInsurancePlanId: string;
  InsurancePlanId: string;
  IssueTypeId: string;
  OptionTypeId: string | null;
  PricingInsurancePlanDescription: string;
  PricingInsurancePlanName: string;
  CreateDate: Date | string;
  CreatedBy: string | null;
  ModifiedDate: Date | string | null;
  ModifiedBy: string | null;
  InsurancePlan: InsurancePlanModel;

}
