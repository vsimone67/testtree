import { DemographicInfoGroupDto } from './demographicInfoGroupDto';
import { EmailDocumentEmailAddressDto } from './emailDocumentEmailAddressDto';

export interface EmailAddressDto {
    emailAddressId: string;
    demographicInfoGroupId: string | null;
    emailAddress1: string;
    emailAddressTypeId: string;
    isPrimaryEmail: boolean | null;
    createDate: string;
    createdBy: string | null;
    modifiedDate: string | null;
    modifiedBy: string | null;
    moduleReference: string | null;
    rowStatusId: string | null;
    demographicInfoGroup: DemographicInfoGroupDto;
    emailDocumentEmailAddress: EmailDocumentEmailAddressDto[];
}