export interface CodeModel{
    CodeId: string;
    CodeCategoryId: string;
    CodeDescription: string;
    CodeName: string;
    CodeValue: string;
    IsDefault: boolean;
    SequenceNumber: number;
    CreateDate: Date| string | null;
    CreatedBy: string | null;
    ModifiedDate: Date| string | null;
    ModifiedBy: string | null;
    ModuleReference: string | null;
    RowStatusId: string | null;
}