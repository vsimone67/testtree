using System;
using System.Threading;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using MediatR;

namespace MyNamespace.Application.Commands
{
    public class MyCommandCommandHandler : IRequestHandler<MyCommandCommand, MyCommandType>
    {
        private readonly ILogger<MyCommandCommandHandler> _logger;
        private readonly IMapper _mapper;
        private readonly MyDBService _dbService;

        public MyCommandCommandHandler(IServiceProvider serviceProvider)
        {
            _logger = serviceProvider.GetService<ILogger<MyCommandCommandHandler>>();
            _mapper = serviceProvider.GetService<IMapper>();
            _dbService = serviceProvider.GetService<MyDBService>();
        }

        public async Task<MyCommandType> Handle(MyCommandCommand request, CancellationToken cancellationToken)
        {

            return new Unit();
        }

    }
}
