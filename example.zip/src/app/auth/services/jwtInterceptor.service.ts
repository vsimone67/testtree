import { Injectable } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from "@angular/common/http";
import { BehaviorSubject, Observable } from "rxjs";
import { User } from "@auth/models/user";
import { SiteConstants } from "@constants/siteConstants";
import { AuthenticationService } from "./authentication.service";
import { switchMap } from "rxjs/operators";
import { filter } from "rxjs/operators";
import { take } from "rxjs/operators";
import { catchError } from "rxjs/operators";
import { throwError } from "rxjs";

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(
    null
  );

  constructor(private _authService: AuthenticationService) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const isLoggedIn = this._authService.isUserLoggedIn();

    if (isLoggedIn) {
      request = this.addToken(request, this._authService.getJwtToken());
    } else {
      // do not pass Bearer token if we do not have a valid one, we will get an unauthorized error
      // always pass withCredentials so Angular can pass the windows credentials
      request = request.clone({
        withCredentials: true,
      });
    }

    return next.handle(request);
  }

  private addToken(request: HttpRequest<any>, token: string) {
    return (request = request.clone({
      withCredentials: true,
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    }));
  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler) {
    console.log("Timeout Occurred, getting new credentials");
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);

      return this._authService.refreshToken().pipe(
        switchMap((token: any) => {
          this.isRefreshing = true;
          this.refreshTokenSubject.next(token.jwt);
          return next.handle(this.addToken(request, token.jwt));
        })
      );
    } else {
      return this.refreshTokenSubject.pipe(
        filter((token) => token != null),
        take(1),
        switchMap((jwt) => {
          return next.handle(this.addToken(request, jwt));
        })
      );
    }
  }
}
