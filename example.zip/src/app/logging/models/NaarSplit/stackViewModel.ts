import { StackCapacityViewModel } from "./StackCapacityViewModel";

export interface StackViewModel {
  stackName: string;
  effectiveDate: string;
  cancelDate: string;
  reinsuranceType: string;
  retainedRatio: number;
  nAARToAllocate: number;
  cededToAllocate: number;
  payorLegalEntity: string;
  stackCapacities: StackCapacityViewModel[];
}
