import { NgModule } from "@angular/core";
import { MessagesModule } from "primeng/messages";

@NgModule({
  declarations: [],
  imports: [MessagesModule],
  exports: [MessagesModule],
  providers: [],
})
export class HttpModule {}
