import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {TreeNode} from "primeng/api";
import {CompanyRelationshipDto} from "../../../dto/companyRelationshipDto";
import {CompanyDto} from "../../../dto/companyDto";
import {CrmService} from "../../../service/CrmService";

@Component({
  selector: 'company-relationship',
  templateUrl: './company-relationship.component.html',
  styleUrls: ['./company-relationship.component.css']
})
export class CompanyRelationshipComponent implements OnInit, OnChanges {
  @Input() relationship: CompanyRelationshipDto[]
  @Input() parentCompany: CompanyDto
  relationshioTree: any[];
  @Output() openContract: EventEmitter<any> = new EventEmitter<any>()
  showDialog: boolean;
  companyRelationship: CompanyRelationshipDto;
  @Output() refreshData: EventEmitter<any> = new EventEmitter<any>()

  constructor(private crmService: CrmService) {
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes)
    if (changes.relationship) {
      this.prepareTree(changes.relationship.currentValue)

    }
  }

  ngOnInit(): void {


  }

  prepareTree(companies) {
    this.relationshioTree = [];
    if (companies) {
      let root: TreeNode = {};
      root.label = "Relationships";
      root.expanded = true;
      root.children = []
      let parent: TreeNode = {};
      parent.label = this.parentCompany.companyName;
      parent.expanded = true;
      parent.children = [];
      companies.forEach((com: CompanyRelationshipDto) => {
        let node: TreeNode = {};
        node.data = com.childCompany ? com.childCompany.companyId : null;
        node.type = "url";
        node.label = com.childCompany ? com.childCompany.companyName : null;
        node.children = [];
        let owner: TreeNode = {label: com.companyRelationshipType.codeName};
        node.children.push(owner);
        parent.children.push(node)
      });
      if(companies.length === 0){
        let nodata: TreeNode = {};
        nodata.label = "No Relationship exists";
        parent.children.push(nodata)

      }
      root.children.push(parent)
      this.relationshioTree.push(root)
    }

  }

  open(data: any) {

  }

  addRelationship() {
    this.showDialog = true;
    this.companyRelationship = <CompanyRelationshipDto>{}
    this.companyRelationship.childCompany = <CompanyDto>{}
    this.companyRelationship.parentCompanyId = this.parentCompany.companyId
  }

  submitDialog(relationship: CompanyRelationshipDto) {
    this.crmService.AddCompanyRelationship(relationship).then(liste => this.refreshData.emit())
  }

  hideDialog() {
    this.showDialog = false;
  }
}
