export function formatNumberToCurrency(value) {
  return "$" + Math.round(Math.floor(value)).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}
export function txnformatNumberToCurrency(value) {
  return "$" + (Math.round(value * 100) / 100).toFixed(2).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}
