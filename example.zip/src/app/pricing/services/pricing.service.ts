import { Injectable } from "@angular/core";
import { HttpService } from "@shared/services/http-service.service";
import { SiteConstants } from '@constants/siteConstants';
import { PoolCapacityModel } from "@assumed/models/PoolCapacityModel";
import { StackCapacityModel } from "@assumed/models/StackCapacityModel";
import { RetroQuoteModel } from '@retro/models/retroQuoteModel';
import { RetroQuotePlanModel } from '@retro/models/retroQuotePlanModel';
import { RetroQuoteBandRateModel } from '@retro/models/retroQuoteBandRateModel';
import { AppSettingsService } from '@shared/services/app-settings.service';

@Injectable({
  providedIn: "root",
})
export class PricingService {

  private _pricingUrl: string;

  constructor(
    private _httpService: HttpService, private _appSettingsService: AppSettingsService) {
    //this._pricingUrl = `${environment.apiGatewayUrl}/${SiteConstants.pricingController}`;
    this._pricingUrl = `${this._appSettingsService.GetValue("apiGatewayUrl")}/${SiteConstants.pricingController}`;
  }

  async getStackForCession(stackName: string) {
    var stack = encodeURIComponent(stackName);
    return await this._httpService.getData<Array<StackCapacityModel>>(
      `${this._pricingUrl}/StackCapacity/${stack}`
    );
  }

  async getPoolForCession(poolName: string) {
    var pool = encodeURIComponent(poolName);

    return await this._httpService.getData<Array<PoolCapacityModel>>(
      `${this._pricingUrl}/PoolCapacity/${pool}`
    );
  }

  async getRetroQuote(quoteId: string) {

    return await this._httpService.getData<Array<RetroQuoteModel>>(
      `${this._pricingUrl}/RetroQuote/${quoteId}`
    );
  }

  async getRetroQuotePlan(quotePlanId: string) {

    return await this._httpService.getData<Array<RetroQuotePlanModel>>(
      `${this._pricingUrl}/RetroQuotePlan/${quotePlanId}`
    );
  }

  async getRetroQuoteBandRates(quoteBandId: string) {

    return await this._httpService.getData<Array<RetroQuoteBandRateModel>>(
      `${this._pricingUrl}/RetroQuoteBandRates/${quoteBandId}`
    );
  }
}
