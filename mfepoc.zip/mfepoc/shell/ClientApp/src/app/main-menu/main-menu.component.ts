import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadCrumbModel } from '../common/components/breadcrumb/breadcrumb.model';
import { events } from 'src/assets/constants/events.model';
import { LoaderService } from '../common/services/loader.service';
import { MicroFrontEnd } from '../common/models/microFrontEnd';
import { AppSettingsService, EventService } from '@scor/common';
import { Router } from '@angular/router';

@Component({
  selector: 'main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.css'],
})
export class MainMenuComponent implements OnInit {
  public items: MenuItem[];
  constructor(
    private eventService: EventService,
    private loaderService: LoaderService,
    private appSettings: AppSettingsService,
    private router: Router
  ) {
    this.items = [];
  }

  ngOnInit(): void {
    // get all available mfe's from appsettings
    // var microFontEnds = <Array<MicroFrontEnd>>(
    //   this.appSettings.GetValue('microFrontEnds')
    // );

    // // fill the menu array with all the mfe's
    // microFontEnds.forEach((mfe) =>
    //   this.items.push({
    //     label: mfe.label,
    //     url: mfe.url,
    //     command: (event) => {
    //       this.loadMfe(mfe.name, mfe.url, mfe.label);
    //     },
    //   })
    // );

    // this.items.push({label: "app2",
    //     url: "#/app2/page2",
    //     command: (event) => {
    //       this.loadMfe("app2", "#/app2/page2", "Page2");
    //     },});

     this.items = [
      {
        label: 'Treaty',
        url: '',
        command: (event) => {
          this.loadMfe('treaty', 'Treaty', 'treaty');
        },
      },
      {
        label: 'App1',
        command: (event) => {
          this.loadMfe('app1', '#/app1/home', 'App 1 Home');
        },
      },
      {
        label: 'App2',
        items: [
          {
            label: 'Home',
            command: (event) => {
              this.loadMfe("app2","#/app2/home","App 2 Home");
            },
          },
          {
            label: 'Page 2',
            command: (event) => {
              this.loadMfe("app2","#/app2/page2","App 2 Page 2");
            },
          }
        ],
      },
    ];
  }

  loadMfe(name: string, url: string, label: string) {
    //this.loaderService.loadMicroFrontEnd(name); // load the mfe into the shell

    // send breadcrumb event to update the control
    this.eventService.sendEvent(events.breadcrumbEvent, <BreadCrumbModel>{
      url: url,
      label: label,
    });

    //this.router.navigateByUrl(url);
    this.loaderService.navigate(name,url);

  }
}
