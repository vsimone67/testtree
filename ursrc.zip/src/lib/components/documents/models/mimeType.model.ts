import { CodeDto } from "./codeModel";

export interface MimeTypeDto {
  mimeTypeId: string;
  mimeMediaTypeId: string;
  mimeTypeDescription: string;
  mimeTypeName: string;
  mimeTypeExtension: string;
  mimeTypeImageName: string;
  isSubMimeType: boolean;
  sequenceNumber: number;
  createDate: string | null;
  createdBy: string | null;
  modifiedDate: string | null;
  modifiedBy: string | null;
  moduleReference: string | null;
  rowStatusId: string | null;
  mimeMediaType: CodeDto;
}
