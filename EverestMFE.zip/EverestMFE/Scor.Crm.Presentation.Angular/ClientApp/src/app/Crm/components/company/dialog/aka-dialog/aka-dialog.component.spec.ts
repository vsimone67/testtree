import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AkaDialogComponent } from './aka-dialog.component';

describe('AkaDialogComponent', () => {
  let component: AkaDialogComponent;
  let fixture: ComponentFixture<AkaDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AkaDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AkaDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
