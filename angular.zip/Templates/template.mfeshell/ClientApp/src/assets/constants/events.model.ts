export const events = {
  loadingEvent: 'loadingEvent',
  breadcrumbEvent: 'breadcrumbEvent'
};
