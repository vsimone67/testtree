export interface RetroTransactionHistoryModel {
  retroTransactionId: string;
  cessionId: string;
  retroCessionId: string;
  isConverted: boolean;
  isManual: boolean;
  rARSplitId: string;
  retroTransactionPeriodId: string;
  transactionFromDate: Date | string;
  transactionSequence: number;
  transactionToDate: Date | string;
  transactionTypeId: string;
  companyName: string;
  companyId: string;
  splitAmount: number;
  transactionTypeIdCodeName: string;
  grossBasePremium: number | null;
  baseAllowance: number | null;
  grossTempFlatExtraPremium: number | null;
  tempFlatExtraAllowance: number | null;
  grossPermFlatExtraPremium: number | null;
  permFlatExtraAllowance: number | null;
  grossPolicyFeePremium: number | null;
  policyFeeAllowance: number | null;
  cashSurrenderValue: number | null;
  unknownFlatExtraPremium: number | null;
  unknownFlatExtraAllowance: number | null;
  premiumTax: number | null;
  exciseTax: number | null;
  retroExpense: number | null;
  runDate: Date | string;
  isFinalized: boolean;
  isReversed: boolean;
  transactionIndicator: string;
  reportToDate: Date | string;
  splitTypeId: string;
  splitType: string;
  payorLegalEntityCompanyName: string;
  retroTreaty: string;
  isActiveRetro: boolean;

  splitAmountFormatted?: string;
  grossBasePremiumFormatted?: string;
  baseAllowanceFormatted?: string;
  grossTempFlatExtraPremiumFormatted?: string;
  tempFlatExtraAllowanceFormatted?: string;
  grossPermFlatExtraPremiumFormatted?: string;
  permFlatExtraAllowanceFormatted?: string;
  grossPolicyFeePremiumFormatted?: string;
  policyFeeAllowanceFormatted?: string;
  cashSurrenderValueFormatted?: string;
  unknownFlatExtraPremiumFormatted?: number | string | null;
  unknownFlatExtraAllowanceFormatted?: number | string | null;
  premiumTaxFormatted?: string;
  exciseTaxFormatted?: string;
  retroExpenseFormatted?: string;
  runDateFormatted?: Date | string;
  transactionFromDateFormatted?: Date | string;
  transactionToDateFormatted?: Date | string;
  reportToDateFormatted?: Date | string;
  hasRollback:boolean;
}

export class retroByDate {
  reportToDate: Date | string;
  children: retroByCompanies[]
}

export class retroByCompanies {
  companyName: string;
  children: RetroTransactionHistoryModel []

}
