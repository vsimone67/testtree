export const environment = {
  env: "prod",
  production: true,
};
